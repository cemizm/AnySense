<?php
/*
Plugin Name: Viral Coupon for WooCommerce
Plugin URI: http://WESMASHED.IT
Description: Offer your customers a discount if they like or share your link.
Version: 1.5.2
Author: WESMASHED.IT
Author URI: http://WESMASHED.IT
*/

define('VIRALCOUPON_DIR', dirname (__FILE__));
session_start();
ob_start();

/** Define class **/
if( !class_exists( "Woocommerce_Viral_Options" ) ) {
	class Woocommerce_Viral_Options {
		/** Add the admin menu **/
		function add_admin_menu_latest() {
			if ( function_exists( 'add_options_page' ) ) {
				$page = add_menu_page( 'viralcoupon', 'Viral Coupon', 'edit_pages', 'viral-coupon/viral-coupon.php', array( &$this, 'excute_it' ) );
			}
			add_action( 'admin_head-'. $page, array($this,'addHeaderCode') );
			add_action('admin_menu','add_admin_menu_latest');
		}
		
		public function curPageURL() {
			$pageURL = 'http';
			if (@$_SERVER["HTTPS"] == "on") {
				$pageURL .= "s";
			}
			$pageURL .= "://";
			if ($_SERVER["SERVER_PORT"] != "80") {
				$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
			} else {
				$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
			}
			return $pageURL;
		}
		
		/** Add style to header **/
		function addHeaderCode() {
			echo "<link type='text/css' rel='stylesheet' href='".plugins_url( 'style.css', __FILE__ )."'>";
		}
		
		/** Function for plugin view **/
		function excute_it() { 
			/** Get coupons which can be used for free shipping **/
			global $wpdb;
			$couponQuery = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'shop_coupon' ORDER BY id DESC");
			$count       = count( $couponQuery );
			if( $count > 0 ) {
				foreach( $couponQuery as $couponid ) {
					$pid         = $couponid->ID;
					$couponCheck = get_post_meta( $pid, 'free_shipping', true );
					if( $couponCheck == 'yes' )	{
						$couponNames[] = $couponid->post_title;
					}
				}
			}
			/** Get the options if saved **/
			$options = get_option( 'viralcoupon_options' );
			if( $options != '' ) {				
				/** Get the Viral couponer options **/
				$viraloptions = json_decode( $options);				
				$myid         = $viraloptions->myid;
				$message      = $viraloptions->message;
				$twitterurl   = $viraloptions->twitterurl;
				$fburl        = $viraloptions->fburl;
				$googleurl    = $viraloptions->googleurl;
				$tweet        = $viraloptions->tweet;
				$coupon       = $viraloptions->coupon;
				$uncouponed   = $viraloptions->uncouponed;
				$cookies      = $viraloptions->cookies;
				$cartpage     = $viraloptions->cartpage;
				$checkoutpage = $viraloptions->checkoutpage;
				$delaytime    = $viraloptions->delaytime;
				$delayseconds    = $viraloptions->delayseconds;
				$displaybuttons = $viraloptions->displaybuttons;
				if(isset($viraloptions->enablehttps) && property_exists($viraloptions,'enablehttps'))
					$enablehttps=$viraloptions->enablehttps;
				$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
				$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
				$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
				
				if(isset($viraloptions->disablejquery) && property_exists($viraloptions,'disablejquery'))
					$disablejquery = $viraloptions->disablejquery;

			}
			
			?>
			<div class="wrap ino_wrap">
				<div class="wrap ino_wrap">
					<?php
					/** Show message when options are saved or updated **/
					if( isset( $_SESSION['successmessage'] ) ) {
					?>
						<div class="updated fade" id="message"><p><strong><?php echo $_SESSION['successmessage'];unset( $_SESSION['successmessage'] ); ?></strong></p></div>
					<?php
					}
					?>
					<div class="ino_opts">
						<form method="post" action="">					
							
							<div class="ino_section">								
								<div class="ino_titlee"><h3><span class="home">Viral Coupon Settings</span></h3><div class="clearfix"></div></div>
								<div class="ino_optionss">
									
									<div class="ino_input ino_text">
									 <label for="myid">My ID</label>
										<input name='data[myid]' id='myid' type='text' value='<?php if( isset( $myid ) ) echo $myid;?>'/>
										<small>Enter the unique campaign ID.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_textarea">
										<label for="message">Message</label>
										<textarea name='data[message]' rows='3' cols='5'><?php if( isset( $message ) ) echo $message;?></textarea>
										<small>Enter the message you want to appear before the customer has liked or shared.</small><div class="clearfix"></div>
									</div>
											
									<div class="ino_input ino_text">
									 <label for="twitterurl">Twitter URL</label>
										<input name='data[twitterurl]' id='twitterurl' type='text' value='<?php if( isset( $twitterurl ) ) echo $twitterurl;?>'/>
										<small>Enter the URL you want to share on Twitter.</small>
										<span style="float: left; clear: both; margin-left: 20%; color: red; margin-top: 5px;">Please include HTTP in your link. Example: http://www.mysite.com/</span>
										<div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="fburl">Facebook URL</label>
										<input name='data[fburl]' id='fburl' type='text' value='<?php if( isset( $fburl ) ) echo $fburl;?>'/>
										<small>Enter the URL you want to share on Facebook.</small>
										<span style="float: left; clear: both; margin-left: 20%; color: red; margin-top: 5px;">Please include HTTP in your link. Example: http://www.mysite.com/</span>
										<div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="googleurl">Google+ URL</label>
										<input name='data[googleurl]' id='googleurl' type='text' value='<?php if( isset( $googleurl ) ) echo $googleurl;?>'/>
										<small>Enter the URL you want to share on Google+.</small>
										<span style="float: left; clear: both; margin-left: 20%; color: red; margin-top: 5px;">Please include HTTP in your link. Example: http://www.mysite.com/</span>
										<div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_textarea">
										<label for="tweet">Tweet</label>
										<textarea name='data[tweet]' rows='5' cols='5'><?php if( isset( $tweet ) ) echo $tweet;?></textarea>
										<small>Enter the Tweet you want to send (don't include your link here).</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_select">
										<label for="coupon">Select Coupon code</label>
										<select name="data[coupon]" id="cookies">
											<?php 
											if( $count > 0 ) {
												foreach( $couponQuery as $couponid ) {
												?>
													<option value="<?php echo $couponid->post_title;?>" <?php if( isset( $coupon ) && $coupon == $couponid->post_title ) echo "selected=selected";?>><?php echo $couponid->post_title;?></option>
												<?php
												}
											} else {
												?>
												<option value="" >Select</option>
												<?php
											}
											?>											
										</select>
										<small>Select Coupon code which should be applied</small><div class="clearfix"></div>
									</div>
																		
									<div class="ino_input ino_textarea">
										<label for="tweet">Thank you message</label>
										<textarea name='data[uncouponed]' rows='5' cols='5'><?php if( isset( $uncouponed ) ) echo $uncouponed;?></textarea>
										<small>Enter message to be shown when the user has liked or shared your link. You can included the coupon name here if you wan't your customer to be able to use it at another time.</small><div class="clearfix"></div>
									</div>	

									<div class="ino_input ino_text">
									 <label for="enableFB">Enable Facebook</label>
										<input name='data[enableFB]' id='enableFB' type='checkbox' value='1' <?php if( ( isset( $enableFB ) && $enableFB == "enable" ) || ( !isset($enableFB) && $enableFB != "enable" && $enableFB != "disable"  ) ) { echo "checked=checked"; } else {}?> />
										<small>Check to enable Facebook.</small><div class="clearfix"></div>
									</div> 
									
									<div class="ino_input ino_text">
									 <label for="enableTwttr">Enable Twitter</label>
										<input name='data[enableTwttr]' id='enableTwttr' type='checkbox' value='1' <?php if( ( isset( $enableTwttr ) && $enableTwttr == "enable" ) || ( !isset($enableTwttr) && $enableTwttr != "enable" && $enableTwttr != "disable"  ) ) { echo "checked=checked"; } else {}?> />
										<small>Check to enable Twitter.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="enableGo">Enable Google+</label>
										<input name='data[enableGo]' id='enableGo' type='checkbox' value='enableGo' <?php if( ( isset( $enableGo ) && $enableGo == "enable" ) || ( !isset($enableGo) && $enableGo != "enable" && $enableGo != "disable"  ) ) { echo "checked=checked"; } else {}?> />
										<small>Check to enable Google+.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="cartpage">Enable on Cart page</label>
										<input name='data[cartpage]' id='cartpage' type='checkbox' value='cartpage' <?php if( isset( $cartpage ) && $cartpage == 'cartpage' ) echo "checked=checked";?>/>
										<small>Check to enable on Cart Page.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="checkoutpage">Enable on Checkout page</label>
										<input name='data[checkoutpage]' id='checkoutpage' type='checkbox' value='checkoutpage' <?php if( isset( $checkoutpage ) && $checkoutpage == 'checkoutpage' ) echo "checked=checked";?>/>
										<small>Check to enable on Checkout Page.</small><div class="clearfix"></div>
									</div>
									
									<!-- Refresh Delay time : New -->
									<div class="ino_input ino_text">
									 <label for="delaytime">Refresh delay</label>
										<input name='data[delaytime]' id='delaytime' type='checkbox' value='delaytime' <?php if( isset( $delaytime ) && $delaytime == 'delaytime' ) echo "checked=checked";?>/>
										<small>Check to enable a delay time before the content is unlocked with Facebook and Google+. This gives your customers the opportunity to write about it on their wall.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="delayseconds">Refresh delay time</label>										
										<select name="data[delayseconds]" id="delayseconds">
											<option value="0" <?php if( isset( $delayseconds ) && $delayseconds == 0 ) echo "selected=selected";?>>0</option>
											<option value="1000" <?php if( isset( $delayseconds ) && $delayseconds == 1000 ) echo "selected=selected";?>>1</option>
											<option value="2000" <?php if( isset( $delayseconds ) && $delayseconds == 2000 ) echo "selected=selected";?>>2</option>
											<option value="3000" <?php if( isset( $delayseconds ) && $delayseconds == 3000 ) echo "selected=selected";?>>3</option>
											<option value="4000" <?php if( isset( $delayseconds ) && $delayseconds == 4000 ) echo "selected=selected";?>>4</option>
											<option value="5000" <?php if( isset( $delayseconds ) && $delayseconds == 5000 ) echo "selected=selected";?>>5</option>
											<option value="6000" <?php if( isset( $delayseconds ) && $delayseconds == 6000 ) echo "selected=selected";?>>6</option>
											<option value="7000" <?php if( isset( $delayseconds ) && $delayseconds == 7000 ) echo "selected=selected";?>>7</option>
											<option value="8000" <?php if( isset( $delayseconds ) && $delayseconds == 8000 ) echo "selected=selected";?>>8</option>
											<option value="9000" <?php if( isset( $delayseconds ) && $delayseconds == 9000 ) echo "selected=selected";?>>9</option>
											<option value="10000" <?php if( isset( $delayseconds ) && $delayseconds == 10000 ) echo "selected=selected";?>>10</option>
											<option value="11000" <?php if( isset( $delayseconds ) && $delayseconds == 11000 ) echo "selected=selected";?>>11</option>
											<option value="12000" <?php if( isset( $delayseconds ) && $delayseconds == 12000 ) echo "selected=selected";?>>12</option>
											<option value="13000" <?php if( isset( $delayseconds ) && $delayseconds == 13000 ) echo "selected=selected";?>>13</option>
											<option value="14000" <?php if( isset( $delayseconds ) && $delayseconds == 14000 ) echo "selected=selected";?>>14</option>
											<option value="15000" <?php if( isset( $delayseconds ) && $delayseconds == 15000 ) echo "selected=selected";?>>15</option>
											<option value="16000" <?php if( isset( $delayseconds ) && $delayseconds == 16000 ) echo "selected=selected";?>>16</option>
											<option value="17000" <?php if( isset( $delayseconds ) && $delayseconds == 17000 ) echo "selected=selected";?>>17</option>
											<option value="18000" <?php if( isset( $delayseconds ) && $delayseconds == 18000 ) echo "selected=selected";?>>18</option>
											<option value="19000" <?php if( isset( $delayseconds ) && $delayseconds == 19000 ) echo "selected=selected";?>>19</option>
											<option value="20000" <?php if( isset( $delayseconds ) && $delayseconds == 20000 ) echo "selected=selected";?>>20</option>
										</select>
										<small>Set the Refresh delay time in seconds.</small><div class="clearfix"></div>
									</div>

									<div class="ino_input ino_text">
									 <label for="enablehttps">Enable HTTPS</label>
										<input name='data[enablehttps]' id='enablehttps' type='checkbox' value='enablehttps' <?php if( isset( $enablehttps ) && $enablehttps == 'enablehttps' ) echo "checked=checked";?> />
										<small>Enable to send the data over HTTPS. If you use SSL then enable this option.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_select">
										<label for="cookies">Test Mode</label>
										<select name="data[cookies]" id="cookies">
											<option value="enable" <?php if( isset( $cookies ) && $cookies == 'enable' ) echo "selected=selected";?>>Disable</option>
											<option value="disable" <?php if( isset( $cookies ) && $cookies == 'disable' ) echo "selected=selected";?>>Enable</option>
										</select>
										<small>Enable if you don't want the Viral Coupon box to dissapear after it has been liked/shared.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_select">
										<label for="displaybuttons">Display Buttons</label>
										<select name="data[displaybuttons]" id="displaybuttons">
											<option value="vertical" <?php if( isset( $displaybuttons ) && $displaybuttons == 'vertical' ) echo "selected=selected";?>>Vertical</option>
											<option value="horizontal" <?php if( isset( $displaybuttons ) && $displaybuttons == 'horizontal' ) echo "selected=selected";?>>Horizontal</option>
										</select>
										<small>Display Buttons: Vertically / Horizontally.</small><div class="clearfix"></div>
									</div>
									
									<div class="ino_input ino_text">
									 <label for="disablejquery">Disable jQuery</label>
										<input name='data[disablejquery]' id='disablejquery' type='checkbox' value='disablejquery' <?php if( isset( $disablejquery ) && $disablejquery == 'disablejquery' ) echo "checked=checked";?> />
										<small>Disable jQuery if there is a jQuery Conflict.</small><div class="clearfix"></div>
									</div>
									
									<input type="hidden" name="action" value="save" />
									<div class="ino_foot"><span class="submit"><input type="submit" value="Save changes" name="save"></span></div>
								</div>
							</div>
							<div class="footer">
								<span style="float: left; line-height: 25px; font-weight: bold; padding-left: 5px;">&copy; WESMASHED.IT</span>
								<div class="clearfix"></div>
							</div>
						</form>						
					</div>
					<div class="clear"></div>					
				</div>
				<div class="clear"></div>
			</div>	
			<div class="clear"></div>			
			<?php
		}
		
		/** Function to display the Viral coupon box in the cart page and checkout page **/
		function front_end_cart_init() { 
			/** Incude the Viral Locker Class **/
				require_once( 'class-viral-coupon.php' );
				/** Intiate object **/
				$virallocker = new Woocommerce_Viral_Coupon();
				/** Check if viral lock is active or not to show/hide the content accordingly **/
				if( isset( $_COOKIE["virallock_".$myid] ) )
					$cookie_value = $_COOKIE["virallock_".$myid];
				if( isset( $_COOKIE['virallock_time_'.$myid] ) && $cookies == 'disable' )	{
					setcookie ( "virallock_time_".$myid, 'long', time() - 3600 );
					setcookie("virallock_".$myid, '0001', time() - 3600 );
				}
				if( !empty( $cookie_value ) && $cookie_value == '0001' ) {
					$options      = get_option( 'viralcoupon_options' );
					$viraloptions = json_decode( $options);
					$cookies      = $viraloptions->cookies;
					
					//if( isset( $_COOKIE['virallock_time_'.$myid] ) ) { 
					if( isset( $_COOKIE['virallock_message'] ) ) { 
					?>
					<div class="unlocked">
						<h2>
							<?php echo $_COOKIE['virallock_message'];setcookie("virallock_message", $viraloptions->uncouponed, time() - 3600 ); ?>
						</h2>
					</div>
					<?php
					} elseif( isset( $_COOKIE['virallock_smessage'] ) ) {
					?>
					<div class="unlocked">
						<h2><?php echo $_COOKIE['virallock_smessage'];setcookie( "virallock_smessage", $viraloptions->uncouponed, time() - 3600 );?></h2>
					</div>
					<?php
					}
				} elseif( empty( $cookie_value ) )	{
					
					// check enabled/disabled social media
					$options      = get_option( 'viralcoupon_options' );
					$viraloptions = json_decode( $options);
					$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
					$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
					$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
					$message      = $viraloptions->message;
					$twitterurl   = $viraloptions->twitterurl;
					$fburl        = $viraloptions->fburl;
					$googleurl    = $viraloptions->googleurl;
					$tweet        = $viraloptions->tweet;
					$displaybuttons = $viraloptions->displaybuttons;
					
					if(trim($twitterurl) == ''){
						$twitterurl=$this->curPageURL();
					} 
					if(trim($fburl) == ''){
						$fburl=$this->curPageURL();
					} 
					if(trim($googleurl) == ''){
						$googleurl=$this->curPageURL();
					} 
					$twittershareurl='http://twitter.com/share';
					if(isset($enablehttps) && ($enablehttps == "enablehttps"))
						$twittershareurl= 'https://twitter.com/share';
					
					$classname = $displaybuttons;
					
					$html = '<script type="text/javascript">
							virallocker_use = true;
						</script>
						<div class="virallocker-box">
							<div class="viralmessage">'.$message.'</div>';
					
					if( $classname == "horizontal") {
						if( $enableTwttr == "enable") 
							$html .=	'<div class="'.$classname.'twttr"><a href="'.$twittershareurl.'" class="twitter-share-button" data-text="'.$tweet.'" data-url="'.$twitterurl.'" data-count="horizontal">Tweet</a></div>';
						if( $enableGo == "enable")
							$html .=	'<div class="'.$classname.'gplus"><div class="g-plusone" data-size="medium" data-href="'.$googleurl.'"></div></div>';
						if( $enableFB == "enable")
							$html .=	'<div class="'.$classname.'fb"><fb:like id="fbLikeButton" href="'.$fburl.'" show_faces="false" data-layout="button_count" width=""></fb:like></div>';
					} else {
						if( $enableTwttr == "enable") 
							$html .=	'<div class="'.$classname.'twttr"><a href="'.$twittershareurl.'" class="twitter-share-button" data-text="'.$tweet.'" data-url="'.$twitterurl.'" data-count="horizontal">Tweet</a></div>';
						if( $enableGo == "enable")
							$html .=	'<div class="'.$classname.'gplus"><div class="g-plusone" data-size="medium" data-annotation="inline" data-href="'.$googleurl.'"></div></div>';
						if( $enableFB == "enable")
							$html .=	'<div class="'.$classname.'fb"><fb:like id="fbLikeButton" href="'.$fburl.'" show_faces="false" data-layout="standard" width=""></fb:like></div>';
					}
					
					$html .= '</div>';
					
					echo $html;
				}
				/** Include the required fb div and short code handler **/
				$virallocker->virallocker_handler();
			?>
			<div style="position:absolute;top: -1000px;">
				<form id="couponForm" method="POST" action="">
					<input type="text" value="<?php echo $coupon;?>" id="coupon_code" class="input-text" name="coupon_code"> 
					<input type="submit" class="button" style="display:block;">
					<input type="hidden" value="Apply Coupon" name="apply_coupon" />
				</form>
			</div>
			<!-- End: Viral Lock Coupon -->
			<?php
		}
		
		/** Function to display the Viral coupon box in the cart page and checkout page **/
		function front_end_checkout_init() { 
			/** Incude the Viral Locker Class **/
				require_once( 'class-viral-coupon.php' );
				/** Intiate object **/
				$virallocker = new Woocommerce_Viral_Coupon();
				/** Check if viral lock is active or not to show/hide the content accordingly **/
				if( isset( $_COOKIE["virallock_".$myid] ) )
					$cookie_value = $_COOKIE["virallock_".$myid];
				if( isset( $_COOKIE['virallock_time_'.$myid] ) && $cookies == 'disable' )	{
					setcookie ( "virallock_time_".$myid, 'long', time() - 3600 );
					setcookie("virallock_".$myid, '0001', time() - 3600 );
				}
				if( !empty( $cookie_value ) && $cookie_value == '0001' ) {
					$options      = get_option( 'viralcoupon_options' );
					$viraloptions = json_decode( $options);
					$cookies      = $viraloptions->cookies;
					
					//if( isset( $_COOKIE['virallock_time_'.$myid] ) ) { 
					if( isset( $_COOKIE['virallock_message'] ) ) { 
					?>
					<div class="unlocked-checkout">
						<h2>
							<?php echo $_COOKIE['virallock_message'];setcookie("virallock_message", $viraloptions->uncouponed, time() - 3600 ); ?>
						</h2>
					</div>
					<?php
					} elseif( isset( $_COOKIE['virallock_smessage'] ) ) {
					?>
					<div class="unlocked-checkout">
						<h2><?php echo $_COOKIE['virallock_smessage'];setcookie( "virallock_smessage", $viraloptions->uncouponed, time() - 3600 );?></h2>
					</div>
					<?php
					}
				} elseif( empty( $cookie_value ) )	{
				
					// check enabled/disabled social media
					$options      = get_option( 'viralcoupon_options' );
					$viraloptions = json_decode( $options);
					$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
					$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
					$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
					$message      = $viraloptions->message;
					$twitterurl   = $viraloptions->twitterurl;
					$fburl        = $viraloptions->fburl;
					$googleurl    = $viraloptions->googleurl;
					$tweet        = $viraloptions->tweet;
					$displaybuttons = $viraloptions->displaybuttons;
					
					if(trim($twitterurl) == ''){
						$twitterurl=$this->curPageURL();
					} 
					if(trim($fburl) == ''){
						$fburl=$this->curPageURL();
					} 
					if(trim($googleurl) == ''){
						$googleurl=$this->curPageURL();
					} 
					$twittershareurl='http://twitter.com/share';
					if(isset($enablehttps) && ($enablehttps == "enablehttps"))
						$twittershareurl= 'https://twitter.com/share';
					
					$classname = $displaybuttons;
					
					$html = '<script type="text/javascript">
							virallocker_use = true;
						</script>
						<div class="virallocker-box-checkout">
							<div class="viralmessage">'.$message.'</div>';
					if( $classname == "horizontal") {
						if( $enableTwttr == "enable") 
							$html .=	'<div class="'.$classname.'twttr"><a href="'.$twittershareurl.'" class="twitter-share-button" data-text="'.$tweet.'" data-url="'.$twitterurl.'" data-count="horizontal">Tweet</a></div>';
						if( $enableGo == "enable")
							$html .=	'<div class="'.$classname.'gplus"><div class="g-plusone" data-size="medium" data-href="'.$googleurl.'"></div></div>';
						if( $enableFB == "enable")
							$html .=	'<div class="'.$classname.'fb"><fb:like id="fbLikeButton" href="'.$fburl.'" show_faces="false" data-layout="button_count" width=""></fb:like></div>';
					} else {
						if( $enableTwttr == "enable") 
							$html .=	'<div class="'.$classname.'twttr"><a href="'.$twittershareurl.'" class="twitter-share-button" data-text="'.$tweet.'" data-url="'.$twitterurl.'" data-count="horizontal">Tweet</a></div>';
						if( $enableGo == "enable")
							$html .=	'<div class="'.$classname.'gplus"><div class="g-plusone" data-size="medium" data-annotation="inline" data-href="'.$googleurl.'"></div></div>';
						if( $enableFB == "enable")
							$html .=	'<div class="'.$classname.'fb"><fb:like id="fbLikeButton" href="'.$fburl.'" show_faces="false" data-layout="standard" width=""></fb:like></div>';
					}
					$html .= '</div>';
					
					echo $html;
				}
				/** Include the required fb div and short code handler **/
				$virallocker->virallocker_handler_checkout();
			?>
			<div style="position:absolute;top: -1000px;">
				<form id="couponForm" method="POST" action="">
					<input type="text" value="<?php echo $coupon;?>" id="coupon_code" class="input-text" name="coupon_code"> 
					<input type="submit" class="button" style="display:block;">
					<input type="hidden" value="Apply Coupon" name="apply_coupon" />
				</form>
			</div>
			<!-- End: Viral Lock Coupon -->
			<?php
		}
	}
}

/** class object **/
$viralcouponoptions = new Woocommerce_Viral_Options();
/** Get the options if saved **/
$options = get_option( 'viralcoupon_options' );
if( $options != '' ) {
	/** Get the Viral couponer options **/
	$viraloptions = json_decode( $options);
	$cartpage     = $viraloptions->cartpage;
	$checkoutpage = $viraloptions->checkoutpage;
}

if( isset( $cartpage ) && $cartpage == 'cartpage' )
	add_action( 'woocommerce_cart_collaterals', array( &$viralcouponoptions, 'front_end_cart_init' ) );

if( isset( $checkoutpage ) && $checkoutpage == 'checkoutpage' )
	add_action( 'woocommerce_before_checkout_form', array(&$viralcouponoptions, 'front_end_checkout_init'));
if( is_admin() ) {	
	add_action( "admin_menu", array( &$viralcouponoptions, "add_admin_menu_latest" ) );
}


/** Save the Viral coupon options **/
if( isset( $_POST['action'] ) && ( $_POST['action'] == 'save' ) ) {

	/** Set the option name and value **/
	$option_name     = 'viralcoupon_options';
	if( !isset( $_POST['data']['cartpage'] ) )
		$_POST['data']['cartpage'] = '';
	if( !isset( $_POST['data']['checkoutpage'] ) )
		$_POST['data']['checkoutpage'] = '';
	if( !isset($_POST['data']['delaytime']))
		$_POST['data']['delaytime']='';	
	$options         = $_POST['data'];
	$viralcouponopts = json_encode( $options );
	
	/** Check if option exists for updating or add the option **/
	
	if ( get_option( $option_name ) != $viralcouponopts ) {
		update_option( $option_name, $viralcouponopts );
		$_SESSION['successmessage'] = 'Viral coupon options updated.';
	} else {
		add_option( $option_name, $viralcouponopts, '', 'yes' );
		$_SESSION['successmessage'] = 'Viral coupon options saved.';
	}
}

/** set cookie on ajax call and return true to show the locked content **/
if( isset( $_POST['action'] ) && ( $_POST['action'] == 'submit' ) ) {	
	$options = get_option( 'viralcoupon_options' );
	if( $options != '' ) {
		$viraloptions = json_decode( $options);
		$myid         = $viraloptions->myid;
		$message      = $viraloptions->message;
		$twitterurl   = $viraloptions->twitterurl;
		$fburl        = $viraloptions->fburl;
		$googleurl    = $viraloptions->googleurl;
		$tweet        = $viraloptions->tweet;
		$coupon       = $viraloptions->coupon;
		$unlocked     = $viraloptions->uncouponed;
		$cookies      = $viraloptions->cookies;
		$delaytime    = $viraloptions->delaytime;
		$delayseconds = $viraloptions->delayseconds;
		$displaybuttons = $viraloptions->displaybuttons;
	}
	/** Set the cookies time according to enable/disable **/
	if( $cookies == 'disable' )	{
		$time = time()+ 60;
		setcookie( "virallock_smessage", $viraloptions->uncouponed, time()+ 60 );
		$longtime = time()+ 60*60*24*365*10;
		setcookie ( "virallock_time_".$myid, '', $longtime - 3600 );
	} else {
		$time = time()+ 60*60*24*365*10;
		setcookie( "virallock_time_".$myid, 'long', $time );
		setcookie( "virallock_message", $viraloptions->uncouponed, time()+ 30 );
	}
	setcookie("virallock_".$myid, '0001', $time);
	echo true;
	exit;
}
