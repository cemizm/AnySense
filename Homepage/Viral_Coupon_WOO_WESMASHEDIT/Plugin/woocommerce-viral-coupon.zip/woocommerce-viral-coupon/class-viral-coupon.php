<?php 
/*
Script Name: Viral Coupon
Description: Viral Coupon gives your customers a coupon if they like or share your link.
Version: 1.0
Author: WESMASHED.IT
*/
$wp_scripts = new WP_Scripts();

/** Get the viral locker options **/
$options = get_option( 'viralcoupon_options' );
if( $options != '' ) {
	$viraloptions = json_decode( $options);
	$myid         = $viraloptions->myid;
	$message      = $viraloptions->message;
	$twitterurl   = $viraloptions->twitterurl;
	$fburl        = $viraloptions->fburl;
	$googleurl    = $viraloptions->googleurl;
	$tweet        = $viraloptions->tweet;
	$coupon       = $viraloptions->coupon;
	$unlocked     = $viraloptions->uncouponed;
	$cookies      = $viraloptions->cookies;		
	$delaytime    = $viraloptions->delaytime;
	$delayseconds    = $viraloptions->delayseconds;	
	$displaybuttons = $viraloptions->displaybuttons;
	
	if(isset($viraloptions->enablehttps) && property_exists($viraloptions,'enablehttps'))
		$enablehttps= $viraloptions->enablehttps;
	
	$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
	$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
	$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
	
	if(isset($viraloptions->disablejquery) && property_exists($viraloptions,'disablejquery'))
		$disablejquery = $viraloptions->disablejquery;
}

wp_deregister_script('plusone');
wp_deregister_script('twittersdk');
if(isset($enablehttps) && ($enablehttps == "enablehttps")){
	if( $enableGo == "enable")
		wp_register_script('plusone', 'https://apis.google.com/js/plusone.js');	
	if( $enableTwttr == "enable")
		wp_register_script('twittersdk', 'https://platform.twitter.com/widgets.js');
}
else{
	if( $enableGo == "enable")
		wp_register_script('plusone', 'http://apis.google.com/js/plusone.js');
	if( $enableTwttr == "enable")
		wp_register_script('twittersdk', 'http://platform.twitter.com/widgets.js');
}
if( $enableGo == "enable")
	wp_enqueue_script("plusone");
if( $enableTwttr == "enable")
	wp_enqueue_script("twittersdk");

/** Woo commerce viral coupon class **/
class Woocommerce_Viral_Coupon {
	
	function __construct() {
		$this->add_header();
	}
	
	function virallocker_handler() {
		/** Get the viral locker options **/
		$options = get_option( 'viralcoupon_options' );
		if( $options != '' )
		{
			$viraloptions = json_decode( $options);
			$myid         = $viraloptions->myid;
			$message      = $viraloptions->message;
			$twitterurl   = $viraloptions->twitterurl;
			$fburl        = $viraloptions->fburl;
			$googleurl    = $viraloptions->googleurl;
			$tweet        = $viraloptions->tweet;
			$coupon       = $viraloptions->coupon;
			$unlocked     = $viraloptions->uncouponed;
			$cookies      = $viraloptions->cookies;						
			$delaytime    = $viraloptions->delaytime;
			$delayseconds    = $viraloptions->delayseconds;			
			if(isset($viraloptions->enablehttps) && property_exists($viraloptions,'enablehttps'))
				$enablehttps = $viraloptions->enablehttps;
			
			if( !empty( $delaytime ) ) {				
				$seconds = $delayseconds;			
			} else {				
				$seconds = 1000;			
			}
			
			$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
			$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
			$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
		}
		
		$html = '<script type="text/javascript">
			var virallocker_use = true;
			var viralcurrentpageurl = "/" + window.location.pathname.substr(1);';
		
		if( $enableGo == "enable") {
			$html .= '
					function virallocker_plusone(plusone) {
						if (plusone.state == "on") {
							var data = { action: "submit", myID: "'.$myid.'"};
							jQuery.post(viralcurrentpageurl, data, function(response) {
								if (virallocker_use) {
									setTimeout(function() {								
										jQuery("#couponForm").submit();							 
									}, '.$seconds.');
									//jQuery("#couponForm").submit();
									//location.reload();
								}				
							});
						}
					}';
		}
		
		$html .= '
			jQuery(document).ready(function() { ';
		
		if( $enableFB == "enable") {
			$html .= 'FB.Event.subscribe("edge.create", function(href, widget) { 
						var data = { action: "submit", myID: "'.$myid.'"};
						jQuery.post(viralcurrentpageurl, data, function(response) { 
							if (virallocker_use) 
							{ 							
								setTimeout(function() {								
									jQuery("#couponForm").submit();							 
								}, '.$seconds.');
								//jQuery("#couponForm").submit();
								//location.reload();					
							}
						});
						
					});';
		}
		
		if( $enableTwttr == "enable")	{	
			$html .= 'twttr.ready(function (twttr) {
						twttr.events.bind("tweet", function(event) { 
							var data = { action: "submit", myID: "'.$myid.'"};
							jQuery.post(viralcurrentpageurl, data, function(response) {
							if (virallocker_use) 
							{
								jQuery("#couponForm").submit();
								//location.reload();					
							}					
						});
						});
					});';
		}
				
		$html .= '});
		</script>';
		
		echo $html;	
	}
	
	function virallocker_handler_checkout() {
		/** Get the viral locker options **/
		$options = get_option( 'viralcoupon_options' );
		if( $options != '' )
		{
			$viraloptions = json_decode( $options);
			$myid         = $viraloptions->myid;
			$message      = $viraloptions->message;
			$twitterurl   = $viraloptions->twitterurl;
			$fburl        = $viraloptions->fburl;
			$googleurl    = $viraloptions->googleurl;
			$tweet        = $viraloptions->tweet;
			$coupon       = $viraloptions->coupon;
			$unlocked     = $viraloptions->uncouponed;
			$cookies      = $viraloptions->cookies;						
			$delaytime    = $viraloptions->delaytime;
			$delayseconds    = $viraloptions->delayseconds;	
			if(isset($viraloptions->enablehttps) && property_exists($viraloptions,'enablehttps'))			
				$enablehttps = $viraloptions->enablehttps;
			if( !empty( $delaytime ) ) {				
				$seconds = $delayseconds;			
			} else {				
				$seconds = 1000;			
			}
			
			$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
			$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
			$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
		}
		
		// check if SSL is enabled on the Checkout page
		$homeURL = get_option('home');		
		if( isset( $_SERVER['HTTPS'] ) ) {
			$postURL = str_replace('http', 'https', $homeURL);
		} else {
			$postURL = $homeURL;
		}
		
		$html = '<script type="text/javascript">
				var virallocker_use = true;
				var viralcurrentpageurl = "/" + window.location.pathname.substr(1);';
		
		if( $enableGo == "enable") {
			$html .= '
			function virallocker_plusone(plusone) {
				if (plusone.state == "on") {
					var data = { action: "submit", myID: "'.$myid.'"};
					jQuery.post(viralcurrentpageurl, data, function(response) {
						if (virallocker_use) {
							//jQuery("#couponForm").submit();
							var _data= jQuery("#couponForm").serialize() + "&action=woocommerce_apply_coupon&security='.wp_create_nonce( "apply-coupon" ).'";
							jQuery.ajax({
							  type: "POST",
							  url: "'.$postURL.'/wp-admin/admin-ajax.php",
							  data:_data,
							  success: function(html){
								 location.reload();
								 //jQuery("#couponForm").submit();
							  }
							});
						}				
					});
				}
			}';
		}
		
		$html .= '
			jQuery(document).ready(function() { ';
		
		if( $enableFB == "enable") {
			$html .= '
				FB.Event.subscribe("edge.create", function(href, widget) { 
					var data = { action: "submit", myID: "'.$myid.'"};
					jQuery.post(viralcurrentpageurl, data, function(response) { 
						if (virallocker_use) 
						{ 							
							setTimeout(function() {								
								var _data= jQuery("#couponForm").serialize() + "&action=woocommerce_apply_coupon&security='.wp_create_nonce( "apply-coupon" ).'";
								jQuery.ajax({
								  type: "POST",
								  url: "'.$postURL.'/wp-admin/admin-ajax.php",
								  data:_data,
								  success: function(html){
									 location.reload();
									 //jQuery("#couponForm").submit();
								  }
								});							 
							}, '.$seconds.');
							//jQuery("#couponForm").submit();
							//location.reload();					
						}
					});
					
				});';
		}
		if( $enableTwttr == "enable")	{	
			$html .= 'twttr.ready(function (twttr) {
					twttr.events.bind("tweet", function(event) { 
						var data = { action: "submit", myID: "'.$myid.'"};
						jQuery.post(viralcurrentpageurl, data, function(response) {
						if (virallocker_use) 
						{
							//jQuery("#couponForm").submit();
							var _data= jQuery("#couponForm").serialize() + "&action=woocommerce_apply_coupon&security='.wp_create_nonce( "apply-coupon" ).'";
							jQuery.ajax({
							  type: "POST",
							  url: "'.$postURL.'/wp-admin/admin-ajax.php",
							  data:_data,
							  success: function(html){
								 location.reload();
								 //jQuery("#couponForm").submit();
							  }
							});
						}					
					});
					});
				});';
		}
		$html .= '});
		</script>';
		
		echo $html;
	}
	/** Function to add the required styles and scripts **/
	function add_header() {
		
		$home =  home_url();
	    /** Include the required styles and scripts for the VL script **/
		echo '<style type="text/css">
		.virallocker-box {background-color: #E0ECEF;border: 1px dashed #3B5998;padding: 10px;	color: #000;text-align: left; margin-top: 15px; margin-bottom: 5px;border-radius: 5px;-moz-border-radius: 5px; font-weight: bold;width:330px;float:left;overflow:visible;}
		.virallocker-box-checkout {background-color: #E0ECEF;border: 1px dashed #3B5998;padding: 10px;	color: #000;text-align: left; margin-top: 0px; margin-bottom: 10px;border-radius: 5px;-moz-border-radius: 5px; font-weight: bold;width: 330px;float: left;}
		.virallocker-box  div, .virallocker-box-checkout div {margin-top: 5px;height: 25px;}
		.fb_edge_widget_with_comment span.fb_edge_comment_widget iframe.fb_ltr {display: none !important;}
		.virallocker-box iframe, .virallocker-box-checkout iframe {max-width: 600px !important;}
		.unlocked {text-align:left;position: absolute;padding-top:3px;}
		.unlocked-checkout {text-align:left;/*position: absolute;*/padding-top:13px;}
		.small a {float:left !important;}
		.viralmessage { clear:both; }
		.verticaltwttr, .verticalgplus, .verticalfb { clear: both; }
		.horizontaltwttr { float:left; width:120px; }
		.horizontalgplus { float:left; width:100px;}
		.horizontalfb { float:left;width: 100px; }
		.woocommerce-info { clear:both; }
		@media only screen and (max-width :480px) {
			.virallocker-box-checkout { width: 93%; }
			.virallocker-box { width: 100%; }
			.horizontaltwttr { float:left; width:38%; }
			.horizontalgplus { float:left; width:28%;}
			.horizontalfb { float:left;width: 30%; }
		}
		</style>';
		$options = get_option( 'viralcoupon_options' );
		if( $options != '' )
		{
			$viraloptions = json_decode( $options);
			$enableFB 	  = isset( $viraloptions->enableFB ) ? "enable": "disable";
			$enableTwttr 	  = isset( $viraloptions->enableTwttr ) ? "enable": "disable";
			$enableGo 	  = isset( $viraloptions->enableGo ) ? "enable": "disable";
			
			if(isset($viraloptions->enablehttps) && property_exists($viraloptions,'enablehttps')){
				
				if(!isset($viraloptions->disablejquery) && !property_exists($viraloptions,'disablejquery'))
					echo '<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>';
					
				if( $enableFB == "enable")
					echo '<script type="text/javascript" src="https://connect.facebook.net/en_US/all.js#xfbml=1"></script>';
	
			}
			else{
				if(!isset($viraloptions->disablejquery) && !property_exists($viraloptions,'disablejquery'))
					echo '<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>';
					
				if( $enableFB == "enable")
					echo '<script type="text/javascript" src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>';
			}
			if( $enableFB == "enable")
				echo '<div id="fb-root"></div><script type="text/javascript">FB.XFBML.parse();</script>';
				
			echo "<link rel='stylesheet' href='".plugins_url( 'custom.css', __FILE__ )."' type='text/css' media='all' />";
		}
	}
}
