<?php
$prefix = 'woo_ce';

delete_option( $prefix . '_secret_key' );
?>