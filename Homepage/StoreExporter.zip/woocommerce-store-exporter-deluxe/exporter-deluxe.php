<?php
/*
Plugin Name: WooCommerce - Store Exporter Deluxe
Plugin URI: http://www.visser.com.au/woocommerce/plugins/exporter-deluxe/
Description: Unlocks business focused e-commerce features within Store Exporter for WooCommerce. This Pro ugprade will de-activate the basic Store Exporter Plugin on activation.
Version: 1.8.7
Author: Visser Labs
Author URI: http://www.visser.com.au/about/
License: GPL2
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'WOO_CD_DIRNAME', basename( dirname( __FILE__ ) ) );
define( 'WOO_CD_RELPATH', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );
define( 'WOO_CD_PATH', plugin_dir_path( __FILE__ ) );
define( 'WOO_CD_PREFIX', 'woo_ce' );

// Turn this on to enable additional debugging options at export time
define( 'WOO_CD_DEBUG', false );

// Disable basic Store Exporter if it is activated
include_once( WOO_CD_PATH . 'common/common.php' );
if( defined( 'WOO_CE_PREFIX' ) == true ) {
	// Detect Store Exporter and other platform versions
	include_once( WOO_CD_PATH . 'includes/install.php' );
	woo_cd_detect_ce();
} else {
	include_once( WOO_CD_PATH . 'includes/functions.php' );
}

function woo_cd_i18n() {

	load_plugin_textdomain( 'woo_ce', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

}
add_action( 'init', 'woo_cd_i18n' );

if( is_admin() ) {

	/* Start of: WordPress Administration */

	include_once( WOO_CD_PATH . 'includes/install.php' );
	register_activation_hook( __FILE__, 'woo_cd_install' );
	register_deactivation_hook( __FILE__, 'woo_cd_uninstall' );

	// Initial scripts and export process
	function woo_cd_admin_init() {

		global $export, $wp_roles;

		$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';

		// Time to tell the store owner if we were unable to disable the basic Store Exporter
		if( defined( 'WOO_CE_PREFIX' ) ) {
			// Display notice if we were unable to de-activate basic Store Exporter
			if( ( is_plugin_active( 'woocommerce-exporter/exporter.php' ) || is_plugin_active( 'woocommerce-store-exporter/exporter.php' ) ) && current_user_can( 'activate_plugins' ) ) {
				$plugins_url = add_query_arg( '', '', 'plugins.php' );
				$message = sprintf( __( 'We did our best to de-activate Store Exporter for you but may have failed, please check that the basic Store Exporter is de-activated from the <a href="%s">Plugins screen</a>.', 'woo_ce' ), $plugins_url );
				woo_cd_admin_notice( $message, 'error', array( 'plugins.php', 'update-core.php' ) );
			}
		}

		// Detect if another e-Commerce platform is activated
		if( !woo_is_woo_activated() && ( woo_is_jigo_activated() || woo_is_wpsc_activated() ) ) {
			$message = sprintf( __( 'We have detected another e-Commerce Plugin than WooCommerce activated, please check that you are using Store Exporter Deluxe for the correct platform. <a href="%s" target="_blank">Need help?</a>', 'woo_ce' ), $troubleshooting_url );
			woo_cd_admin_notice( $message, 'error', 'plugins.php' );
		} else if( !woo_is_woo_activated() ) {
			$message = sprintf( __( 'We have been unable to detect the WooCommerce Plugin activated on this WordPress site, please check that you are using Store Exporter Deluxe for the correct platform. <a href="%s" target="_blank">Need help?</a>', 'woo_ce' ), $troubleshooting_url );
			woo_cd_admin_notice( $message, 'error', 'plugins.php' );
		}

		// Detect if WooCommerce Subscriptions Exporter is activated
		if( function_exists( 'wc_subs_exporter_admin_init' ) ) {
			$message = sprintf( __( 'We have detected a WooCommerce Plugin that is activated and known to conflict with Store Exporter Deluxe, please de-activate WooCommerce Subscriptions Exporter to resolve export issues. <a href="%s" target="_blank">Need help?</a>', 'woo_ce' ), $troubleshooting_url );
			woo_cd_admin_notice( $message, 'error', array( 'plugins.php', 'admin.php' ) );
		}

		add_action( 'after_plugin_row_' . WOO_CD_RELPATH, 'woo_ce_admin_plugin_row' );

		if( current_user_can( 'view_woocommerce_reports' ) ) {
			// Load Dashboard widget for Scheduled Exports
			add_action( 'wp_dashboard_setup', 'woo_ce_dashboard_setup' );
			// Load Download buttons for Edit Orders screen
			wp_enqueue_style( 'dashicons' );
			wp_enqueue_style( 'woo_ce_styles', plugins_url( '/templates/admin/export.css', WOO_CD_RELPATH ) );
			add_filter( 'woocommerce_admin_order_actions', 'woo_ce_admin_order_actions', 10, 2 );
			add_action( 'wp_ajax_woo_ce_export_order', 'woo_ce_ajax_export_order' );
			// Add Download as... options to Orders Bulk
			add_action( 'admin_footer', 'woo_ce_admin_order_bulk_actions' );
			add_action( 'load-edit.php', 'woo_ce_admin_order_process_bulk_action' );
			// Add Download as... options to Edit Order Actions
			add_action( 'woocommerce_order_actions', 'woo_ce_admin_order_single_actions' );
			add_action( 'woocommerce_order_action_woo_ce_export_order_csv', 'woo_ce_admin_order_single_export_csv' );
			add_action( 'woocommerce_order_action_woo_ce_export_order_xml', 'woo_ce_admin_order_single_export_xml' );
			add_action( 'woocommerce_order_action_woo_ce_export_order_xls', 'woo_ce_admin_order_single_export_xls' );
		}

		// Check that we are on the Store Exporter screen
		$page = ( isset($_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : false );
		if( $page != strtolower( WOO_CD_PREFIX ) )
			return;

		// Process any pre-export notice confirmations
		$action = woo_get_action();
		switch( $action ) {

			// Prompt on Export screen when insufficient memory (less than 64M is allocated)
			case 'dismiss_memory_prompt':
				woo_ce_update_option( 'dismiss_memory_prompt', 1 );
				$url = add_query_arg( 'action', null );
				wp_redirect( $url );
				exit();
				break;

			// Prompt on Export screen when insufficient memory (less than 64M is allocated)
			case 'dismiss_php_legacy':
				woo_ce_update_option( 'dismiss_php_legacy', 1 );
				$url = add_query_arg( 'action', null );
				wp_redirect( $url );
				exit();
				break;

			// Save skip overview preference
			case 'skip_overview':
				$skip_overview = false;
				if( isset( $_POST['skip_overview'] ) )
					$skip_overview = 1;
				woo_ce_update_option( 'skip_overview', $skip_overview );

				if( $skip_overview == 1 ) {
					$url = add_query_arg( 'tab', 'export' );
					wp_redirect( $url );
					exit();
				}
				break;

			// This is where the magic happens
			case 'export':

				// Set up the basic export options
				$export = new stdClass();
				$export->cron = 0;
				$export->scheduled_export = 0;
				$export->start_time = time();
				$export->idle_memory_start = woo_ce_current_memory_usage();
				$export->delete_file = woo_ce_get_option( 'delete_file', 0 );
				$export->encoding = woo_ce_get_option( 'encoding', get_option( 'blog_charset', 'UTF-8' ) );
				// Reset the Encoding if corrupted
				if( $export->encoding == '' || $export->encoding == false || $export->encoding == 'System default' ) {
					error_log( '[store-exporter-deluxe] Encoding export option was corrupted, defaulted to UTF-8' );
					$export->encoding = 'UTF-8';
					woo_ce_update_option( 'encoding', 'UTF-8' );
				}
				$export->delimiter = woo_ce_get_option( 'delimiter', ',' );
				// Reset the Delimiter if corrupted
				if( $export->delimiter == '' || $export->delimiter == false ) {
					error_log( '[store-exporter-deluxe] Delimiter export option was corrupted, defaulted to ,' );
					$export->delimiter = ',';
					woo_ce_update_option( 'delimiter', ',' );
				}
				$export->category_separator = woo_ce_get_option( 'category_separator', '|' );
				// Reset the Category Separator if corrupted
				if( $export->category_separator == '' || $export->category_separator == false ) {
					error_log( '[store-exporter-deluxe] Category Separator export option was corrupted, defaulted to |' );
					$export->category_separator = '|';
					woo_ce_update_option( 'category_separator', '|' );
				}
				// Override for line break (LF) support in Category Separator
				if( $export->category_separator == 'LF' )
					$export->category_separator = "\n";
				$export->bom = woo_ce_get_option( 'bom', 1 );
				$export->escape_formatting = woo_ce_get_option( 'escape_formatting', 'all' );
				// Reset the Escape Formatting if corrupted
				if( $export->escape_formatting == '' || $export->escape_formatting == false ) {
					error_log( '[store-exporter-deluxe] Escape Formatting export option was corrupted, defaulted to all' );
					$export->escape_formatting = 'all';
					woo_ce_update_option( 'escape_formatting', 'all' );
				}
				$export->header_formatting = woo_ce_get_option( 'header_formatting', 1 );
				$export->date_format = woo_ce_get_option( 'date_format', 'd/m/Y' );
				// Reset the Date Format if corrupted
				if( $export->date_format == '1' || $export->date_format == '' || $export->date_format == false ) {
					error_log( '[store-exporter-deluxe] Date Format export option was corrupted, defaulted to d/m/Y' );
					$export->date_format = 'd/m/Y';
					woo_ce_update_option( 'date_format', 'd/m/Y' );
				}

				// Save export option changes made on the Export screen
				$export->limit_volume = ( isset( $_POST['limit_volume'] ) ? sanitize_text_field( $_POST['limit_volume'] ) : '' );
				woo_ce_update_option( 'limit_volume', $export->limit_volume );
				if( $export->limit_volume == '' )
					$export->limit_volume = -1;
				$export->offset = ( isset( $_POST['offset'] ) ? sanitize_text_field( $_POST['offset'] ) : '' );
				woo_ce_update_option( 'offset', $export->offset );
				if( $export->offset == '' )
					$export->offset = 0;
				woo_ce_update_option( 'export_format', sanitize_text_field( (string)$_POST['export_format'] ) );

				// Set default values for all export options to be later passed onto the export process
				$export->fields = array();
				$export->fields_order = false;
				$export->export_format = woo_ce_get_option( 'export_format', 'csv' );

				// Product sorting
				$export->product_categories = false;
				$export->product_tags = false;
				$export->product_brands = false;
				$export->product_vendors = false;
				$export->product_status = false;
				$export->product_type = false;
				$export->product_stock = false;
				$export->product_orderby = false;
				$export->product_order = false;
				$export->gallery_formatting = false;
				$export->upsell_formatting = false;
				$export->crosssell_formatting = false;
				$export->variation_formatting = false;

				// Category sorting
				$export->category_orderby = false;
				$export->category_order = false;

				// Tag sorting
				$export->tag_orderby = false;
				$export->tag_order = false;

				// Brand sorting
				$export->brand_orderby = false;
				$export->brand_order = false;

				// Order sorting
				$export->order_dates_filter = false;
				$export->order_dates_from = '';
				$export->order_dates_to = '';
				$export->order_dates_filter_variable = false;
				$export->order_dates_filter_variable_length = false;
				$export->order_status = false;
				$export->order_customer = false;
				$export->order_billing_country = false;
				$export->order_shipping_country = false;
				$export->order_user_roles = false;
				$export->order_product = false;
				$export->order_coupons = false;
				$export->order_category = false;
				$export->order_tag = false;
				$export->order_brand = false;
				$export->order_ids = false;
				$export->order_items = 'combined';
				$export->order_items_types = false;
				$export->order_orderby = false;
				$export->order_order = false;
				$export->max_order_items = false;

				// User sorting
				$export->user_orderby = false;
				$export->user_order = false;

				// Coupon sorting
				$export->coupon_orderby = false;
				$export->coupon_order = false;

				// Subscription sorting
				$export->subscription_status = false;
				$export->subscription_product = false;

				// Commission sorting
				$export->commission_dates_filter = false;
				$export->commission_dates_from = '';
				$export->commission_dates_to = '';
				$export->commission_dates_filter_variable = false;
				$export->commission_dates_filter_variable_length = false;
				$export->commission_product_vendors = false;
				$export->commission_status = false;
				$export->commission_orderby = false;
				$export->commission_order = false;

				// Shipping Class sorting
				$export->shipping_class_orderby = false;
				$export->shipping_class_order = false;

				$export->type = ( isset( $_POST['dataset'] ) ? sanitize_text_field( $_POST['dataset'] ) : false );
				if( $export->type ) {
					$export->fields = ( isset( $_POST[$export->type . '_fields'] ) ? array_map( 'sanitize_text_field', $_POST[$export->type . '_fields'] ) : false );
					$export->fields_order = ( isset( $_POST[$export->type . '_fields_order'] ) ? array_map( 'absint', $_POST[$export->type . '_fields_order'] ) : false );
					woo_ce_update_option( 'last_export', $export->type );
				}
				switch( $export->type ) {

					case 'product':
						// Set up dataset specific options
						$export->product_categories = ( isset( $_POST['product_filter_category'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['product_filter_category'] ) ) : false );
						$export->product_tags = ( isset( $_POST['product_filter_tag'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['product_filter_tag'] ) ) : false );
						$export->product_brands = ( isset( $_POST['product_filter_brand'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['product_filter_brand'] ) ) : false );
						$export->product_vendors = ( isset( $_POST['product_filter_vendor'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['product_filter_vendor'] ) ) : false );
						$export->product_status = ( isset( $_POST['product_filter_status'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['product_filter_status'] ) ) : false );
						$export->product_type = ( isset( $_POST['product_filter_type'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['product_filter_type'] ) ) : false );
						$export->product_stock = ( isset( $_POST['product_filter_stock'] ) ? sanitize_text_field( $_POST['product_filter_stock'] ) : false );
						$export->product_orderby = ( isset( $_POST['product_orderby'] ) ? sanitize_text_field( $_POST['product_orderby'] ) : false );
						$export->product_order = ( isset( $_POST['product_order'] ) ? sanitize_text_field( $_POST['product_order'] ) : false );
						$export->gallery_formatting = ( isset( $_POST['product_gallery_formatting'] ) ? absint( $_POST['product_gallery_formatting'] ) : false );
						$export->upsell_formatting = ( isset( $_POST['product_upsell_formatting'] ) ? absint( $_POST['product_upsell_formatting'] ) : false );
						$export->crosssell_formatting = ( isset( $_POST['product_crosssell_formatting'] ) ? absint( $_POST['product_crosssell_formatting'] ) : false );
						$export->variation_formatting = ( isset( $_POST['variation_formatting'] ) ? absint( $_POST['variation_formatting'] ) : false );

						// Save dataset export specific options
						if( $export->product_orderby <> woo_ce_get_option( 'product_orderby' ) )
							woo_ce_update_option( 'product_orderby', $export->product_orderby );
						if( $export->product_order <> woo_ce_get_option( 'product_order' ) )
							woo_ce_update_option( 'product_order', $export->product_order );
						if( $export->upsell_formatting <> woo_ce_get_option( 'upsell_formatting' ) )
							woo_ce_update_option( 'upsell_formatting', $export->upsell_formatting );
						if( $export->crosssell_formatting <> woo_ce_get_option( 'crosssell_formatting' ) )
							woo_ce_update_option( 'crosssell_formatting', $export->crosssell_formatting );
						if( $export->variation_formatting <> woo_ce_get_option( 'variation_formatting' ) )
							woo_ce_update_option( 'variation_formatting', $export->variation_formatting );
						if( $export->gallery_formatting <> woo_ce_get_option( 'gallery_formatting' ) )
							woo_ce_update_option( 'gallery_formatting', $export->gallery_formatting );
						break;

					case 'category':
						// Set up dataset specific options
						$export->category_orderby = ( isset( $_POST['category_orderby'] ) ? sanitize_text_field( $_POST['category_orderby'] ) : false );
						$export->category_order = ( isset( $_POST['category_order'] ) ? sanitize_text_field( $_POST['category_order'] ) : false );

						// Save dataset export specific options
						if( $export->category_orderby <> woo_ce_get_option( 'category_orderby' ) )
							woo_ce_update_option( 'category_orderby', $export->category_orderby );
						if( $export->category_order <> woo_ce_get_option( 'category_order' ) )
							woo_ce_update_option( 'category_order', $export->category_order );
						break;

					case 'tag':
						// Set up dataset specific options
						$export->tag_orderby = ( isset( $_POST['tag_orderby'] ) ? sanitize_text_field( $_POST['tag_orderby'] ) : false );
						$export->tag_order = ( isset( $_POST['tag_order'] ) ? sanitize_text_field( $_POST['tag_order'] ) : false );

						// Save dataset export specific options
						if( $export->tag_orderby <> woo_ce_get_option( 'tag_orderby' ) )
							woo_ce_update_option( 'tag_orderby', $export->tag_orderby );
						if( $export->tag_order <> woo_ce_get_option( 'tag_order' ) )
							woo_ce_update_option( 'tag_order', $export->tag_order );
						break;

					case 'brand':
						// Set up dataset specific options
						$export->brand_orderby = ( isset( $_POST['brand_orderby'] ) ? sanitize_text_field( $_POST['brand_orderby'] ) : false );
						$export->brand_order = ( isset( $_POST['brand_order'] ) ? sanitize_text_field( $_POST['brand_order'] ) : false );

						// Save dataset export specific options
						if( $export->brand_orderby <> woo_ce_get_option( 'brand_orderby' ) )
							woo_ce_update_option( 'brand_orderby', $export->brand_orderby );
						if( $export->brand_order <> woo_ce_get_option( 'brand_order' ) )
							woo_ce_update_option( 'brand_order', $export->brand_order );
						break;

					case 'order':
						// Set up dataset specific options
						$export->order_dates_filter = ( isset( $_POST['order_dates_filter'] ) ? sanitize_text_field( $_POST['order_dates_filter'] ) : false );
						$export->order_dates_from = sanitize_text_field( $_POST['order_dates_from'] );
						$export->order_dates_to = sanitize_text_field( $_POST['order_dates_to'] );
						$export->order_dates_filter_variable = ( isset( $_POST['order_dates_filter_variable'] ) ? absint( $_POST['order_dates_filter_variable'] ) : false );
						$export->order_dates_filter_variable_length = ( isset( $_POST['order_dates_filter_variable_length'] ) ? sanitize_text_field( $_POST['order_dates_filter_variable_length'] ) : false );
						$export->order_status = ( isset( $_POST['order_filter_status'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['order_filter_status'] ) ) : false );
						$export->order_customer = ( isset( $_POST['order_filter_customer'] ) ? absint( $_POST['order_filter_customer'] ) : false );
						$export->order_billing_country = ( isset( $_POST['order_filter_billing_country'] ) ? sanitize_text_field( $_POST['order_filter_billing_country'] ) : false );
						$export->order_shipping_country = ( isset( $_POST['order_filter_shipping_country'] ) ? sanitize_text_field( $_POST['order_filter_shipping_country'] ) : false );
						$export->order_user_roles = ( isset( $_POST['order_filter_user_role'] ) ? woo_ce_format_user_role_filters( array_map( 'sanitize_text_field', $_POST['order_filter_user_role'] ) ) : false );
						$export->order_coupons = ( isset( $_POST['order_filter_coupon'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['order_filter_coupon'] ) ) : false );
						$export->order_product = ( isset( $_POST['order_filter_product'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['order_filter_product'] ) ) : false );
						$export->order_category = ( isset( $_POST['order_filter_category'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['order_filter_category'] ) ) : false );
						$export->order_tag = ( isset( $_POST['order_filter_tag'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['order_filter_tag'] ) ) : false );
						$export->order_brand = ( isset( $_POST['order_filter_brand'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['order_filter_brand'] ) ) : false );
						$export->order_ids = ( isset( $_POST['order_filter_id'] ) ? sanitize_text_field( $_POST['order_filter_id'] ) : false );
						$export->order_orderby = ( isset( $_POST['order_orderby'] ) ? sanitize_text_field( $_POST['order_orderby'] ) : false );
						$export->order_order = ( isset( $_POST['order_order'] ) ? sanitize_text_field( $_POST['order_order'] ) : false );

						// Save dataset export specific options
						if( isset( $_POST['order_items'] ) ) {
							$export->order_items = sanitize_text_field( $_POST['order_items'] );
							if( $export->order_items <> woo_ce_get_option( 'order_items_formatting' ) )
								woo_ce_update_option( 'order_items_formatting', $export->order_items );
						}
						if( isset( $_POST['order_items_types'] ) ) {
							$export->order_items_types = array_map( 'sanitize_text_field', $_POST['order_items_types'] );
							if( $export->order_items_types <> woo_ce_get_option( 'order_items_types' ) )
								woo_ce_update_option( 'order_items_types', $export->order_items_types );
						}
						if( isset( $_POST['max_order_items'] ) ) {
							$export->max_order_items = absint( (int)$_POST['max_order_items'] );
							if( $export->max_order_items <> woo_ce_get_option( 'max_order_items' ) )
								woo_ce_update_option( 'max_order_items', $export->max_order_items );
						}
						if( $export->order_orderby <> woo_ce_get_option( 'order_orderby' ) )
							woo_ce_update_option( 'order_orderby', $export->order_orderby );
						if( $export->order_order <> woo_ce_get_option( 'order_order' ) )
							woo_ce_update_option( 'order_order', $export->order_order );
						break;

					case 'customer':
						// Set up dataset specific options

						// Save dataset export specific options
						$export->order_status = ( isset( $_POST['customer_filter_status'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['customer_filter_status'] ) ) : false );
						$export->order_user_roles = ( isset( $_POST['customer_filter_user_role'] ) ? woo_ce_format_user_role_filters( array_map( 'sanitize_text_field', $_POST['customer_filter_user_role'] ) ) : false );
						break;

					case 'user':
						// Set up dataset specific options
						$export->user_orderby = ( isset( $_POST['user_orderby'] ) ? sanitize_text_field( $_POST['user_orderby'] ) : false );
						$export->user_order = ( isset( $_POST['user_order'] ) ? sanitize_text_field( $_POST['user_order'] ) : false );

						// Save dataset export specific options
						if( $export->user_orderby <> woo_ce_get_option( 'user_orderby' ) )
							woo_ce_update_option( 'user_orderby', $export->user_orderby );
						if( $export->user_order <> woo_ce_get_option( 'user_order' ) )
							woo_ce_update_option( 'user_order', $export->user_order );
						break;

					case 'coupon':
						// Set up dataset specific options
						$export->coupon_orderby = ( isset( $_POST['coupon_orderby'] ) ? sanitize_text_field( $_POST['coupon_orderby'] ) : false );
						$export->coupon_order = ( isset( $_POST['coupon_order'] ) ? sanitize_text_field( $_POST['coupon_order'] ) : false );

						// Save dataset export specific options
						if( $export->coupon_orderby <> woo_ce_get_option( 'coupon_orderby' ) )
							woo_ce_update_option( 'coupon_orderby', $export->coupon_orderby );
						if( $export->coupon_order <> woo_ce_get_option( 'coupon_order' ) )
							woo_ce_update_option( 'coupon_order', $export->coupon_order );
						break;

					case 'subscription':
						// Set up dataset specific options

						// Save dataset export specific options
						$export->subscription_status = ( isset( $_POST['subscription_filter_status'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['subscription_filter_status'] ) ) : false );
						$export->subscription_product = ( isset( $_POST['subscription_filter_product'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['subscription_filter_product'] ) ) : false );
						break;

					case 'attribute':
						break;

					case 'product_vendor':
						break;

					case 'commission':
						$export->commission_dates_filter = ( isset( $_POST['commission_dates_filter'] ) ? sanitize_text_field( $_POST['commission_dates_filter'] ) : false );
						$export->commission_dates_from = sanitize_text_field( $_POST['commission_dates_from'] );
						$export->commission_dates_to = sanitize_text_field( $_POST['commission_dates_to'] );
						$export->commission_dates_filter_variable = ( isset( $_POST['commission_dates_filter_variable'] ) ? absint( $_POST['commission_dates_filter_variable'] ) : false );
						$export->commission_dates_filter_variable_length = ( isset( $_POST['commission_dates_filter_variable_length'] ) ? sanitize_text_field( $_POST['commission_dates_filter_variable_length'] ) : false );
						$export->commission_product_vendors = ( isset( $_POST['commission_filter_product_vendor'] ) ? woo_ce_format_product_filters( array_map( 'absint', $_POST['commission_filter_product_vendor'] ) ) : false );
						$export->commission_status = ( isset( $_POST['commission_filter_commission_status'] ) ? woo_ce_format_product_filters( array_map( 'sanitize_text_field', $_POST['commission_filter_commission_status'] ) ) : false );
						$export->commission_orderby = ( isset( $_POST['commission_orderby'] ) ? sanitize_text_field( $_POST['commission_orderby'] ) : false );
						$export->commission_order = ( isset( $_POST['commission_order'] ) ? sanitize_text_field( $_POST['commission_order'] ) : false );

						// Save dataset export specific options
						if( $export->commission_orderby <> woo_ce_get_option( 'commission_orderby' ) )
							woo_ce_update_option( 'commission_orderby', $export->commission_orderby );
						if( $export->commission_order <> woo_ce_get_option( 'commission_order' ) )
							woo_ce_update_option( 'commission_order', $export->commission_order );
						break;

					case 'shipping_class':
						// Set up dataset specific options
						$export->shipping_class_orderby = ( isset( $_POST['shipping_class_orderby'] ) ? sanitize_text_field( $_POST['shipping_class_orderby'] ) : false );
						$export->shipping_class_order = ( isset( $_POST['shipping_class_order'] ) ? sanitize_text_field( $_POST['shipping_class_order'] ) : false );

						// Save dataset export specific options
						if( $export->shipping_class_orderby <> woo_ce_get_option( 'shipping_class_orderby' ) )
							woo_ce_update_option( 'shipping_class_orderby', $export->shipping_class_orderby );
						if( $export->shipping_class_order <> woo_ce_get_option( 'shipping_class_order' ) )
							woo_ce_update_option( 'shipping_class_order', $export->shipping_class_order );
						break;

				}
				if( $export->type ) {

					$timeout = 600;
					if( isset( $_POST['timeout'] ) ) {
						$timeout = absint( (int)$_POST['timeout'] );
						if( $timeout <> woo_ce_get_option( 'timeout' ) )
							woo_ce_update_option( 'timeout', $timeout );
					}
					if( !ini_get( 'safe_mode' ) )
						@set_time_limit( (int)$timeout );

					@ini_set( 'memory_limit', WP_MAX_MEMORY_LIMIT );
					@ini_set( 'max_execution_time', (int)$timeout );

					$export->args = array(
						'limit_volume' => $export->limit_volume,
						'offset' => $export->offset,
						'encoding' => $export->encoding,
						'date_format' => $export->date_format,
						'product_categories' => $export->product_categories,
						'product_tags' => $export->product_tags,
						'product_brands' => $export->product_brands,
						'product_vendors' => $export->product_vendors,
						'product_status' => $export->product_status,
						'product_type' => $export->product_type,
						'product_stock' => $export->product_stock,
						'product_orderby' => $export->product_orderby,
						'product_order' => $export->product_order,
						'category_orderby' => $export->category_orderby,
						'category_order' => $export->category_order,
						'tag_orderby' => $export->tag_orderby,
						'tag_order' => $export->tag_order,
						'brand_orderby' => $export->brand_orderby,
						'brand_order' => $export->brand_order,
						'order_status' => $export->order_status,
						'order_dates_filter' => $export->order_dates_filter,
						'order_dates_from' => woo_ce_format_order_date( $export->order_dates_from ),
						'order_dates_to' => woo_ce_format_order_date( $export->order_dates_to ),
						'order_dates_filter_variable' => $export->order_dates_filter_variable,
						'order_dates_filter_variable_length' => $export->order_dates_filter_variable_length,
						'order_customer' => ( !empty( $export->order_customer ) && woo_ce_return_count( 'users' ) < 1000 ? $export->order_customer : explode( ',', $export->order_customer ) ),
						'order_billing_country' => $export->order_billing_country,
						'order_shipping_country' => $export->order_shipping_country,
						'order_user_roles' => $export->order_user_roles,
						'order_coupons' => $export->order_coupons,
						'order_product' => $export->order_product,
						'order_category' => $export->order_category,
						'order_tag' => $export->order_tag,
						'order_brand' => $export->order_brand,
						'order_ids' => $export->order_ids,
						'order_items' => $export->order_items,
						'order_items_types' => $export->order_items_types,
						'order_orderby' => $export->order_orderby,
						'order_order' => $export->order_order,
						'user_orderby' => $export->user_orderby,
						'user_order' => $export->user_order,
						'coupon_orderby' => $export->coupon_orderby,
						'coupon_order' => $export->coupon_order,
						'subscription_status' => $export->subscription_status,
						'subscription_product' => $export->subscription_product,
						'commission_dates_filter' => $export->commission_dates_filter,
						'commission_dates_from' => woo_ce_format_order_date( $export->commission_dates_from ),
						'commission_dates_to' => woo_ce_format_order_date( $export->commission_dates_to ),
						'commission_dates_filter_variable' => $export->commission_dates_filter_variable,
						'commission_dates_filter_variable_length' => $export->commission_dates_filter_variable_length,
						'commission_product_vendors' => $export->commission_product_vendors,
						'commission_status' => $export->commission_status,
						'commission_orderby' => $export->commission_orderby,
						'commission_order' => $export->commission_order,
						'shipping_class_orderby' => $export->shipping_class_orderby,
						'shipping_class_order' => $export->shipping_class_order
					);
					woo_ce_save_fields( $export->type, $export->fields, $export->fields_order );

					if( $export->export_format == 'csv' ) {
						$export->filename = woo_ce_generate_csv_filename( $export->type );
					} else if( $export->export_format == 'xml' ) {
						$export->filename = woo_ce_generate_xml_filename( $export->type );
					} else if( $export->export_format == 'xls' ) {
						// Override the encoding type
						// $export->encoding = 'UTF-16LE';
						$export->filename = woo_ce_generate_xls_filename( $export->type );
						$export->delimiter = "\t";
					}

					// Print file contents to debug export screen
					if( WOO_CD_DEBUG ) {

						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
							woo_ce_export_dataset( $export->type );
						} else if( $export->export_format == 'xml' ) {
							if( class_exists( 'SimpleXMLElement' ) ) {
								$xml = new SimpleXMLElement( sprintf( '<?xml version="1.0" encoding="%s"?><store/>', $export->encoding ) );
								if( woo_ce_get_option( 'xml_attribute_url', 1 ) )
									$xml->addAttribute( 'url', get_site_url() );
								if( woo_ce_get_option( 'xml_attribute_date', 1 ) )
									$xml->addAttribute( 'date', date( 'Y-m-d' ) );
								if( woo_ce_get_option( 'xml_attribute_time', 0 ) )
									$xml->addAttribute( 'time', date( 'H:i:s' ) );
								if( woo_ce_get_option( 'xml_attribute_title', 1 ) )
									$xml->addAttribute( 'name', htmlspecialchars( get_bloginfo( 'name' ) ) );
								if( woo_ce_get_option( 'xml_attribute_export', 1 ) )
									$xml->addAttribute( 'export', htmlspecialchars( $export->type ) );
								if( woo_ce_get_option( 'xml_attribute_orderby', 1 ) )
									$xml->addAttribute( 'orderby', $export->{$export->type . '_orderby'} );
								if( woo_ce_get_option( 'xml_attribute_order', 1 ) )
									$xml->addAttribute( 'order', $export->{$export->type . '_order'} );
								if( woo_ce_get_option( 'xml_attribute_limit', 1 ) )
									$xml->addAttribute( 'liimit', $export->limit_volume );
							} else {
								$xml = false;
							}
							woo_ce_export_dataset( $export->type, $xml );
						}
						$export->idle_memory_end = woo_ce_current_memory_usage();
						$export->end_time = time();

					// Print file contents to browser
					} else {
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {

							// Generate CSV contents
							$bits = woo_ce_export_dataset( $export->type );
							unset( $export->fields );
							if( !$bits ) {
								$message = __( 'No export entries were found, please try again with different export filters.', 'woo_ce' );
								woo_cd_admin_notice( $message, 'error' );
								return;
							}
							if( $export->delete_file ) {

								// Print to browser
								if( $export->export_format == 'csv' )
									woo_ce_generate_csv_header( $export->type );
								else if( $export->export_format == 'xls' )
									woo_ce_generate_xls_header( $export->type );
								echo $bits;
								exit();

							} else {

								// Save to file and insert to WordPress Media
								if( $export->filename && $bits ) {
									$post_ID = false;
									if( $export->export_format == 'csv' )
										$post_ID = woo_ce_save_file_attachment( $export->filename, 'text/csv' );
									else if( $export->export_format == 'xls' )
										$post_ID = woo_ce_save_file_attachment( $export->filename, 'application/vnd.ms-excel' );
									$upload = wp_upload_bits( $export->filename, null, $bits );
									if( ( $post_ID == false ) || $upload['error'] ) {
										wp_delete_attachment( $post_ID, true );
										if( isset( $upload['error'] ) )
											wp_redirect( add_query_arg( array( 'failed' => true, 'message' => urlencode( $upload['error'] ) ) ) );
										else
											wp_redirect( add_query_arg( array( 'failed' => true ) ) );
										return;
									}
									$attach_data = wp_generate_attachment_metadata( $post_ID, $upload['file'] );
									wp_update_attachment_metadata( $post_ID, $attach_data );
									update_attached_file( $post_ID, $upload['file'] );
									if( $post_ID ) {
										woo_ce_save_file_guid( $post_ID, $export->type, $upload['url'] );
										woo_ce_save_file_details( $post_ID );
									}
									$export_format = $export->export_format;
									$export_type = $export->type;
									unset( $export );

									// The end memory usage and time is collected at the very last opportunity prior to the CSV header being rendered to the screen
									woo_ce_update_file_detail( $post_ID, '_woo_idle_memory_end', woo_ce_current_memory_usage() );
									woo_ce_update_file_detail( $post_ID, '_woo_end_time', time() );

									// Generate CSV header
									if( $export_format == 'csv' )
										woo_ce_generate_csv_header( $export_type );
									else if( $export_format == 'xls' )
										woo_ce_generate_xls_header( $export_type );
									unset( $export_format, $export_type );

									// Print file contents to screen
									if( $upload['file'] )
										readfile( $upload['file'] );
									else
										wp_redirect( add_query_arg( 'failed', true ) );
									unset( $upload );
								} else {
									wp_redirect( add_query_arg( 'failed', true ) );
								}
								exit();

							}

						} else if( $export->export_format == 'xml' ) {

							if( class_exists( 'SimpleXMLElement' ) ) {
								$xml = new SimpleXMLElement( sprintf( '<?xml version="1.0" encoding="%s"?><store/>', $export->encoding ) );
								if( woo_ce_get_option( 'xml_attribute_url', 1 ) )
									$xml->addAttribute( 'url', get_site_url() );
								if( woo_ce_get_option( 'xml_attribute_date', 1 ) )
									$xml->addAttribute( 'date', date( 'Y-m-d' ) );
								if( woo_ce_get_option( 'xml_attribute_time', 0 ) )
									$xml->addAttribute( 'time', date( 'H:i:s' ) );
								if( woo_ce_get_option( 'xml_attribute_title', 1 ) )
									$xml->addAttribute( 'name', htmlspecialchars( get_bloginfo( 'name' ) ) );
								if( woo_ce_get_option( 'xml_attribute_export', 1 ) )
									$xml->addAttribute( 'export', htmlspecialchars( $export->type ) );
							} else {
								$xml = false;
							}

							// Generate XML contents
							$bits = woo_ce_export_dataset( $export->type, $xml );
							unset( $export->fields );
							if( !$bits ) {
								$message = __( 'No export entries were found, please try again with different export filters.', 'woo_ce' );
								woo_cd_admin_notice( $message, 'error' );
								return;
							}
							if( $export->delete_file ) {

								// Print to browser
								woo_ce_generate_xml_header( $export->type );
								if( $bits = woo_ce_format_xml( $bits ) )
									echo $bits;
								exit();

							} else {

								// Save to file and insert to WordPress Media
								if( $export->filename && $bits ) {
									$post_ID = woo_ce_save_file_attachment( $export->filename, 'xml/application' );
									$bits = woo_ce_format_xml( $bits );
									$upload = wp_upload_bits( $export->filename, null, $bits );
									if( ( $post_ID == false ) || $upload['error'] ) {
										wp_delete_attachment( $post_ID, true );
										if( isset( $upload['error'] ) )
											wp_redirect( add_query_arg( array( 'failed' => true, 'message' => urlencode( $upload['error'] ) ) ) );
										else
											wp_redirect( add_query_arg( array( 'failed' => true ) ) );
										return;
									}
									$attach_data = wp_generate_attachment_metadata( $post_ID, $upload['file'] );
									wp_update_attachment_metadata( $post_ID, $attach_data );
									update_attached_file( $post_ID, $upload['file'] );
									if( $post_ID ) {
										woo_ce_save_file_guid( $post_ID, $export->type, $upload['url'] );
										woo_ce_save_file_details( $post_ID );
									}
									$export_type = $export->type;
									unset( $export );

									// The end memory usage and time is collected at the very last opportunity prior to the XML header being rendered to the screen
									woo_ce_update_file_detail( $post_ID, '_woo_idle_memory_end', woo_ce_current_memory_usage() );
									woo_ce_update_file_detail( $post_ID, '_woo_end_time', time() );

									// Generate XML header
									woo_ce_generate_xml_header( $export_type );
									unset( $export_type );

									// Print file contents to screen
									if( $upload['file'] )
										readfile( $upload['file'] );
									else
										wp_redirect( add_query_arg( 'failed', true ) );
									unset( $upload );
								} else {
									wp_redirect( add_query_arg( 'failed', true ) );
								}

							}

						}
						exit();
					}
				}
				break;

			// Save changes on Settings screen
			case 'save-settings':
				// Sanitize each setting field as needed

				// Strip file extension from export filename
				$export_filename = strip_tags( (string)$_POST['export_filename'] );
				if( ( strpos( $export_filename, '.csv' ) !== false ) || ( strpos( $export_filename, '.xml' ) !== false ) || ( strpos( $export_filename, '.xls' ) !== false ) )
					$export_filename = str_replace( array( '.csv', '.xml', '.xls' ), '', $export_filename );
				woo_ce_update_option( 'export_filename', $export_filename );
				woo_ce_update_option( 'delete_file', sanitize_text_field( (int)$_POST['delete_file'] ) );
				woo_ce_update_option( 'encoding', sanitize_text_field( (string)$_POST['encoding'] ) );
				woo_ce_update_option( 'delimiter', sanitize_text_field( (string)$_POST['delimiter'] ) );
				woo_ce_update_option( 'category_separator', sanitize_text_field( (string)$_POST['category_separator'] ) );
				woo_ce_update_option( 'bom', absint( (int)$_POST['bom'] ) );
				woo_ce_update_option( 'escape_formatting', sanitize_text_field( (string)$_POST['escape_formatting'] ) );
				woo_ce_update_option( 'header_formatting', sanitize_text_field( (int)$_POST['header_formatting'] ) );
				if( $_POST['date_format'] == 'custom' && !empty( $_POST['date_format_custom'] ) )
					woo_ce_update_option( 'date_format', sanitize_text_field( (string)$_POST['date_format_custom'] ) );
				else
					woo_ce_update_option( 'date_format', sanitize_text_field( (string)$_POST['date_format'] ) );
				woo_ce_update_option( 'email_to', sanitize_text_field( (string)$_POST['email_to'] ) );
				woo_ce_update_option( 'post_to', sanitize_text_field( (string)$_POST['post_to'] ) );

				// XML settings
				woo_ce_update_option( 'xml_attribute_url', ( isset( $_POST['xml_attribute_url'] ) ? absint( (int)$_POST['xml_attribute_url'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_title', ( isset( $_POST['xml_attribute_title'] ) ? absint( (int)$_POST['xml_attribute_title'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_date', ( isset( $_POST['xml_attribute_date'] ) ? absint( (int)$_POST['xml_attribute_date'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_time', ( isset( $_POST['xml_attribute_time'] ) ? absint( (int)$_POST['xml_attribute_time'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_export', ( isset( $_POST['xml_attribute_export'] ) ? absint( (int)$_POST['xml_attribute_export'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_orderby', ( isset( $_POST['xml_attribute_orderby'] ) ? absint( (int)$_POST['xml_attribute_orderby'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_order', ( isset( $_POST['xml_attribute_order'] ) ? absint( (int)$_POST['xml_attribute_order'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_limit', ( isset( $_POST['xml_attribute_limit'] ) ? absint( (int)$_POST['xml_attribute_limit'] ) : 0 ) );
				woo_ce_update_option( 'xml_attribute_offset', ( isset( $_POST['xml_attribute_offset'] ) ? absint( (int)$_POST['xml_attribute_offset'] ) : 0 ) );

				// Scheduled export settings
				$enable_auto = absint( (int)$_POST['enable_auto'] );
				$auto_interval = absint( (int)$_POST['auto_interval'] );
				// Display additional notice if Enabled Scheduled Exports is enabled/disabled
				if( woo_ce_get_option( 'enable_auto', 0 ) <> $enable_auto || woo_ce_get_option( 'auto_interval', 0 ) <> $auto_interval ) {
					// Remove from WP-CRON schedule if disabled
					if( $enable_auto == 0 )
						woo_ce_cron_activation();
					else if( woo_ce_get_option( 'auto_interval', 0 ) <> $auto_interval )
						woo_ce_cron_activation( true );
					$message = sprintf( __( 'Scheduled exports has been %s.', 'woo_ce' ), ( ( $enable_auto == 1 ) ? sprintf( __( 'activated, next scheduled export will run in %d minute(s)', 'woo_ce' ), $auto_interval ) : __( 'de-activated, no further automated exports will occur', 'woo_ce' ) ) );
					woo_cd_admin_notice( $message );
				}
				woo_ce_update_option( 'enable_auto', $enable_auto );
				woo_ce_update_option( 'auto_type', sanitize_text_field( (string)$_POST['auto_type'] ) );
				woo_ce_update_option( 'auto_product_type', ( isset( $_POST['product_filter_type'] ) ? array_map( 'sanitize_text_field', $_POST['product_filter_type'] ) : array() ) );
				woo_ce_update_option( 'auto_product_stock', sanitize_text_field( (string)$_POST['product_filter_stock'] ) );
				woo_ce_update_option( 'auto_product_category', ( isset( $_POST['product_filter_category'] ) ? array_map( 'absint', $_POST['product_filter_category'] ) : array() ) );
				woo_ce_update_option( 'auto_product_tag', ( isset( $_POST['product_filter_tag'] ) ? array_map( 'absint', $_POST['product_filter_tag'] ) : array() ) );
				woo_ce_update_option( 'auto_order_status', sanitize_text_field( (string)$_POST['order_filter_status'] ) );
				woo_ce_update_option( 'auto_order_date', sanitize_text_field( (string)$_POST['order_dates_filter'] ) );
				woo_ce_update_option( 'auto_order_dates_from', sanitize_text_field( (string)$_POST['order_dates_from'] ) );
				woo_ce_update_option( 'auto_order_dates_to', sanitize_text_field( (string)$_POST['order_dates_to'] ) );
				woo_ce_update_option( 'auto_order_date_variable', sanitize_text_field( (string)$_POST['order_dates_filter_variable'] ) );
				woo_ce_update_option( 'auto_order_date_variable_length', sanitize_text_field( (string)$_POST['order_dates_filter_variable_length'] ) );
				woo_ce_update_option( 'auto_interval', $auto_interval );
				woo_ce_update_option( 'auto_format', sanitize_text_field( (string)$_POST['auto_format'] ) );
				woo_ce_update_option( 'auto_method', sanitize_text_field( (string)$_POST['auto_method'] ) );
				woo_ce_update_option( 'auto_ftp_method_host', sanitize_text_field( $_POST['ftp_method_host'] ) );
				woo_ce_update_option( 'auto_ftp_method_user', sanitize_text_field( $_POST['ftp_method_user'] ) );
				// Update FTP password only if it is set
				if( !empty( $_POST['ftp_method_pass'] ) )
					woo_ce_update_option( 'auto_ftp_method_pass', sanitize_text_field( $_POST['ftp_method_pass'] ) );
				woo_ce_update_option( 'auto_ftp_method_port', sanitize_text_field( $_POST['ftp_method_port'] ) );
				woo_ce_update_option( 'auto_ftp_method_path', sanitize_text_field( $_POST['ftp_method_path'] ) );
				woo_ce_update_option( 'auto_ftp_method_passive', sanitize_text_field( $_POST['ftp_method_passive'] ) );
				woo_ce_update_option( 'auto_ftp_method_timeout', sanitize_text_field( $_POST['ftp_method_timeout'] ) );
				woo_ce_update_option( 'scheduled_fields', sanitize_text_field( (string)$_POST['scheduled_fields'] ) );

				// CRON settings
				$enable_cron = absint( (int)$_POST['enable_cron'] );
				// Display additional notice if Enabled CRON is enabled/disabled
				if( woo_ce_get_option( 'enable_cron', 0 ) <> $enable_cron ) {
					$message = sprintf( __( 'CRON support has been %s.', 'woo_ce' ), ( ( $enable_cron == 1 ) ? __( 'enabled', 'woo_ce' ) : __( 'disabled', 'woo_ce' ) ) );
					woo_cd_admin_notice( $message );
				}
				woo_ce_update_option( 'enable_cron', $enable_cron );
				woo_ce_update_option( 'secret_key', sanitize_text_field( (string)$_POST['secret_key'] ) );
				woo_ce_update_option( 'cron_fields', sanitize_text_field( (string)$_POST['cron_fields'] ) );

				$message = __( 'Changes have been saved.', 'woo_ce' );
				woo_cd_admin_notice( $message );
				break;

			// Save changes on Field Editor screen
			case 'save-fields':
				$fields = ( isset( $_POST['fields'] ) ? array_filter( $_POST['fields'] ) : array() );
				$types = array_keys( woo_ce_return_export_types() );
				$export_type = ( isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '' );
				if( in_array( $export_type, $types ) ) {
					woo_ce_update_option( $export_type . '_labels', $fields );
					$message = __( 'Changes have been saved.', 'woo_ce' );
					woo_cd_admin_notice( $message );
				} else {
					$message = __( 'Changes could not be saved.', 'woo_ce' );
					woo_cd_admin_notice( $message, 'error' );
				}
				break;

		}

	}
	add_action( 'admin_init', 'woo_cd_admin_init', 11 );

	// HTML templates and form processor for Store Exporter Deluxe screen
	function woo_cd_html_page() {

		global $wpdb, $export;

		$title = apply_filters( 'woo_ce_template_header', __( 'Store Exporter Deluxe', 'woo_ce' ) );
		woo_cd_template_header( $title );
		$action = woo_get_action();
		switch( $action ) {

			case 'export':
				if( WOO_CD_DEBUG ) {
					if( false === ( $export_log = get_transient( WOO_CD_PREFIX . '_debug_log' ) ) ) {
						$export_log = __( 'No export entries were found, please try again with different export filters.', 'woo_ce' );
					} else {
						$export_log = base64_decode( $export_log );
					}
					delete_transient( WOO_CD_PREFIX . '_debug_log' );
					$output = '
<h3>' . sprintf( __( 'Export Details: %s', 'woo_ce' ), esc_attr( $export->filename ) ) . '</h3>
<p>' . __( 'This prints the $export global that contains the different export options and filters to help reproduce this on another instance of WordPress. Very useful for debugging blank or unexpected exports.', 'woo_ce' ) . '</p>
<textarea id="export_log">' . esc_textarea( print_r( $export, true ) ) . '</textarea>
<hr />';
					if( in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
						$output .= '
<script>
	$j(function() {
		$j(\'#export_sheet\').CSVToTable(\'\', { 
			startLine: 0';
						if( $export->export_format == 'xls' ) {
							$output .= ',
			separator: "\t"';
						}
						$output .= '
		});
	});
</script>
<h3>' . __( 'Export', 'woo_ce' ) . '</h3>
<p>' . __( 'We use the <a href="http://code.google.com/p/jquerycsvtotable/" target="_blank"><em>CSV to Table plugin</em></a> to see first hand formatting errors or unexpected values within the export file.', 'woo_ce' ) . '</p>
<div id="export_sheet">' . esc_textarea( $export_log ) . '</div>
<p class="description">' . __( 'This jQuery plugin can fail with <code>\'Item count (#) does not match header count\'</code> notices which simply mean the number of headers detected does not match the number of cell contents.', 'woo_ce' ) . '</p>
<hr />';
					}
					$output .= '
<h3>' . __( 'Export Log', 'woo_ce' ) . '</h3>
<p>' . __( 'This prints the raw export contents and is helpful when the jQuery plugin above fails due to major formatting errors.', 'woo_ce' ) . '</p>
<textarea id="export_log" wrap="off">' . esc_textarea( $export_log ) . '</textarea>
<hr />
';
					echo $output;
				}

				woo_cd_manage_form();
				break;

			case 'update':
				// Save Custom Product Meta
				if( isset( $_POST['custom_products'] ) ) {
					$custom_products = $_POST['custom_products'];
					$custom_products = explode( "\n", trim( $custom_products ) );
					$size = count( $custom_products );
					if( $size ) {
						for( $i = 0; $i < $size; $i++ )
							$custom_products[$i] = sanitize_text_field( trim( $custom_products[$i] ) );
						woo_ce_update_option( 'custom_products', $custom_products );
					}
				}

				// Save Custom Order Meta
				if( isset( $_POST['custom_orders'] ) ) {
					$custom_orders = $_POST['custom_orders'];
					$custom_orders = explode( "\n", trim( $custom_orders ) );
					$size = count( $custom_orders );
					if( $size ) {
						for( $i = 0; $i < $size; $i++ )
							$custom_orders[$i] = sanitize_text_field( trim( $custom_orders[$i] ) );
						woo_ce_update_option( 'custom_orders', $custom_orders );
					}
				}

				// Save Custom Order Item Meta
				if( isset( $_POST['custom_order_items'] ) ) {
					$custom_order_items = $_POST['custom_order_items'];
					if( !empty( $custom_order_items ) ) {
						$custom_order_items = explode( "\n", trim( $custom_order_items ) );
						$size = count( $custom_order_items );
						if( $size ) {
							for( $i = 0; $i < $size; $i++ )
								$custom_order_items[$i] = sanitize_text_field( trim( $custom_order_items[$i] ) );
							woo_ce_update_option( 'custom_order_items', $custom_order_items );
						}
					} else {
						woo_ce_update_option( 'custom_order_items', '' );
					}
				}

				// Save Custom User Meta
				if( isset( $_POST['custom_users'] ) ) {
					$custom_users = $_POST['custom_users'];
					$custom_users = explode( "\n", trim( $custom_users ) );
					$size = count( $custom_users );
					if( $size ) {
						for( $i = 0; $i < $size; $i++ )
							$custom_users[$i] = sanitize_text_field( trim( $custom_users[$i] ) );
						woo_ce_update_option( 'custom_users', $custom_users );
					}
				}

				// Save Custom Customer Meta
				if( isset( $_POST['custom_customers'] ) ) {
					$custom_customers = $_POST['custom_customers'];
					$custom_customers = explode( "\n", trim( $custom_customers ) );
					$size = count( $custom_customers );
					if( $size ) {
						for( $i = 0; $i < $size; $i++ )
							$custom_customers[$i] = sanitize_text_field( trim( $custom_customers[$i] ) );
						woo_ce_update_option( 'custom_customers', $custom_customers );
					}
				}

				$message = __( 'Custom Fields saved.', 'woo_ce' );
				woo_cd_admin_notice_html( $message );
				woo_cd_manage_form();
				break;

			default:
				woo_cd_manage_form();
				break;

		}
		woo_cd_template_footer();

	}

	// HTML template for Export screen
	function woo_cd_manage_form() {

		$tab = ( isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : false );
		// If Skip Overview is set then jump to Export screen
		if( $tab == false && woo_ce_get_option( 'skip_overview', false ) )
			$tab = 'export';
		woo_ce_fail_notices();

		include_once( WOO_CD_PATH . 'templates/admin/tabs.php' );

	}

	/* End of: WordPress Administration */

} else {

	/* Start of: Storefront */

	function woo_ce_cron() {

		$action = woo_get_action();
		// This is where the CRON export magic happens
		if( $action == 'woo_ce-cron' ) {

			// Check that Store Exporter is installed and activated or jump out
			if( !function_exists( 'woo_ce_get_option' ) )
				return;

			// Return silent response and record to error log if CRON support is disabled or bad secret key provided
			if( woo_ce_get_option( 'enable_cron', 0 ) == 0 ) {
				error_log( '[store-exporter-deluxe] Failed CRON access, CRON is disabled' );
				return;
			}
			$key = ( isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '' );
			if( $key <> woo_ce_get_option( 'secret_key', '' ) ) {
				$ip_address = woo_ce_get_visitor_ip_address();
				error_log( sprintf( '[store-exporter-deluxe] Failed CRON attempt from %s, incorrect secret key' ), $ip_address );
				unset( $ip_address );
				return;
			}

			$gui = ( isset( $_GET['gui'] ) ? absint( $_GET['gui'] ) : 0 );
			$response = ( isset( $_GET['response'] ) ? sanitize_text_field( $_GET['response'] ) : '' );
			// Output to screen in friendly design with on-screen error responses
			if( $gui == 1 ) {
				woo_ce_cron_export( 'gui' );
			// Return export download to browser in different expected formats, uses error_log for error responses
			} else if( $gui == 0 && in_array( $response, array( 'download', 'raw', 'url', 'file', 'email', 'post', 'ftp' ) ) ) {
				switch( $response ) {

					// Return export download to browser
					case 'download':
						echo woo_ce_cron_export( 'download' );
						break;

					// Return raw download to browser
					case 'raw':
						echo woo_ce_cron_export( 'raw' );
						break;

					// Return the URI to the saved export
					case 'url':
						echo woo_ce_cron_export( 'url' );
						break;

					// Return the system path to the saved export
					case 'file':
						echo woo_ce_cron_export( 'file' );
						break;

					case 'email':
						echo woo_ce_cron_export( 'email' );
						break;

					case 'post':
						echo woo_ce_cron_export( 'post' );
						break;

					case 'ftp':
						echo woo_ce_cron_export( 'ftp' );
						break;

				}
			} else {
				// Return simple binary response
				echo (int)woo_ce_cron_export();
			}
			exit();

		}

	}
	add_action( 'init', 'woo_ce_cron' );	

	/* End of: Storefront */

}

// Run this function within the WordPress Administration and storefront to ensure scheduled exports happen
function woo_ce_init() {

	// Check that Store Exporter is installed and activated or jump out
	if( !function_exists( 'woo_ce_get_option' ) )
		return;

	if( woo_ce_get_option( 'enable_auto', 0 ) == 1 ) {

		// Add custom schedule for automated exports
		add_filter( 'cron_schedules', 'woo_ce_cron_schedules' );
		woo_ce_cron_activation();

	}

	// Once every x minutes WP_CRON will run the automated export
	add_action( 'woo_ce_auto_export_schedule', 'woo_ce_auto_export' );

}
add_action( 'init', 'woo_ce_init', 11 );
?>