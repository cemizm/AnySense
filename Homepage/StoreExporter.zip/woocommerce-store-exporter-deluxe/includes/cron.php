<?php
function woo_ce_cron_export( $gui = '', $type = '', $is_scheduled = false ) {

	global $export;

	$export = new stdClass;
	$export->scheduled_export = ( $is_scheduled ? 1 : 0 );
	$export->cron = ( $is_scheduled ? 0 : 1 );

	$bits = '';
	$mime_type = 'text/csv';
	$type = ( isset( $_GET['type'] ) ? $_GET['type'] : $type );
	if( !empty( $type ) ) {
		$types = array_keys( woo_ce_return_export_types() );
		$export->type = $type;
		// Check that export is in the list of available exports
		if( in_array( $export->type, $types ) ) {
			$export->export_format = ( isset( $_GET['format'] ) ? sanitize_text_field( $_GET['format'] ) : woo_ce_get_option( 'export_format', 'csv' ) );

			// Override the export format if this is a scheduled export
			if( $export->scheduled_export )
				$export->export_format = woo_ce_get_option( 'auto_format', 'csv' );

			// Override the export format if a single order transient is set
			$single_export_format = get_transient( WOO_CD_PREFIX . '_single_export_format' );
			if( $single_export_format !== false )
				$export->export_format = $single_export_format;
			unset( $single_export_format );

			$export->delimiter = ( isset( $_GET['delimiter'] ) ? (string)$_GET['delimiter'] : woo_ce_get_option( 'delimiter', ',' ) );
			$export->category_separator = ( isset( $_GET['category_separator'] ) ? (string)$_GET['category_separator'] : woo_ce_get_option( 'category_separator', '|' ) );
			// Override for line break (LF) support in Category Separator
			if( $export->category_separator == 'LF' )
				$export->category_separator = "\n";
			$export->bom = ( isset( $_GET['bom'] ) ? (int)$_GET['bom'] : woo_ce_get_option( 'bom', 1 ) );
			$export->encoding = ( isset( $_GET['encoding'] ) ? (string)$_GET['encoding'] : woo_ce_get_option( 'encoding', 'UTF-8' ) );
			$export->timeout = woo_ce_get_option( 'timeout', 600 );
			$export->escape_formatting = ( isset( $_GET['escape_formatting'] ) ? sanitize_text_field( (string)$_GET['escape_formatting'] ) : woo_ce_get_option( 'escape_formatting', 'all' ) );
			$export->header_formatting = ( isset( $_GET['header_formatting'] ) ? absint( (int)$_GET['header_formatting'] ) : woo_ce_get_option( 'header_formatting', 1 ) );
			$export->date_format = woo_ce_get_option( 'date_format', 'd/m/Y' );
			$export->order_items = ( isset( $_GET['order_items'] ) ? (string)$_GET['order_items'] : woo_ce_get_option( 'order_items_formatting', 'unique' ) );
			$export->upsell_formatting = woo_ce_get_option( 'upsell_formatting', 1 );
			$export->crosssell_formatting = woo_ce_get_option( 'crosssell_formatting', 1 );
			$export->gallery_formatting = woo_ce_get_option( 'gallery_formatting', 0 );
			if( $export->export_format == 'csv' ) {
				$export->filename = woo_ce_generate_csv_filename( $export->type );
				$mime_type = 'text/csv';
			} else if( $export->export_format == 'xml' ) {
				$export->filename = woo_ce_generate_xml_filename( $export->type );
				$mime_type = 'application/xml';
			} else if( $export->export_format == 'xls' ) {
				// Override the encoding type
				// $export->encoding = 'UTF-16LE';
				$export->filename = woo_ce_generate_xls_filename( $export->type );
				$mime_type = 'application/vnd.ms-excel';
				$export->delimiter = "\t";
			} else {
				error_log( sprintf( '[store-exporter-deluxe] -: %s', __( 'An invalid export format was provided', 'woo_ce' ) ) );
				return false;
			}
			$export->limit_volume = ( isset( $_GET['limit'] ) ? (int)$_GET['limit'] : woo_ce_get_option( 'limit_volume', -1 ) );
			$export->offset = ( isset( $_GET['offset'] ) ? (int)$_GET['offset'] : woo_ce_get_option( 'offset', 0 ) );
			// Select all export fields for CRON export
			$export->fields = woo_ce_cron_export_fields( $export->type, $export->scheduled_export );
			// Grab to value if response is e-mail or remote POST
			if( in_array( $gui, array( 'email', 'post' ) ) ) {
				if( $gui == 'email' )
					$export->to = ( isset( $_GET['to'] ) ? sanitize_email( $_GET['to'] ) : woo_ce_get_option( 'email_to', '' ) );
				else if( $gui == 'post' )
					$export->to = ( isset( $_GET['to'] ) ? esc_url_raw( $_GET['to'] ) : woo_ce_get_option( 'post_to', '' ) );
			}
			$export = woo_ce_check_cron_export_arguments( $export );

			$export->args = array(
				'limit_volume' => $export->limit_volume,
				'offset' => $export->offset,
				'encoding' => $export->encoding,
				'date_format' => $export->date_format,
				'order_items' => $export->order_items
			);

			$orderby = ( isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : null );
			$order = ( isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : null );
			switch( $export->type ) {

				case 'product':
					$export->args['product_orderby'] = $orderby;
					$export->args['product_order'] = $order;
					if( $export->scheduled_export ) {
						$product_filter_type = woo_ce_get_option( 'auto_product_type', false );
						$product_filter_stock = woo_ce_get_option( 'auto_product_stock', false );
						$product_filter_category = woo_ce_get_option( 'auto_product_category', false );
						$product_filter_tag = woo_ce_get_option( 'auto_product_tag', false );
						$export->args['product_type'] = ( !empty( $product_filter_type ) ? $product_filter_type : false );
						$export->args['product_stock'] = ( !empty( $product_filter_stock ) ? $product_filter_stock : false );
						$export->args['product_categories'] = ( !empty( $product_filter_category ) ? $product_filter_category : false );
						$export->args['product_tags'] = ( !empty( $product_filter_tag ) ? $product_filter_tag : false );
					} else {
						$export->args['product_stock'] = ( isset( $_GET['stock_status'] ) ? sanitize_text_field( $_GET['stock_status'] ) : null );
					}
					break;

				case 'category':
					$export->args['category_orderby'] = $orderby;
					$export->args['category_order'] = $order;
					break;

				case 'tag':
					$export->args['tag_orderby'] = $orderby;
					$export->args['tag_order'] = $order;
					break;

				case 'order':
					$export->args['order_orderby'] = $orderby;
					$export->args['order_order'] = $order;
					$export->args['order_ids'] = ( isset( $_GET['order_ids'] ) ? sanitize_text_field( $_GET['order_ids'] ) : null );

					// Override Filter Orders by Order ID if a single order transient is set
					$single_export_order_ids = get_transient( WOO_CD_PREFIX . '_single_export_order_ids' );
					if( $single_export_order_ids !== false )
						$export->args['order_ids'] = sanitize_text_field( $single_export_order_ids );
					unset( $single_export_order_ids );

					if( $export->scheduled_export ) {
						$order_filter_status = woo_ce_get_option( 'auto_order_status', '' );
						// Order Status
						$export->args['order_status'] = ( !empty( $order_filter_status ) ? (array)$order_filter_status : array() );
						// Order Date
						$order_dates_filter = woo_ce_get_option( 'auto_order_date', false );
						if( $order_dates_filter ) {
							$export->args['order_dates_filter'] = $order_dates_filter;
							switch( $order_dates_filter ) {

								case 'manual':
									$order_filter_dates_from = woo_ce_get_option( 'auto_order_dates_from', false );
									$order_filter_dates_to = woo_ce_get_option( 'auto_order_dates_to', false );
									$export->args['order_dates_from'] = ( !empty( $order_filter_dates_from ) ? sanitize_text_field( $order_filter_dates_from ) : false );
									$export->args['order_dates_to'] = ( !empty( $order_filter_dates_to ) ? sanitize_text_field( $order_filter_dates_to ) : false );
									break;

								case 'variable':
									$order_filter_date_variable = woo_ce_get_option( 'auto_order_date_variable', false );
									$order_filter_date_variable_length = woo_ce_get_option( 'auto_order_date_variable_length', false );
									$export->args['order_dates_filter_variable'] = ( !empty( $order_filter_date_variable ) ? absint( $order_filter_date_variable ) : false );
									$export->args['order_dates_filter_variable_length'] = ( !empty( $order_filter_date_variable_length ) ? sanitize_text_field( $order_filter_date_variable_length ) : false );
									break;

							}
						}
					} else {
						// Order Status
						if( isset( $_GET['order_status'] ) ) {
							$order_filter_status = sanitize_text_field( $_GET['order_status'] );
							$order_filter_status = explode( ',', $order_filter_status );
							$export->args['order_status'] = $order_filter_status;
						}
						// Order Date
						if( isset( $_GET['order_date_from'] ) && isset( $_GET['order_date_to'] ) ) {
							$order_filter_dates_from = $_GET['order_date_from'];
							$order_filter_dates_to = $_GET['order_date_to'];
							$export->args['order_dates_filter'] = 'manual';
							$export->args['order_dates_from'] = ( !empty( $order_filter_dates_from ) ? sanitize_text_field( $order_filter_dates_from ) : false );
							$export->args['order_dates_to'] = ( !empty( $order_filter_dates_to ) ? sanitize_text_field( $order_filter_dates_to ) : false );
						}
					}
					break;

				case 'subscription':
					$export->args['subscription_orderby'] = $orderby;
					$export->args['subscription_order'] = $order;
					break;

				case 'product_vendor':
					$export->args['product_vendor_orderby'] = $orderby;
					$export->args['product_vendor_order'] = $order;
					break;

				case 'commission':
					// Commission Date
					$commission_dates_filter = woo_ce_get_option( 'auto_commission_date', false );
					if( $commission_dates_filter ) {
						$export->args['commission_dates_filter'] = $commission_dates_filter;
						switch( $commission_dates_filter ) {

							case 'manual':
								$commission_filter_dates_from = woo_ce_get_option( 'auto_commission_dates_from', false );
								$commission_filter_dates_to = woo_ce_get_option( 'auto_commission_date_to', false );
								$export->args['commission_dates_from'] = ( !empty( $commission_filter_dates_from ) ? sanitize_text_field( $commission_filter_dates_from ) : false );
								$export->args['commission_dates_to'] = ( !empty( $commission_filter_dates_to ) ? sanitize_text_field( $commission_filter_dates_to ) : false );
								break;

							case 'variable':
								$commission_filter_date_variable = woo_ce_get_option( 'auto_commission_date_variable', false );
								$commission_filter_date_variable_length = woo_ce_get_option( 'auto_commission_date_variable_length', false );
								$export->args['commission_dates_filter_variable'] = ( !empty( $commission_filter_date_variable ) ? absint( $commission_filter_date_variable ) : false );
								$export->args['commission_dates_filter_variable_length'] = ( !empty( $commission_filter_date_variable_length ) ? sanitize_text_field( $commission_filter_date_variable_length ) : false );
								break;

						}
					}
					break;

				case 'shipping_class':
					$export->args['shipping_class_orderby'] = $orderby;
					$export->args['shipping_class_order'] = $order;
					break;

			}
			if( $export->export_format == 'xml' ) {
				if( class_exists( 'SimpleXMLElement' ) ) {
					$xml = new SimpleXMLElement( sprintf( '<?xml version="1.0" encoding="%s"?><store/>', $export->encoding ) );
					if( woo_ce_get_option( 'xml_attribute_url', 1 ) )
						$xml->addAttribute( 'url', get_site_url() );
					if( woo_ce_get_option( 'xml_attribute_date', 1 ) )
						$xml->addAttribute( 'date', date( 'Y-m-d' ) );
					if( woo_ce_get_option( 'xml_attribute_time', 0 ) )
						$xml->addAttribute( 'time', date( 'H:i:s' ) );
					if( woo_ce_get_option( 'xml_attribute_title', 1 ) )
						$xml->addAttribute( 'name', htmlspecialchars( get_bloginfo( 'name' ) ) );
					if( woo_ce_get_option( 'xml_attribute_export', 1 ) )
						$xml->addAttribute( 'export', htmlspecialchars( $export->type ) );
					if( woo_ce_get_option( 'xml_attribute_orderby', 1 ) )
						$xml->addAttribute( 'orderby', $orderby );
					if( woo_ce_get_option( 'xml_attribute_order', 1 ) )
						$xml->addAttribute( 'order', $order );
					if( woo_ce_get_option( 'xml_attribute_limit', 1 ) )
						$xml->addAttribute( 'limit', $export->limit_volume );
					if( woo_ce_get_option( 'xml_attribute_offset', 1 ) )
						$xml->addAttribute( 'offset', $export->offset );
					$xml = woo_ce_export_dataset( $export->type, $xml );
					$bits = woo_ce_format_xml( $xml );
				} else {
					$bits = false;
					error_log( '[store-exporter-deluxe] The SimpleXMLElement class does not exist for XML file generation' );
				}
			} else if( in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
				$bits = woo_ce_export_dataset( $export->type );
			}
			if( !empty( $bits ) ) {
				$output = '<p>' . __( 'Export completed successfully.', 'woo_ce' ) . '</p>';
				if( $gui == 'gui' )
					$output .= '<textarea readonly="readonly">' . esc_textarea( str_replace( '<br />', "\n", $bits ) ) . '</textarea>';
			} else {
				if( $gui == 'gui' ) {
					$output = sprintf( '<p>%s</p>', __( 'No export entries were found.', 'woo_ce' ) );
				} else {
					error_log( sprintf( '[store-exporter-deluxe] %s: %s', $export->filename, __( 'No export entries were found', 'woo_ce' ) ) );
					return false;
				}
			}
		} else {
			if( $gui == 'gui' ) {
				$output = '<p>' . __( 'An invalid export type was provided.', 'woo_ce' ) . '</p>';
			} else {
				error_log( sprintf( '[store-exporter-deluxe] -: %s', __( 'An invalid export type was provided', 'woo_ce' ) ) );
				return false;
			}
		}
	} else {
		if( $gui == 'gui' ) {
			$output = sprintf( '<p>%s</p>', __( 'No export type was provided.', 'woo_ce' ) );
		} else {
			error_log( sprintf( '[store-exporter-deluxe] -: %s', __( 'No export type was provided', 'woo_ce' ) ) );
			return false;
		}
	}
	// Return raw export to browser
	if( $gui == 'raw' && !empty( $bits ) ) {
		return $bits;
	// Return file download to browser
	} else if( $gui == 'download' && !empty( $bits ) ) {
		if( $export->export_format == 'csv' )
			woo_ce_generate_csv_header( $export->type );
		else if( $export->export_format == 'xml' )
			woo_ce_generate_xml_header( $export->type );
		else if( $export->export_format == 'xls' )
			woo_ce_generate_xls_header( $export->type );
		if( defined( 'DOING_AJAX' ) || get_transient( WOO_CD_PREFIX . '_single_export_format' ) !== false )
			echo $bits;
		else
			return $bits;
	// HTTP Post export contents to remote URL
	} else if( $gui == 'post' && !empty( $bits ) ) {
		$args = apply_filters( 'woo_ce_cron_export_post_args', array(
			'method'      => 'POST',
			'timeout'     => 60,
			'redirection' => 0,
			'httpversion' => '1.0',
			'sslverify'   => false,
			'blocking'    => true,
			'headers'     => array(
				'accept'       => $mime_type,
				'content-type' => $mime_type
			),
			'body'        => $bits,
			'cookies'     => array(),
			'user-agent'  => sprintf( 'WordPress/%s', $GLOBALS['wp_version'] ),
		) );
		$response = wp_remote_post( $export->to, $args );
		if ( is_wp_error( $response ) ) {
			error_log( sprintf( '[store-exporter-deluxe] %s: Error: %s', $export->filename, $response->get_error_message() ) );
			return false;
		}
		error_log( sprintf( '[store-exporter-deluxe] %s: %s', $export->filename, __( 'Remote POST sent', 'woo_ce' ) ) );
	// Output to screen in friendly design with on-screen error responses
	} else if( $gui == 'gui' ) {
		include( WOO_CD_PATH . 'templates/admin/cron.php' );
		if( isset( $output ) )
			echo $output;
		echo '
	</body>
</html>';
	// Save export file to WordPress Media
	} else if( in_array( $gui, array( 'gui', 'archive', 'url', 'file', 'email', 'ftp' ) ) ) {
		$upload = false;
		if( $export->filename && $bits ) {
			$post_ID = woo_ce_save_file_attachment( $export->filename, $mime_type );
			$upload = wp_upload_bits( $export->filename, null, $bits );
			if( $upload['error'] ) {
				wp_delete_attachment( $post_ID, true );
				error_log( sprintf( '[store-exporter-deluxe] %s: Error: %s', $export->filename, $upload['error'] ) );
				return false;
			}
			include_once( ABSPATH . 'wp-admin/includes/image.php' );
			$attach_data = wp_generate_attachment_metadata( $post_ID, $upload['file'] );
			wp_update_attachment_metadata( $post_ID, $attach_data );
			update_attached_file( $post_ID, $upload['file'] );
			if( $post_ID )
				woo_ce_save_file_guid( $post_ID, $export->type, $upload['url'] );
		}
		// Return URL to export file
		if( $gui == 'url' )
			return $upload['url'];
		// Return system path to export file
		if( $gui == 'file' )
			return $upload['file'];
		// E-mail export file to preferred address or WordPress site owner address
		if( $gui == 'email' ) {

			global $woocommerce;

			$mailer = $woocommerce->mailer();
			$subject = woo_ce_cron_email_subject( $export->type, $export->filename );
			$attachment = $upload['file'];
			$email_heading = sprintf( __( 'Export: %s', 'woo_ce' ), ucwords( $export->type ) );
			$recipient_name = apply_filters( 'woo_ce_email_recipient_name', __( 'there', 'woo_ce' ) );
			$email_contents = apply_filters( 'woo_ce_email_contents', wpautop( __( 'Please find attached your export ready to review.', 'woo_ce' ) ) );
			// Buffer
			ob_start();

			// Get mail template
			if( file_exists( WOO_CD_PATH . 'templates/emails/scheduled_export.php' ) )
				include( WOO_CD_PATH . 'templates/emails/scheduled_export.php' );

			// Get contents
			$message = ob_get_clean();

			// Send the mail
			if( function_exists( 'woocommerce_mail' ) ) {
				woocommerce_mail( $export->to, $subject, $message, null, $attachment );
				error_log( sprintf( '[store-exporter-deluxe] %s: %s', $export->filename, __( 'Scheduled export e-mail sent', 'woo_ce' ) ) );
				return true;
			}

		}
		if( $gui == 'ftp' ) {
			// Check if ftp_connect() is available
			if( function_exists( 'ftp_connect' ) ) {
				$host = woo_ce_get_option( 'auto_ftp_method_host', '' );
				$user = woo_ce_get_option( 'auto_ftp_method_user', '' );
				$pass = woo_ce_get_option( 'auto_ftp_method_pass', '' );
				$port = woo_ce_get_option( 'auto_ftp_method_port', '' );
				$path = woo_ce_get_option( 'auto_ftp_method_path', '' );
				$passive = woo_ce_get_option( 'auto_ftp_method_passive', '' );
				$timeout = woo_ce_get_option( 'auto_ftp_method_timeout', '' );
				$port = ( !empty( $port ) ? absint( $port ) : false );
				if( $connection = ftp_connect( $host, $port ) ) {
					// Update the FTP timeout if available and if a timeout was provided at import
					$remote_timeout = ftp_get_option( $connection, FTP_TIMEOUT_SEC );
					$timeout = absint( $timeout );
					if( $remote_timeout !== false && !empty( $timeout ) ) {
						// Compare the server timeout and the timeout provided at import
						if( $remote_timeout <> $timeout ) {
							if( ftp_set_option( $connection, FTP_TIMEOUT_SEC, $timeout ) == false )
								error_log( sprintf( '[store-exporter-deluxe] Could not change the timeout on %s', $host ) );
						}
					}
					unset( $remote_timeout );
					if( ftp_login( $connection, $user, $pass ) ) {
						// Check if Transfer Mode is set to Auto/Pasive and if passive mode is available
						if( in_array( $passive, array( 'auto', 'passive' ) ) ) {
							$features = ftp_raw( $connection, 'FEAT' );
							if( !empty( $features ) ) {
								if( in_array( 'PASV', $features ) ) {
									if( ftp_pasv( $connection, true ) == false )
										error_log( sprintf( '[store-exporter-deluxe] Could not switch to passive mode on %s', $host ) );
								}
							}
						}
						// Change directory if neccesary
						if( !empty( $directory ) ) {
							$current_directory  = ftp_pwd( $connection );
							if( $current_directory !== false && @ftp_chdir( $connection, $path ) )
								ftp_chdir( $connection, $path );
						}
						if( ftp_put( $connection, sprintf( '%s/%s', $path, $export->filename ), $upload['file'], FTP_ASCII ) )
							error_log( sprintf( '[store-exporter-deluxe] %s: %s', $export->filename, __( 'Scheduled export to FTP uploaded', 'woo_ce' ) ) );
						else
							error_log( sprintf( '[store-exporter-deluxe] %s: %s', $export->filename, sprintf( __( 'There was a problem uploading %s to %s', 'woo_ce' ), $export->filename, $path ) ) );
					} else {
						error_log( sprintf( '[store-exporter-deluxe] %s', sprintf( __( 'Login incorrect for user %s on FTP server at %s', 'woo_pd' ), $user, $host ) ) );
					}
				}
			} else {
				error_log( __( '[store-exporter-deluxe] The function ftp_connect() is disabled within your WordPress site.', 'woo_ce' ) );
			}
		}
	}
	// If the CRON process gets this far, pass on the good news!
	return true;

}

function woo_ce_check_cron_export_arguments( $args ) {

	$args->export_format = ( $args->export_format != '' ? $args->export_format : 'csv' );
	$args->limit_volume = ( $args->limit_volume != '' ? $args->limit_volume : -1 );
	$args->offset = ( $args->offset != '' ? $args->offset : 0 );
	$args->date_format = ( $args->date_format != '' ? $args->date_format : 'd/m/Y' );
	// Override for corrupt WordPress option 'date_format' from older releases
	if( $args->date_format == '1' || $args->date_format == '' || $args->date_format == false ) {
		error_log( '[store-exporter-deluxe] Date Format export option was corrupted, defaulted to d/m/Y' );
		$args->date_format = 'd/m/Y';
	}
	return $args;

}

function woo_ce_cron_export_fields( $export_type = '', $is_scheduled = 0 ) {

	global $export;

	$fields = array();
	$export_fields = 'all';
	if( $is_scheduled == '0' )
		$export_fields = woo_ce_get_option( 'cron_fields', 'all' );
	else if( $is_scheduled == '1' )
		$export_fields = woo_ce_get_option( 'scheduled_fields', 'all' );

	if( $export_fields == 'all' ) {
		if( function_exists( sprintf( 'woo_ce_get_%s_fields', $export_type ) ) )
			$fields = call_user_func_array( 'woo_ce_get_' . $export_type . '_fields', array( 'summary' ) );
	} else if( $export_fields == 'saved' ) {
		// Fall back to default of stored export fields for that export type
		$fields = woo_ce_get_option( $export_type . '_fields', array() );
	}
	return $fields;

}

function woo_ce_cron_email_subject( $type = '', $filename = '' ) {

	$subject = woo_ce_get_option( 'email_subject', '' );
	// Default subject
	if( empty( $subject ) )
		$subject = __( '[%store_name%] Export: %export_type% (%export_filename%)', 'woo_ce' );
	$subject = str_replace( '%store_name%', sanitize_title( get_bloginfo( 'name' ) ), $subject );
	$subject = str_replace( '%export_type%', ucwords( $type ), $subject );
	$subject = str_replace( '%export_filename%', $filename, $subject );
	return $subject;

}
?>