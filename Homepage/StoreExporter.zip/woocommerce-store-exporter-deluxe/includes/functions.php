<?php
include_once( WOO_CD_PATH . 'includes/product.php' );
include_once( WOO_CD_PATH . 'includes/category.php' );
include_once( WOO_CD_PATH . 'includes/tag.php' );
include_once( WOO_CD_PATH . 'includes/brand.php' );
include_once( WOO_CD_PATH . 'includes/order.php' );
include_once( WOO_CD_PATH . 'includes/customer.php' );
include_once( WOO_CD_PATH . 'includes/user.php' );
include_once( WOO_CD_PATH . 'includes/coupon.php' );
include_once( WOO_CD_PATH . 'includes/subscription.php' );
include_once( WOO_CD_PATH . 'includes/product_vendor.php' );
include_once( WOO_CD_PATH . 'includes/commission.php' );
include_once( WOO_CD_PATH . 'includes/shipping_class.php' );
include_once( WOO_CD_PATH . 'includes/cron.php' );

// Check if we are using PHP 5.3 and above
if( version_compare( phpversion(), '5.3' ) >= 0 )
	include_once( WOO_CD_PATH . 'includes/legacy.php' );
include_once( WOO_CD_PATH . 'includes/formatting.php' );

include_once( WOO_CD_PATH . 'includes/export-csv.php' );
include_once( WOO_CD_PATH . 'includes/export-xml.php' );
include_once( WOO_CD_PATH . 'includes/export-xls.php' );

if( is_admin() ) {

	/* Start of: WordPress Administration */

	include_once( WOO_CD_PATH . 'includes/admin.php' );
	include_once( WOO_CD_PATH . 'includes/settings.php' );

	// Displays a HTML notice when a WordPress or Store Exporter error is encountered
	function woo_ce_fail_notices() {

		woo_ce_memory_prompt();

		$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';
		// If the failed flag is set then prepare for an error notice
		if( isset( $_GET['failed'] ) ) {
			$message = '';
			if( isset( $_GET['message'] ) )
				$message = urldecode( $_GET['message'] );
			if( $message )
				$message = sprintf( __( 'A WordPress or server error caused the exporter to fail, the exporter was provided with a reason: <em>%s</em>', 'woo_ce' ), $message ) . ' (<a href="' . $troubleshooting_url . '" target="_blank">' . __( 'Need help?', 'woo_ce' ) . '</a>)';
			else
				$message = __( 'A WordPress or server error caused the exporter to fail, no reason was provided, please get in touch so we can reproduce and resolve this.', 'woo_ce' ) . ' (<a href="' . $troubleshooting_url . '" target="_blank">' . __( 'Need help?', 'woo_ce' ) . '</a>)';
			woo_cd_admin_notice_html( $message, 'error' );
		}
		// If the export failed the WordPress Transient will still exist
		if( get_transient( WOO_CD_PREFIX . '_running' ) ) {
			$message = __( 'A WordPress or server error caused the exporter to fail with a blank screen, this is either a memory or timeout issue, please get in touch so we can reproduce and resolve this.', 'woo_ce' ) . ' (<a href="' . $troubleshooting_url . '" target="_blank">' . __( 'Need help?', 'woo_ce' ) . '</a>)';
			woo_cd_admin_notice_html( $message, 'error' );
			delete_transient( WOO_CD_PREFIX . '_running' );
		}

	}

	// Displays a HTML notice where the memory allocated to WordPress falls below 64MB
	function woo_ce_memory_prompt() {

		$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';

		// Displays a HTML notice where the memory allocated to WordPress falls below 64MB
		if( !woo_ce_get_option( 'dismiss_memory_prompt', 0 ) ) {
			$memory_limit = (int)( ini_get( 'memory_limit' ) );
			$minimum_memory_limit = 64;
			if( $memory_limit < $minimum_memory_limit ) {
				$dismiss_url = add_query_arg( 'action', 'dismiss_memory_prompt' );
				$message = sprintf( __( 'We recommend setting memory to at least %dMB, your site has only %dMB allocated to it. See: <a href="%s" target="_blank">Increasing memory allocated to PHP</a>', 'woo_ce' ), $minimum_memory_limit, $memory_limit, $troubleshooting_url ) . '<span style="float:right;"><a href="' . $dismiss_url . '">' . __( 'Dismiss', 'woo_ce' ) . '</a></span>';
				woo_cd_admin_notice_html( $message, 'error' );
			}
		}

		// Displays a HTML notice if PHP 5.2 is installed
		if( version_compare( phpversion(), '5.3', '<' ) && !woo_ce_get_option( 'dismiss_php_legacy', 0 ) ) {
			$dismiss_url = add_query_arg( 'action', 'dismiss_php_legacy' );
			$message = sprintf( __( 'Your PHP version (%s) is not supported and is very much out of date, since 2010 all users are strongly encouraged to upgrade to PHP 5.3+ and above. Contact your hosting provider to make this happen. See: <a href="%s" target="_blank">Migrating from PHP 5.2 to 5.3</a>', 'woo_ce' ), phpversion(), $troubleshooting_url ) . '<span style="float:right;"><a href="' . $dismiss_url . '">' . __( 'Dismiss', 'woo_ce' ) . '</a></span>';
			woo_cd_admin_notice_html( $message, 'error' );
		}

	}

	// Saves the state of Export fields for next export
	function woo_ce_save_fields( $type = '', $fields = array(), $sorting = array() ) {

		// Default fields
		if( $fields == false && !is_array( $fields ) )
			$fields = array();
		$types = array_keys( woo_ce_return_export_types() );
		if( in_array( $type, $types ) && !empty( $fields ) ) {
			woo_ce_update_option( $type . '_fields', array_map( 'sanitize_text_field', $fields ) );
			woo_ce_update_option( $type . '_sorting', array_map( 'absint', $sorting ) );
		}

	}

	// Returns number of an Export type prior to export, used on Store Exporter screen
	function woo_ce_return_count( $export_type = '', $args = array() ) {

		global $wpdb;

		$count_sql = null;
		$woocommerce_version = woo_get_woo_version();
		switch( $export_type ) {

			case 'product':
				$post_type = array( 'product', 'product_variation' );
				$args = array(
					'post_type' => $post_type,
					'posts_per_page' => 1,
					'fields' => 'ids'
				);
				$count_query = new WP_Query( $args );
				$count = $count_query->found_posts;
				break;

			case 'category':
				$term_taxonomy = 'product_cat';
				$count = wp_count_terms( $term_taxonomy );
				break;

			case 'tag':
				$term_taxonomy = 'product_tag';
				$count = wp_count_terms( $term_taxonomy );
				break;

			case 'brand':
				$term_taxonomy = apply_filters( 'woo_ce_return_count_brand', 'product_brand' );
				$count = wp_count_terms( $term_taxonomy );
				break;

			case 'order':
				$post_type = 'shop_order';
				// Check if this is a WooCommerce 2.2+ instance (new Post Status)
				if( version_compare( $woocommerce_version, '2.2' ) >= 0 )
					$post_status = ( function_exists( 'wc_get_order_statuses' ) ? apply_filters( 'woo_ce_order_post_status', array_keys( wc_get_order_statuses() ) ) : 'any' );
				else
					$post_status = apply_filters( 'woo_ce_order_post_status', woo_ce_post_statuses() );
				$args = array(
					'post_type' => $post_type,
					'posts_per_page' => 1,
					'post_status' => $post_status,
					'fields' => 'ids'
				);
				$count_query = new WP_Query( $args );
				$count = $count_query->found_posts;
				break;

			case 'customer':
				if( $users = woo_ce_return_count( 'user' ) > 1000 ) {
					$count = sprintf( '~%s+', 1000 );
				} else {
					$post_type = 'shop_order';
					$args = array(
						'post_type' => $post_type,
						'posts_per_page' => -1,
						'fields' => 'ids'
					);
					// Check if this is a WooCommerce 2.2+ instance (new Post Status)
					if( version_compare( $woocommerce_version, '2.2' ) >= 0 ) {
						$args['post_status'] = apply_filters( 'woo_ce_customer_post_status', array( 'wc-pending', 'wc-on-hold', 'wc-processing', 'wc-completed' ) );
					} else {
						$args['post_status'] = apply_filters( 'woo_ce_customer_post_status', woo_ce_post_statuses() );
						$args['tax_query'] = array(
							array(
								'taxonomy' => 'shop_order_status',
								'field' => 'slug',
								'terms' => array( 'pending', 'on-hold', 'processing', 'completed' )
							),
						);
					}
					$order_ids = new WP_Query( $args );
					$count = $order_ids->found_posts;
					if( $count > 100 ) {
						$count = sprintf( '~%s', $count );
					} else {
						$customers = array();
						if( $order_ids->posts ) {
							foreach( $order_ids->posts as $order_id ) {
								$email = get_post_meta( $order_id, '_billing_email', true );
								if( !in_array( $email, $customers ) )
									$customers[$order_id] = $email;
								unset( $email );
							}
							$count = count( $customers );
						}
					}
				}
/*
				if( false ) {
					$orders = get_posts( $args );
					if( $orders ) {
						$customers = array();
						foreach( $orders as $order ) {
							$order->email = get_post_meta( $order->ID, '_billing_email', true );
							if( empty( $order->email ) ) {
								if( $order->user_id = get_post_meta( $order->ID, '_customer_user', true ) ) {
									$user = get_userdata( $order->user_id );
									if( $user )
										$order->email = $user->user_email;
									unset( $user );
								} else {
									$order->email = '-';
								}
							}
							if( !in_array( $order->email, $customers ) ) {
								$customers[$order->ID] = $order->email;
								$count++;
							}
						}
						unset( $orders, $order );
					}
				}
*/
				break;

			case 'user':
				if( $users = count_users() )
					$count = $users['total_users'];
				break;

			case 'coupon':
				$post_type = 'shop_coupon';
				$count = wp_count_posts( $post_type );
				break;

			case 'subscription':
				$count = 0;
				// Check that WooCommerce Subscriptions exists
				if( class_exists( 'WC_Subscriptions_Manager' ) ) {
					// Check that the get_all_users_subscriptions() function exists
					if( method_exists( 'WC_Subscriptions_Manager', 'get_all_users_subscriptions' ) ) {
						if( $subscriptions = WC_Subscriptions_Manager::get_all_users_subscriptions() ) {
							foreach( $subscriptions as $key => $user_subscription ) {
								if( !empty( $user_subscription ) ) {
									foreach( $user_subscription as $subscription )
										$count++;
								}
							}
							unset( $subscriptions, $subscription, $user_subscription );
						}
					}
				}
				break;

			case 'product_vendor':
				$term_taxonomy = 'shop_vendor';
				$count = wp_count_terms( $term_taxonomy );
				break;

			case 'commission':
				$post_type = 'shop_commission';
				$count = wp_count_posts( $post_type );
				break;

			case 'shipping_class':
				$term_taxonomy = 'product_shipping_class';
				$count = wp_count_terms( $term_taxonomy );
				break;

			case 'attribute':
				$attributes = ( function_exists( 'wc_get_attribute_taxonomies' ) ? wc_get_attribute_taxonomies() : array() );
				$count = count( $attributes );
				break;

		}
		if( isset( $count ) || $count_sql ) {
			if( isset( $count ) ) {
				if( is_object( $count ) ) {
					$count = (array)$count;
					$count = (int)array_sum( $count );
				}
				return $count;
			} else {
				if( $count_sql )
					$count = $wpdb->get_var( $count_sql );
				else
					$count = 0;
			}
			return $count;
		} else {
			return 0;
		}

	}

	// In-line display of export file and export details when viewed via WordPress Media screen
	function woo_ce_read_csv_file( $post = null ) {

		if( !$post ) {
			if( isset( $_GET['post'] ) )
				$post = get_post( $_GET['post'] );
		}

		if( $post->post_type != 'attachment' )
			return false;

		if( !in_array( $post->post_mime_type, array( 'text/csv', 'xml/application', 'application/vnd.ms-excel' ) ) )
			return false;

		$filename = $post->post_name;
		$filepath = get_attached_file( $post->ID );
		$contents = __( 'No export entries were found, please try again with different export filters.', 'woo_ce' );
		if( file_exists( $filepath ) ) {
			$handle = fopen( $filepath, "r" );
			$contents = stream_get_contents( $handle );
			fclose( $handle );
		} else {
			// This resets the _wp_attached_file Post meta key to the correct value
			update_attached_file( $post->ID, $post->guid );
			// Try grabbing the file contents again
			$filepath = get_attached_file( $post->ID );
			if( file_exists( $filepath ) ) {
				$handle = fopen( $filepath, "r" );
				$contents = stream_get_contents( $handle );
				fclose( $handle );
			}
		}
		if( !empty( $contents ) )
			include_once( WOO_CD_PATH . 'templates/admin/media-csv_file.php' );

		$export_type = get_post_meta( $post->ID, '_woo_export_type', true );
		$columns = get_post_meta( $post->ID, '_woo_columns', true );
		$rows = get_post_meta( $post->ID, '_woo_rows', true );
		$start_time = get_post_meta( $post->ID, '_woo_start_time', true );
		$end_time = get_post_meta( $post->ID, '_woo_end_time', true );
		$idle_memory_start = get_post_meta( $post->ID, '_woo_idle_memory_start', true );
		$data_memory_start = get_post_meta( $post->ID, '_woo_data_memory_start', true );
		$data_memory_end = get_post_meta( $post->ID, '_woo_data_memory_end', true );
		$idle_memory_end = get_post_meta( $post->ID, '_woo_idle_memory_end', true );

		include_once( WOO_CD_PATH . 'templates/admin/media-export_details.php' );

	}
	add_action( 'edit_form_after_editor', 'woo_ce_read_csv_file' );

	// Returns label of Export type slug used on Store Exporter screen
	function woo_ce_export_type_label( $export_type = '', $echo = false ) {

		$output = '';
		if( !empty( $export_type ) ) {
			$export_types = woo_ce_return_export_types();
			if( array_key_exists( $export_type, $export_types ) )
				$output = $export_types[$export_type];
		}
		if( $echo )
			echo $output;
		else
			return $output;

	}

	function woo_ce_export_options_export_format() {

		$export_format = woo_ce_get_option( 'export_format', 'csv' );
		ob_start(); ?>
<tr>
	<th>
		<label><?php _e( 'Export format', 'woo_ce' ); ?></label>
	</th>
	<td>
		<label><input type="radio" name="export_format" value="csv"<?php checked( $export_format, 'csv' ); ?> /> <?php _e( 'CSV', 'woo_ce' ); ?> <span class="description"><?php _e( '(Comma separated values)', 'woo_ce' ); ?></span></label><br />
		<label><input type="radio" name="export_format" value="xml"<?php checked( $export_format, 'xml' ); ?> /> <?php _e( 'XML', 'woo_ce' ); ?> <span class="description"><?php _e( '(EXtensible Markup Language)', 'woo_ce' ); ?></label><br />
		<label><input type="radio" name="export_format" value="xls"<?php checked( $export_format, 'xls' ); ?> /> <?php _e( 'Excel (XLS)', 'woo_ce' ); ?> <span class="description"><?php _e( '(Microsoft Excel 2007)', 'woo_ce' ); ?></label>
		<p class="description"><?php _e( 'Adjust the export format to generate different export file formats.', 'woo_ce' ); ?></p>
	</td>
</tr>
<?php
		ob_end_flush();

	}

	// Returns a list of archived exports
	function woo_ce_get_archive_files() {

		$post_type = 'attachment';
		$meta_key = '_woo_export_type';
		$args = array(
			'post_type' => $post_type,
			'post_mime_type' => array( 'text/csv', 'xml/application', 'application/vnd.ms-excel' ),
			'meta_key' => $meta_key,
			'meta_value' => null,
			'posts_per_page' => -1
		);
		if( isset( $_GET['filter'] ) ) {
			$filter = $_GET['filter'];
			if( !empty( $filter ) )
				$args['meta_value'] = $filter;
		}
		$files = get_posts( $args );
		return $files;

	}

	// Returns an archived export with additional details
	function woo_ce_get_archive_file( $file = '' ) {

		$wp_upload_dir = wp_upload_dir();
		$file->export_type = get_post_meta( $file->ID, '_woo_export_type', true );
		$file->export_type_label = woo_ce_export_type_label( $file->export_type );
		if( empty( $file->export_type ) )
			$file->export_type = __( 'Unassigned', 'woo_ce' );
		if( empty( $file->guid ) )
			$file->guid = $wp_upload_dir['url'] . '/' . basename( $file->post_title );
		$file->post_mime_type = get_post_mime_type( $file->ID );
		if( !$file->post_mime_type )
			$file->post_mime_type = __( 'N/A', 'woo_ce' );
		$file->media_icon = wp_get_attachment_image( $file->ID, array( 80, 60 ), true );
		if( $author_name = get_user_by( 'id', $file->post_author ) )
			$file->post_author_name = $author_name->display_name;
		$t_time = strtotime( $file->post_date, current_time( 'timestamp' ) );
		$time = get_post_time( 'G', true, $file->ID, false );
		if( ( abs( $t_diff = time() - $time ) ) < 86400 )
			$file->post_date = sprintf( __( '%s ago' ), human_time_diff( $time ) );
		else
			$file->post_date = mysql2date( __( 'Y/m/d' ), $file->post_date );
		unset( $author_name, $t_time, $time );
		return $file;

	}

	// HTML template for displaying the current export type filter on the Archives screen
	function woo_ce_archives_quicklink_current( $current = '' ) {

		$output = '';
		if( isset( $_GET['filter'] ) ) {
			$filter = $_GET['filter'];
			if( $filter == $current )
				$output = ' class="current"';
		} else if( $current == 'all' ) {
			$output = ' class="current"';
		}
		echo $output;

	}

	// HTML template for displaying the number of each export type filter on the Archives screen
	function woo_ce_archives_quicklink_count( $type = '' ) {

		$output = '0';
		$post_type = 'attachment';
		$meta_key = '_woo_export_type';
		$args = array(
			'post_type' => $post_type,
			'meta_key' => $meta_key,
			'meta_value' => null,
			'numberposts' => -1
		);
		if( $type )
			$args['meta_value'] = $type;
		if( $posts = get_posts( $args ) )
			$output = count( $posts );
		echo $output;

	}

	/* End of: WordPress Administration */

}

// Export process for CSV file
function woo_ce_export_dataset( $export_type = null, &$output = null ) {

	global $export;

	$separator = $export->delimiter;
	$line_ending = woo_ce_get_line_ending();
	$export->columns = array();
	$export->total_rows = 0;
	$export->total_columns = 0;
	$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';
	set_transient( WOO_CD_PREFIX . '_running', time(), woo_ce_get_option( 'timeout', MINUTE_IN_SECONDS ) );

	switch( $export_type ) {

		// Products
		case 'product':
			$fields = woo_ce_get_product_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_product_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $products = woo_ce_get_products( $export->args ) ) {
				$export->total_rows = count( $products );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				$weight_unit = get_option( 'woocommerce_weight_unit' );
				$dimension_unit = get_option( 'woocommerce_dimension_unit' );
				$height_unit = $dimension_unit;
				$width_unit = $dimension_unit;
				$length_unit = $dimension_unit;
				if( !empty( $export->fields ) ) {
					foreach( $products as $product ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						$product = woo_ce_get_product_data( $product, $export->args );
						foreach( $export->fields as $key => $field ) {
							if( isset( $product->$key ) ) {
								if( is_array( $field ) ) {
									foreach( $field as $array_key => $array_value ) {
										if( !is_array( $array_value ) ) {
											if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
												$output .= woo_ce_escape_csv_value( $array_value, $export->delimiter, $export->escape_formatting );
											else if( $export->export_format == 'xml' )
												$child->addChild( $array_key, htmlspecialchars( $array_value ) );
										}
									}
								} else {
									if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
										$output .= woo_ce_escape_csv_value( $product->$key, $export->delimiter, $export->escape_formatting );
									else if( $export->export_format == 'xml' )
										$child->addChild( $key, htmlspecialchars( $product->$key ) );
								}
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}

						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
				}
				unset( $products, $product );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			break;

		// Categories
		case 'category':
			$fields = woo_ce_get_category_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_category_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			$category_args = array(
				'orderby' => ( isset( $export->args['category_orderby'] ) ? $export->args['category_orderby'] : 'ID' ),
				'order' => ( isset( $export->args['category_order'] ) ? $export->args['category_order'] : 'ASC' ),
			);
			if( $categories = woo_ce_get_product_categories( $category_args ) ) {
				$export->total_rows = count( $categories );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $categories as $category ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {
							if( isset( $category->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $category->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $category->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
				}
				unset( $categories, $category );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			break;

		// Tags
		case 'tag':
			$fields = woo_ce_get_tag_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_tag_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			$tag_args = array(
				'orderby' => ( isset( $export->args['tag_orderby'] ) ? $export->args['tag_orderby'] : 'ID' ),
				'order' => ( isset( $export->args['tag_order'] ) ? $export->args['tag_order'] : 'ASC' ),
			);
			if( $tags = woo_ce_get_product_tags( $tag_args ) ) {
				$export->total_rows = count( $tags );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $tags as $tag ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {
							if( isset( $tag->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $tag->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $tag->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
				}
				unset( $tags, $tag );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			break;

		// Brands
		case 'brand':
			$fields = woo_ce_get_brand_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_brand_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			$brand_args = array(
				'orderby' => ( isset( $export->args['brand_orderby'] ) ? $export->args['brand_orderby'] : 'ID' ),
				'order' => ( isset( $export->args['brand_order'] ) ? $export->args['brand_order'] : 'ASC' ),
			);
			if( $brands = woo_ce_get_product_brands( $brand_args ) ) {
				$export->total_rows = count( $brands );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $brands as $brand ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {
							if( isset( $brand->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $brand->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $brand->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
				}
				unset( $brands, $brand );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			break;

		// Orders
		case 'order':
			$fields = woo_ce_get_order_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				remove_filter( 'woo_ce_order_fields', 'woo_ce_override_order_field_labels', 11 );
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_order_field( $key );
				add_filter( 'woo_ce_order_fields', 'woo_ce_override_order_field_labels', 11 );
			}
			if( $export->args['order_items'] == 'unique' ) {
				$export->fields = woo_ce_unique_order_item_fields( $export->fields );
				$export->columns = woo_ce_unique_order_item_columns( $export->columns, $export->fields );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $orders = woo_ce_get_orders( 'order', $export->args ) ) {
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					$i = 0;
					foreach( $export->columns as $column ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $column, $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $column, $export->delimiter, $export->escape_formatting ) . $separator;
						$i++;
					}
				}
				if( !empty( $export->fields ) ) {

					foreach( $orders as $order ) {

						if( $export->export_format == 'xml' ) {
							$child = $output->addChild( $export->type );
							$child->addAttribute( 'id', $order->ID );
						}

						$order = woo_ce_get_order_data( $order, 'order', $export->args );
						if( in_array( $export->args['order_items'], array( 'combined', 'unique' ) ) ) {

							// Order items formatting: SPECK-IPHONE|INCASE-NANO|-
							foreach( $export->fields as $key => $field ) {
								if( isset( $order->$key ) ) {
									// Check if the field value is an array
									if( is_array( $field ) ) {
										foreach( $field as $array_key => $array_value ) {
											if( !is_array( $array_value ) ) {
												if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
													$output .= woo_ce_escape_csv_value( $array_value, $export->delimiter, $export->escape_formatting );
												else if( $export->export_format == 'xml' )
													$child->addChild( $array_key, htmlspecialchars( $array_value ) );
											}
										}
										unset( $array_key, $array_value );
									} else {
										if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
											$output .= woo_ce_escape_csv_value( $order->$key, $export->delimiter, $export->escape_formatting );
										else if( $export->export_format == 'xml' )
											$child->addChild( $key, htmlspecialchars( $order->$key ) );
									}
								}
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= $separator;
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output = substr( $output, 0, -1 ) . $line_ending;

						} else if( $export->args['order_items'] == 'individual' ) {

							// Order items formatting: SPECK-IPHONE<br />INCASE-NANO<br />-
							if( $order->order_items ) {
								$order->order_items_product_id = '';
								$order->order_items_variation_id = '';
								$order->order_items_sku = '';
								$order->order_items_name = '';
								$order->order_items_variation = '';
								$order->order_items_description = '';
								$order->order_items_excerpt = '';
								$order->order_items_tax_class = '';
								$order->order_items_quantity = '';
								$order->order_items_total = '';
								$order->order_items_subtotal = '';
								$order->order_items_rrp = '';
								$order->order_items_tax = '';
								$order->order_items_tax_subtotal = '';
								$order->order_items_type = '';
								$order->order_items_category = '';
								$order->order_items_tag = '';
								$order->order_items_weight = '';
								$order->order_items_total_weight = '';
								foreach( $order->order_items as $order_item ) {

									// Add Order Item weight to Shipping Weight
									if( $order_item->total_weight != '' )
										$order->shipping_weight = $order->shipping_weight + $order_item->total_weight;
									$order->order_items_product_id = $order_item->product_id;
									$order->order_items_variation_id = $order_item->variation_id;
									if( empty( $order_item->sku ) )
										$order_item->sku = '';
									$order->order_items_sku = $order_item->sku;
									$order->order_items_name = $order_item->name;
									$order->order_items_variation = $order_item->variation;
									$order->order_items_description = $order_item->description;
									$order->order_items_excerpt = $order_item->excerpt;
									$order->order_items_tax_class = $order_item->tax_class;
									$order->total_quantity += $order_item->quantity;
									$order->order_items_quantity = $order_item->quantity;
									$order->order_items_total = $order_item->total;
									$order->order_items_subtotal = $order_item->subtotal;
									$order->order_items_rrp = $order_item->rrp;
									$order->order_items_tax = $order_item->tax;
									$order->order_items_tax_subtotal = $order_item->tax_subtotal;
									$order->order_items_type = $order_item->type;
									$order->order_items_category = $order_item->category;
									$order->order_items_tag = $order_item->tag;
									$order->order_items_weight = $order_item->weight;
									$order->order_items_total_weight = $order_item->total_weight;
									$order = apply_filters( 'woo_ce_order_items_individual', $order, $order_item );
									foreach( $export->fields as $key => $field ) {
										if( isset( $order->$key ) ) {
											if( is_array( $order->$key ) ) {
												foreach( $order->$key as $array_key => $array_value ) {
													if( $export->export_format == 'xml' )
														$child->addAttribute( 'id', $order->ID );
													if( is_array( $array_value ) ) {
														if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
															$output .= woo_ce_escape_csv_array( $array_value, $child );
														else if( $export->export_format == 'xml' )
															$child->addChild( $key, htmlspecialchars( woo_ce_escape_csv_array( $array_value, $child ) ) );
													} else {
														if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
															$output .= woo_ce_escape_csv_value( $array_value, $export->delimiter, false );
														else if( $export->export_format == 'xml' )
															$child->addChild( $array_key, htmlspecialchars( $array_value ) );
													}
												}
											} else {
												if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
													$output .= woo_ce_escape_csv_value( $order->$key, $export->delimiter, $export->escape_formatting );
												else if( $export->export_format == 'xml' )
													$child->addChild( $key, htmlspecialchars( $order->$key ) );
											}
										}
										if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
											$output .= $separator;
									}
									if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
										$output = substr( $output, 0, -1 ) . $line_ending;
								}
							}
						}
					}
					unset( $orders, $order );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Customers
		case 'customer':
			$fields = woo_ce_get_customer_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_customer_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $customers = woo_ce_get_orders( 'customer', $export->args ) ) {
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $customers as $customer ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {
							if( isset( $customer->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $customer->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $customer->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
					unset( $customers, $customer );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Users
		case 'user':
			$fields = woo_ce_get_user_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_user_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $users = woo_ce_get_users( $export->args ) ) {
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					$i = 0;
					foreach( $export->columns as $column ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $column, $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $column, $export->delimiter, $export->escape_formatting ) . $separator;
						$i++;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $users as $user ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						$user = woo_ce_get_user_data( $user, $export->args );

						foreach( $export->fields as $key => $field ) {
							if( isset( $user->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $user->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $user->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;

					}
				}
				unset( $users, $user );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			break;

		// Coupons
		case 'coupon':
			$fields = woo_ce_get_coupon_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_coupon_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $coupons = woo_ce_get_coupons( $export->args ) ) {
				$export->total_rows = count( $coupons );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $coupons as $coupon ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						$coupon = woo_ce_get_coupon_data( $coupon, $export->args );
						foreach( $export->fields as $key => $field ) {

							if( isset( $coupon->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $coupon->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $coupon->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
					unset( $coupons, $coupon );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Subscriptions
		case 'subscription':
			$fields = woo_ce_get_subscription_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_subscription_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $subscriptions = woo_ce_get_subscriptions( $export->args ) ) {
				$export->total_rows = count( $subscriptions );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $subscriptions as $subscription ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {

							if( isset( $subscription->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $subscription->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $subscription->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;

						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
					unset( $subscriptions, $subscription );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Product Vendors
		case 'product_vendor':
			$fields = woo_ce_get_product_vendor_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_product_vendor_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $product_vendors = woo_ce_get_product_vendors( $export->args ) ) {
				$export->total_rows = count( $product_vendors );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $product_vendors as $product_vendor ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						$product_vendor = woo_ce_get_product_vendor_data( $product_vendor, $export->args );

						foreach( $export->fields as $key => $field ) {

							if( isset( $product_vendor->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $product_vendor->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $product_vendor->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;

						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
					unset( $product_vendors, $product_vendor );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Commissions
		case 'commission':
			$fields = woo_ce_get_commission_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_commission_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			if( $commissions = woo_ce_get_commissions( $export->args ) ) {
				$export->total_rows = count( $commissions );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $commissions as $commission ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						$commission = woo_ce_get_commission_data( $commission, $export->args );

						foreach( $export->fields as $key => $field ) {

							if( isset( $commission->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $commission->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $commission->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;

						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
					unset( $commissions, $commission );
				}
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Shipping Classes
		case 'shipping_class':
			$fields = woo_ce_get_shipping_class_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_shipping_class_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
			$shipping_class_args = array(
				'orderby' => ( isset( $export->args['shipping_class_orderby'] ) ? $export->args['shipping_class_orderby'] : 'ID' ),
				'order' => ( isset( $export->args['shipping_class_order'] ) ? $export->args['shipping_class_order'] : 'ASC' ),
			);
			if( $shipping_classes = woo_ce_get_shipping_classes( $shipping_class_args ) ) {
				$export->total_rows = count( $shipping_classes );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $shipping_classes as $shipping_class ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type );

						foreach( $export->fields as $key => $field ) {
							if( isset( $shipping_class->$key ) ) {
								if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
									$output .= woo_ce_escape_csv_value( $shipping_class->$key, $export->delimiter, $export->escape_formatting );
								else if( $export->export_format == 'xml' )
									$child->addChild( $key, htmlspecialchars( $shipping_class->$key ) );
							}
							if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
								$output .= $separator;
						}
						if( in_array( $export->export_format, array( 'csv', 'xls' ) ) )
							$output = substr( $output, 0, -1 ) . $line_ending;
					}
				}
				unset( $shipping_classes, $shipping_class );
			}
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

		// Attributes
		case 'attribute':
			$fields = woo_ce_get_attribute_fields( 'summary' );
			if( $export->fields = array_intersect_assoc( (array)$export->fields, $fields ) ) {
				foreach( $export->fields as $key => $field )
					$export->columns[] = woo_ce_get_attribute_field( $key );
			}
			$export->data_memory_start = woo_ce_current_memory_usage();
/*
			if( $attributes = woo_ce_get_attributes( $export->args ) ) {
				$export->total_rows = count( $attributes );
				$export->total_columns = $size = count( $export->columns );
				// Generate the export headers
				if( $export->header_formatting && in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
					for( $i = 0; $i < $size; $i++ ) {
						if( $i == ( $size - 1 ) )
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $line_ending;
						else
							$output .= woo_ce_escape_csv_value( $export->columns[$i], $export->delimiter, $export->escape_formatting ) . $separator;
					}
				}
				if( !empty( $export->fields ) ) {
					foreach( $atributes as $attribute ) {

						if( $export->export_format == 'xml' )
							$child = $output->addChild( $export->type, 0, -1 );

					}
				}
			}
*/
			$export->data_memory_end = woo_ce_current_memory_usage();
			unset( $export->fields );
			break;

	}
	// Export completed successfully
	delete_transient( WOO_CD_PREFIX . '_running' );
	// Check that the export file is populated, export columns have been assigned and rows counted
	if( $output && $export->total_rows && $export->total_columns ) {
		if( in_array( $export->export_format, array( 'csv', 'xls' ) ) ) {
			$output = woo_ce_file_encoding( $output );
			if( $export->export_format == 'csv' && $export->bom && ( WOO_CD_DEBUG == false ) )
				$output = "\xEF\xBB\xBF" . $output;
			else if( $export->export_format == 'xls' && $export->bom && ( WOO_CD_DEBUG == false ) )
				$output = "\xEF\xBB\xBF" . $output;
				// $output = "\xFF\xFE" . $output;
		} else if( $export->export_format == 'xml' && WOO_CD_DEBUG ) {
			$output = woo_ce_format_xml( $output );
		}
		if( WOO_CD_DEBUG && ( !$export->cron && !$export->scheduled_export ) ) {
			$response = set_transient( WOO_CD_PREFIX . '_debug_log', base64_encode( $output ), woo_ce_get_option( 'timeout', MINUTE_IN_SECONDS ) );
			if( $response !== true ) {
				$message = __( 'The export contents were too large to store in a single WordPress transient, use the Volume offset / Limit volume options to reduce the size of your export and try again.', 'woo_ce' ) . ' (<a href="' . $troubleshooting_url . '" target="_blank">' . __( 'Need help?', 'woo_ce' ) . '</a>)';
				if( function_exists( 'woo_cd_admin_notice' ) )
					woo_cd_admin_notice( $message, 'error' );
				else
					error_log( sprintf( '[store-exporter-deluxe] woo_ce_export_dataset() - %s', $message ) );
			}
		} else {
			return $output;
		}
	}

}

// List of Export types used on Store Exporter screen
function woo_ce_return_export_types() {

	$types = array();
	$types['product'] = __( 'Products', 'woo_ce' );
	$types['category'] = __( 'Categories', 'woo_ce' );
	$types['tag'] = __( 'Tags', 'woo_ce' );
	$types['brand'] = __( 'Brands', 'woo_ce' );
	$types['order'] = __( 'Orders', 'woo_ce' );
	$types['customer'] = __( 'Customers', 'woo_ce' );
	$types['user'] = __( 'Users', 'woo_ce' );
	$types['coupon'] = __( 'Coupons', 'woo_ce' );
	$types['subscription'] = __( 'Subscriptions', 'woo_ce' );
	$types['product_vendor'] = __( 'Product Vendors', 'woo_ce' );
	$types['commission'] = __( 'Commission', 'woo_ce' );
	$types['shipping_class'] = __( 'Shipping Classes', 'woo_ce' );
	// $types['attribute'] = __( 'Attributes', 'woo_ce' );
	$types = apply_filters( 'woo_ce_types', $types );
	return $types;

}

// Returns the Post object of the export file saved as an attachment to the WordPress Media library
function woo_ce_save_file_attachment( $filename = '', $post_mime_type = 'text/csv' ) {

	if( !empty( $filename ) ) {
		$post_type = 'woo-export';
		$args = array(
			'post_title' => $filename,
			'post_type' => $post_type,
			'post_mime_type' => $post_mime_type
		);
		$post_ID = wp_insert_attachment( $args, $filename );
		if( is_wp_error( $post_ID ) )
			error_log( sprintf( '[store-exporter-deluxe] save_file_attachment() - $s: %s', $filename, $result->get_error_message() ) );
		else
			return $post_ID;
	}

}

// Updates the GUID of the export file attachment to match the correct file URL
function woo_ce_save_file_guid( $post_ID, $export_type, $upload_url = '' ) {

	add_post_meta( $post_ID, '_woo_export_type', $export_type );
	if( !empty( $upload_url ) ) {
		$args = array(
			'ID' => $post_ID,
			'guid' => $upload_url
		);
		wp_update_post( $args );
	}

}

// Save critical export details against the archived export
function woo_ce_save_file_details( $post_ID ) {

	global $export;

	add_post_meta( $post_ID, '_woo_start_time', $export->start_time );
	add_post_meta( $post_ID, '_woo_idle_memory_start', $export->idle_memory_start );
	add_post_meta( $post_ID, '_woo_columns', $export->total_columns );
	add_post_meta( $post_ID, '_woo_rows', $export->total_rows );
	add_post_meta( $post_ID, '_woo_data_memory_start', $export->data_memory_start );
	add_post_meta( $post_ID, '_woo_data_memory_end', $export->data_memory_end );

}

// Update detail of existing archived export
function woo_ce_update_file_detail( $post_ID, $detail, $value ) {

	if( strstr( $detail, '_woo_' ) !== false )
		update_post_meta( $post_ID, $detail, $value );

}

// Returns a list of allowed Export type statuses, can be overridden on a per-Export type basis
function woo_ce_post_statuses( $extra_status = array(), $override = false ) {

	$output = array(
		'publish',
		'pending',
		'draft',
		'future',
		'private',
		'trash'
	);
	if( $override ) {
		$output = $extra_status;
	} else {
		if( $extra_status )
			$output = array_merge( $output, $extra_status );
	}
	return $output;

}

function woo_ce_add_missing_mime_type( $mime_types = array() ) {

	// Add CSV mime type if it has been removed
	if( !isset( $mime_types['csv'] ) )
		$mime_types['csv'] = 'text/csv';
	// Add XML mime type if it has been removed
	if( !isset( $mime_types['xml'] ) )
		$mime_types['xml'] = 'xml/application';
	// Add XLS mime type if it has been removed
	if( !isset( $mime_types['xls'] ) )
		$mime_types['xls'] = 'application/vnd.ms-excel';
	return $mime_types;

}
add_filter( 'upload_mimes', 'woo_ce_add_missing_mime_type', 10, 1 );

if( !function_exists( 'woo_ce_sort_fields' ) ) {
	function woo_ce_sort_fields( $key ) {

		return $key;

	}
}

function woo_ce_cron_schedules( $schedule = array() ) {

	$interval = woo_ce_get_option( 'auto_interval', 1440 );
	$schedule['woo_ce_auto_interval'] = array(
		'interval' => (int)$interval * 60,
		'display'  => sprintf( __( 'Every %d minutes', 'woo_ce' ), (int)$interval )
	);
	return $schedule;

}

function woo_ce_next_scheduled_export() {

	// Check that WordPress has set up a wp_cron for our export
	if( wp_next_scheduled( 'woo_ce_auto_export_schedule' ) ) {
		$cron = ( function_exists( '_get_cron_array' ) ? _get_cron_array() : array() );
		if( !empty( $cron ) ) {
			foreach( $cron as $timestamp => $cronhooks ) {
				foreach ( (array) $cronhooks as $hook => $events ) {
					if( $hook == 'woo_ce_auto_export_schedule' )
						return human_time_diff( current_time( 'timestamp', 1 ), $timestamp );
				}
			}
		}
		unset( $cron );
	}

}

function woo_ce_cron_activation( $force_reload = false ) {

	if( woo_ce_get_option( 'enable_auto', 0 ) == 0 || $force_reload ) {
		wp_clear_scheduled_hook( 'woo_ce_auto_export_schedule' );
		return;
	}

	$interval = woo_ce_get_option( 'auto_interval', 1440 );
	if( !wp_next_scheduled( 'woo_ce_auto_export_schedule' ) )
		wp_schedule_event( strtotime( (int)$interval * 60 ), 'woo_ce_auto_interval', 'woo_ce_auto_export_schedule' );

}

function woo_ce_auto_export() {

	$export_method = woo_ce_get_option( 'auto_method', 'archive' );
	$export_type = woo_ce_get_option( 'auto_type', '' );
	$order_filter_status = woo_ce_get_option( 'auto_order_status', '' );
	if( !empty( $export_type ) ) {
		if( in_array( $export_method, array( 'archive', 'email', 'post', 'ftp' ) ) )
			woo_ce_cron_export( $export_method, $export_type, true );
		else
			woo_ce_cron_export( '', $export_type, true );
	}
	if( WOO_CD_DEBUG )
		error_log( sprintf( '[store-exporter-deluxe] Scheduled export ran: %s - %s', $export_method, $export_type ) );

}

// Add Store Export to filter types on the WordPress Media screen
function woo_ce_add_post_mime_type( $post_mime_types = array() ) {

	$post_mime_types['text/csv'] = array( __( 'Store Exports (CSV)', 'woo_ce' ), __( 'Manage Store Exports (CSV)', 'woo_ce' ), _n_noop( 'Store Export - CSV <span class="count">(%s)</span>', 'Store Exports - CSV <span class="count">(%s)</span>' ) );
	$post_mime_types['xml/application'] = array( __( 'Store Exports (XML)', 'woo_ce' ), __( 'Manage Store Exports (XML)', 'woo_ce' ), _n_noop( 'Store Export - XML <span class="count">(%s)</span>', 'Store Exports - XML <span class="count">(%s)</span>' ) );
	$post_mime_types['application/vnd.ms-excel'] = array( __( 'Store Exports (Excel)', 'woo_ce' ), __( 'Manage Store Exports (Excel)', 'woo_ce' ), _n_noop( 'Store Export - Excel <span class="count">(%s)</span>', 'Store Exports - Excel <span class="count">(%s)</span>' ) );
	return $post_mime_types;

}
add_filter( 'post_mime_types', 'woo_ce_add_post_mime_type' );

function woo_ce_current_memory_usage() {

	$output = '';
	if( function_exists( 'memory_get_usage' ) )
		$output = round( memory_get_usage( true ) / 1024 / 1024, 2 );
	return $output;

}

function woo_ce_get_start_of_week_day() {

	global $wp_locale;

	$output = 'Monday';
	$start_of_week = get_option( 'start_of_week', 0 );
	for( $day_index = 0; $day_index <= 6; $day_index++ ) {
		if( $start_of_week == $day_index ) {
			$output = $wp_locale->get_weekday( $day_index );
			break;
		}
	}
	return $output;

}

// Provided by Pippin Williamson, mentioned on WP Beginner (http://www.wpbeginner.com/wp-tutorials/how-to-display-a-users-ip-address-in-wordpress/)
function woo_ce_get_visitor_ip_address() {

	if( !empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
		//check ip from share internet
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		//to check ip is pass from proxy
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return apply_filters( 'woo_ce_get_visitor_ip_address', $ip );

}

function woo_ce_get_line_ending() {

	$output = "\n";
	$line_ending_formatting = woo_ce_get_option( 'line_ending_formatting', 'windows' );
	if( $line_ending_formatting == false || $line_ending_formatting == '' ) {
		error_log( '[store-exporter-deluxe] Line ending formatting export option was corrupted, defaulted to windows' );
		$line_ending_formatting = 'windows';
		woo_ce_update_option( 'line_ending_formatting', 'windows' );
	}
	switch( $line_ending_formatting ) {

		case 'windows':
			$output = "\n";
			break;

		case 'mac':
			$output = "\r";
			break;

		case 'unix':
			$output = "\n";
			break;

	}
	return $output;

}

function woo_ce_get_option( $option = null, $default = false, $allow_empty = false ) {

	$output = false;
	if( $option !== null ) {
		$separator = '_';
		$output = get_option( WOO_CD_PREFIX . $separator . $option, $default );
		if( $allow_empty == false && $output != 0 && ( $output == false || $output == '' ) )
			$output = $default;
	}
	return $output;

}

function woo_ce_update_option( $option = null, $value = null ) {

	$output = false;
	if( $option !== null && $value !== null ) {
		$separator = '_';
		$output = update_option( WOO_CD_PREFIX . $separator . $option, $value );
	}
	return $output;

}
?>