<?php
function woo_ce_export_settings_quicklinks() {

	ob_start(); ?>
<li>| <a href="#xml-settings"><?php _e( 'XML Settings', 'woo_ce' ); ?></a> |</li>
<li><a href="#scheduled-exports"><?php _e( 'Scheduled Exports', 'woo_ce' ); ?></a> |</li>
<li><a href="#cron-exports"><?php _e( 'CRON Exports', 'woo_ce' ); ?></a></li>
<?php
	ob_end_flush();

}

function woo_ce_export_settings_additional() {

	$email_to = woo_ce_get_option( 'email_to', get_option( 'admin_email', '' ) );
	$email_subject = woo_ce_get_option( 'email_subject', '' );
	// Default subject
	if( empty( $email_subject ) )
		$email_subject = __( '[%store_name%] Export: %export_type% (%export_filename%)', 'woo_ce' );
	$post_to = woo_ce_get_option( 'post_to', '' );
	$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';
	ob_start(); ?>
<tr>
	<th>
		<label for="email_to"><?php _e( 'Default e-mail recipient', 'woo_ce' ); ?></label>
	</th>
	<td>
		<input name="email_to" type="text" id="email_to" value="<?php echo esc_attr( $email_to ); ?>" class="regular-text code" />
		<p class="description"><?php _e( 'Set the default recipient of scheduled export e-mails, can be overriden via CRON using the <code>to</code> argument. Default is the WordPress Blog administrator e-mail address.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="email_subject"><?php _e( 'Default e-mail subject', 'woo_ce' ); ?></label>
	</th>
	<td>
		<input name="email_subject" type="text" id="email_subject" value="<?php echo esc_attr( $email_subject ); ?>" class="large-text code" />
		<p class="description"><?php _e( 'Set the default subject of scheduled export e-mails, can be overriden via CRON using the <code>subject</code> argument. Tags can be used: <code>%store_name%</code>, <code>%export_type%</code>, <code>%export_filename%</code>.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="post_to"><?php _e( 'Default remote POST URL', 'woo_ce' ); ?></label>
	</th>
	<td>
		<input name="post_to" type="text" id="post_to" value="<?php echo esc_url( $post_to ); ?>" class="full-text code" />
		<p class="description"><?php printf( __( 'Set the default remote POST address for scheduled exports, can be overriden via CRON using the <code>to</code> argument. Default is empty. See our <a href="%s" target="_blank">Usage</a> document for more information on Default remote POST URL.', 'woo_ce' ), $troubleshooting_url ); ?></p>
	</td>
</tr>
<?php
	ob_end_flush();
	
}

function woo_ce_export_settings_csv() {

	$header_formatting = woo_ce_get_option( 'header_formatting', 1 );
	ob_start(); ?>
<tr>
	<th>
		<label for="header_formatting"><?php _e( 'Header formatting', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul style="margin-top:0.2em;">
			<li><label><input type="radio" name="header_formatting" value="1"<?php checked( $header_formatting, '1' ); ?> />&nbsp;<?php _e( 'Include export field column headers', 'woo_ce' ); ?></label></li>
			<li><label><input type="radio" name="header_formatting" value="0"<?php checked( $header_formatting, '0' ); ?> />&nbsp;<?php _e( 'Disregard export field column headers', 'woo_ce' ); ?></label></li>
		</ul>
		<p class="description"><?php _e( 'Choose the header format that suits your spreadsheet software (e.g. Excel, OpenOffice, etc.). This rule applies to both CSV and Excel 2007 (XLS) export types.', 'woo_ce' ); ?></p>
	</td>
</tr>
<?php
	ob_end_flush();
	
}

// Returns the HTML template for the Enable CRON and Secret Export Key options for the Settings screen
function woo_ce_export_settings_cron() {

	// XML settings
	$xml_attribute_url = woo_ce_get_option( 'xml_attribute_url', 1 );
	$xml_attribute_title = woo_ce_get_option( 'xml_attribute_title', 1 );
	$xml_attribute_date = woo_ce_get_option( 'xml_attribute_date', 1 );
	$xml_attribute_time = woo_ce_get_option( 'xml_attribute_time', 0 );
	$xml_attribute_export = woo_ce_get_option( 'xml_attribute_export', 1 );
	$xml_attribute_orderby = woo_ce_get_option( 'xml_attribute_orderby', 0 );
	$xml_attribute_order = woo_ce_get_option( 'xml_attribute_order', 0 );
	$xml_attribute_limit = woo_ce_get_option( 'xml_attribute_limit', 0 );
	$xml_attribute_offset = woo_ce_get_option( 'xml_attribute_offset', 0 );

	// Scheduled exports
	$enable_auto = woo_ce_get_option( 'enable_auto', 0 );
	if( $enable_auto == 1 ) {
		if( ( $next_export = woo_ce_next_scheduled_export() ) == false )
			$next_export = __( 'a little while...', 'woo_ce' );
	}
	$auto_type = woo_ce_get_option( 'auto_type', 'product' );
	$types = woo_ce_return_export_types();
	$order_statuses = woo_ce_get_order_statuses();
	$product_types = woo_ce_get_product_types();
	$args = array(
		'hide_empty' => 1
	);
	$product_categories = woo_ce_get_product_categories( $args );
	$product_tags = woo_ce_get_product_tags( $args );

	$product_filter_type = woo_ce_get_option( 'auto_product_type', array() );
	$product_filter_stock = woo_ce_get_option( 'auto_product_stock', false );
	$product_filter_category = woo_ce_get_option( 'auto_product_category', array() );
	$product_filter_tag = woo_ce_get_option( 'auto_product_tag', array() );
	$order_filter_status = woo_ce_get_option( 'auto_order_status', '' );
	$order_filter_date = woo_ce_get_option( 'auto_order_date', false );
	$order_filter_dates_from = woo_ce_get_option( 'auto_order_dates_from', '' );
	$order_filter_dates_to = woo_ce_get_option( 'auto_order_dates_to', '' );
	$order_filter_date_variable = woo_ce_get_option( 'auto_order_date_variable', '' );
	$order_filter_date_variable_length = woo_ce_get_option( 'auto_order_date_variable_length', '' );

	$auto_interval = woo_ce_get_option( 'auto_interval', 1440 );
	$auto_format = woo_ce_get_option( 'auto_format', 'csv' );
	$auto_method = woo_ce_get_option( 'auto_method', 'archive' );
	$ftp_method_host = woo_ce_get_option( 'auto_ftp_method_host', '' );
	$ftp_method_user = woo_ce_get_option( 'auto_ftp_method_user', '' );
	$ftp_method_pass = woo_ce_get_option( 'auto_ftp_method_pass', '' );
	$ftp_method_port = woo_ce_get_option( 'auto_ftp_method_port', '' );
	$ftp_method_path = woo_ce_get_option( 'auto_ftp_method_path', '' );
	$ftp_method_passive = woo_ce_get_option( 'auto_ftp_method_passive', '' );
	$ftp_method_timeout = woo_ce_get_option( 'auto_ftp_method_timeout', '' );
	$scheduled_fields = woo_ce_get_option( 'scheduled_fields', 'all' );

	// CRON exports
	$enable_cron = woo_ce_get_option( 'enable_cron', 0 );
	$secret_key = woo_ce_get_option( 'secret_key', '' );
	$cron_fields = woo_ce_get_option( 'cron_fields', 'all' );

	$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/';
	ob_start(); ?>
<tr id="xml-settings">
	<td colspan="2" style="padding:0;">
		<hr />
		<h3><div class="dashicons dashicons-media-code"></div>&nbsp;<?php _e( 'XML Settings', 'woo_ce' ); ?></h3>
	</td>
</tr>
<tr>
	<th>
		<label><?php _e( 'Attribute display', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul>
			<li><label><input type="checkbox" name="xml_attribute_url" value="1"<?php checked( $xml_attribute_url ); ?> /> <?php _e( 'Site Address', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_title" value="1"<?php checked( $xml_attribute_title ); ?> /> <?php _e( 'Site Title', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_date" value="1"<?php checked( $xml_attribute_date ); ?> /> <?php _e( 'Export Date', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_time" value="1"<?php checked( $xml_attribute_time ); ?> /> <?php _e( 'Export Time', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_export" value="1"<?php checked( $xml_attribute_export ); ?> /> <?php _e( 'Export Type', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_orderby" value="1"<?php checked( $xml_attribute_orderby ); ?> /> <?php _e( 'Export Order By', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_order" value="1"<?php checked( $xml_attribute_order ); ?> /> <?php _e( 'Export Order', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_limit" value="1"<?php checked( $xml_attribute_limit ); ?> /> <?php _e( 'Limit Volume', 'woo_ce' ); ?></label></li>
			<li><label><input type="checkbox" name="xml_attribute_offset" value="1"<?php checked( $xml_attribute_offset ); ?> /> <?php _e( 'Volume Offset', 'woo_ce' ); ?></label></li>
		</ul>
		<p class="description"><?php _e( 'Control the visibility of different attributes in the XML export.', 'woo_ce' ); ?></p>
	</td>
</tr>

<tr id="scheduled-exports">
	<td colspan="2" style="padding:0;">
		<hr />
		<h3><div class="dashicons dashicons-calendar"></div>&nbsp;<?php _e( 'Scheduled Exports', 'woo_ce' ); ?></h3>
<?php if( $enable_auto == 1 ) { ?>
		<p style="font-size:0.8em;"><div class="dashicons dashicons-yes"></div>&nbsp;<strong><?php printf( __( 'Scheduled Exports is enabled, next scheduled export will run in %s', 'woo_ce' ), $next_export ); ?></strong></p>
<?php } ?>
		<p class="description"><?php _e( 'Configure Store Exporter Deluxe to automatically generate exports.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="enable_auto"><?php _e( 'Enable scheduled exports', 'woo_ce' ); ?></label>
	</th>
	<td>
		<select id="enable_auto" name="enable_auto">
			<option value="1"<?php selected( $enable_auto, 1 ); ?>><?php _e( 'Yes', 'woo_ce' ); ?></option>
			<option value="0"<?php selected( $enable_auto, 0 ); ?>><?php _e( 'No', 'woo_ce' ); ?></option>
		</select>
		<p class="description"><?php _e( 'Enabling Scheduled Exports will trigger automated exports at the interval specified under Once every (minutes).', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="auto_type"><?php _e( 'Export type', 'woo_ce' ); ?></label>
	</th>
	<td>
		<select id="auto_type" name="auto_type">
<?php if( $types ) { ?>
	<?php foreach( $types as $key => $type ) { ?>
			<option value="<?php echo $key; ?>"<?php selected( $auto_type, $key ); ?>><?php echo $type; ?></option>
	<?php } ?>
<?php } else { ?>
			<option value=""><?php _e( 'No export types were found.', 'woo_ce' ); ?></option>
<?php } ?>
		</select>
		<p class="description"><?php _e( 'Select the data type you want to export.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr class="auto_type_options">
	<th>
		<label><?php _e( 'Export filters', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul>

			<li class="export-options product-options">
				<label><?php _e( 'Product Type', 'woo_ce' ); ?></label>
<?php if( $product_types ) { ?>
				<ul style="margin-top:0.2em;">
	<?php foreach( $product_types as $key => $product_type ) { ?>
					<li><label><input type="checkbox" name="product_filter_type[]" value="<?php echo $key; ?>"<?php checked( in_array( $key, $product_filter_type ), true ); ?> /> <?php echo woo_ce_format_product_type( $product_type['name'] ); ?> (<?php echo $product_type['count']; ?>)</label></li>
	<?php } ?>
				</ul>
<?php } ?>
				<p class="description"><?php _e( 'Select the Product Type\'s you want to filter exported Products by. Default is to include all Product Types and Variations.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options product-options">
				<label><?php _e( 'Stock Status', 'woo_ce' ); ?></label>
				<ul style="margin-top:0.2em;">
					<li><label><input type="radio" name="product_filter_stock" value=""<?php checked( $product_filter_stock, false ); ?> /> <?php _e( 'Both', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="product_filter_stock" value="instock"<?php checked( $product_filter_stock, 'instock' ); ?> /> <?php _e( 'In stock', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="product_filter_stock" value="outofstock"<?php checked( $product_filter_stock, 'outofstock' ); ?> /> <?php _e( 'Out of stock', 'woo_ce' ); ?></label></li>
				</ul>
				<p class="description"><?php _e( 'Select the Stock Status\'s you want to filter exported Products by. Default is to include all Stock Status\'s.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options product-options">
				<label><?php _e( 'Product Category', 'woo_ce' ); ?></label>
<?php if( $product_categories ) { ?>
				<ul style="margin-top:0.2em;">
	<?php foreach( $product_categories as $product_category ) { ?>
					<li>
						<label><input type="checkbox" name="product_filter_category[]" value="<?php echo $product_category->term_id; ?>"<?php checked( in_array( $product_category->term_id, $product_filter_category ), true ); ?> /> <?php echo $product_category->name; ?></label>
						<span class="description">(<?php echo $product_category->count; ?>)</span>
					</li>
	<?php } ?>
				</ul>
<?php } ?>
				<p class="description"><?php _e( 'Select the Product Category\'s you want to filter exported Products by. Default is to include all Product Categories.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options product-options">
				<label><?php _e( 'Product Tag', 'woo_ce' ); ?></label>
<?php if( $product_categories ) { ?>
				<ul style="margin-top:0.2em;">
	<?php foreach( $product_tags as $product_tag ) { ?>
					<li>
						<label><input type="checkbox" name="product_filter_tag[]" value="<?php echo $product_tag->term_id; ?>"<?php checked( in_array( $product_tag->term_id, $product_filter_tag ), true ); ?> /> <?php echo $product_tag->name; ?></label>
						<span class="description">(<?php echo $product_tag->count; ?>)</span>
					</li>
	<?php } ?>
				</ul>
<?php } ?>
				<p class="description"><?php _e( 'Select the Product Tag\'s you want to filter exported Products by. Default is to include all Product Tags.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options order-options">
				<label><?php _e( 'Order Status', 'woo_ce' ); ?></label>
				<select name="order_filter_status">
					<option value=""<?php selected( $order_filter_status, '' ); ?>><?php _e( 'All', 'woo_ce' ); ?></option>
<?php if( $order_statuses ) { ?>
	<?php foreach( $order_statuses as $order_status ) { ?>
					<option value="<?php echo $order_status->slug; ?>"<?php selected( $order_filter_status, $order_status->slug ); ?>><?php echo ucfirst( $order_status->name ); ?></option>
	<?php } ?>
<?php } ?>
				</select>
				<p class="description"><?php _e( 'Select the Order Status you want to filter exported Orders by. Default is to include all Order Status options.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options order-options">
				<label><?php _e( 'Order Date', 'woo_ce' ); ?></label>
				<ul style="margin-top:0.2em;">
					<li><label><input type="radio" name="order_dates_filter" value=""<?php checked( $order_filter_date, false ); ?> /><?php _e( 'All', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="today"<?php checked( $order_filter_date, 'today' ); ?> /><?php _e( 'Today', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="yesterday"<?php checked( $order_filter_date, 'yesterday' ); ?> /><?php _e( 'Yesterday', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="current_week"<?php checked( $order_filter_date, 'current_week' ); ?> /><?php _e( 'Current week', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="last_week"<?php checked( $order_filter_date, 'last_week' ); ?> /><?php _e( 'Last week', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="current_month"<?php checked( $order_filter_date, 'current_month' ); ?> /><?php _e( 'Current month', 'woo_ce' ); ?></label></li>
					<li><label><input type="radio" name="order_dates_filter" value="last_month"<?php checked( $order_filter_date, 'last_month' ); ?> /><?php _e( 'Last month', 'woo_ce' ); ?></label></li>
					<li>
						<label><input type="radio" name="order_dates_filter" value="variable"<?php checked( $order_filter_date, 'variable' ); ?> /><?php _e( 'Variable date', 'woo_ce' ); ?></label>
						<div style="margin-top:0.2em;">
							<?php _e( 'Last', 'woo_ce' ); ?>
							<input type="text" name="order_dates_filter_variable" class="text" size="4" value="<?php echo $order_filter_date_variable; ?>" />
							<select name="order_dates_filter_variable_length">
								<option value=""<?php selected( $order_filter_date_variable_length, '' ); ?>>&nbsp;</option>
								<option value="second"<?php selected( $order_filter_date_variable_length, 'second' ); ?>><?php _e( 'second(s)', 'woo_ce' ); ?></option>
								<option value="minute"<?php selected( $order_filter_date_variable_length, 'minute' ); ?>><?php _e( 'minute(s)', 'woo_ce' ); ?></option>
								<option value="hour"<?php selected( $order_filter_date_variable_length, 'hour' ); ?>><?php _e( 'hour(s)', 'woo_ce' ); ?></option>
								<option value="day"<?php selected( $order_filter_date_variable_length, 'day' ); ?>><?php _e( 'day(s)', 'woo_ce' ); ?></option>
								<option value="week"<?php selected( $order_filter_date_variable_length, 'week' ); ?>><?php _e( 'week(s)', 'woo_ce' ); ?></option>
								<option value="month"<?php selected( $order_filter_date_variable_length, 'month' ); ?>><?php _e( 'month(s)', 'woo_ce' ); ?></option>
								<option value="year"<?php selected( $order_filter_date_variable_length, 'year' ); ?>><?php _e( 'year(s)', 'woo_ce' ); ?></option>
							</select>
						</div>
					</li>
					<li>
						<label><input type="radio" name="order_dates_filter" value="manual"<?php checked( $order_filter_date, 'manual' ); ?> /><?php _e( 'Fixed date', 'woo_ce' ); ?></label>
						<div style="margin-top:0.2em;">
							<input type="text" name="order_dates_from" value="<?php echo $order_filter_dates_from; ?>" size="10" maxlength="10" class="text datepicker" /> to <input type="text" name="order_dates_to" value="<?php echo $order_filter_dates_to; ?>" size="10" maxlength="10" class="text datepicker" />
						</div>
					</li>
				</ul>
				<p class="description"><?php _e( 'Filter the dates of Orders to be included in the export. If manually selecting dates ensure the Fixed date radio field is checked, likewise for variable dates. Default is to include all Orders made.', 'woo_ce' ); ?></p>
			</li>

			<li class="export-options category-options tag-options brand-options customer-options user-options coupon-options subscription-options product_vendor-options">
				<p><?php _e( 'No export filter options are available for this export type.', 'woo_ce' ); ?></p>
			</li>

		</ul>
	</td>
</tr>
<tr>
	<th>
		<label for="auto_interval"><?php _e( 'Once every (minutes)', 'woo_ce' ); ?></label>
	</th>
	<td>
		<input name="auto_interval" type="text" id="auto_interval" value="<?php echo esc_attr( $auto_interval ); ?>" size="4" maxlength="4" class="text" />
		<p class="description"><?php _e( 'Choose how often Store Exporter Deluxe generates new exports. Default is every 1440 minutes (once every 24 hours).', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label><?php _e( 'Export format', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul style="margin-top:0.2em;">
			<li><label><input type="radio" name="auto_format" value="csv"<?php checked( $auto_format, 'csv' ); ?> /> <?php _e( 'CSV', 'woo_ce' ); ?> <span class="description"><?php _e( '(Comma separated values)', 'woo_ce' ); ?></span></label></li>
			<li><label><input type="radio" name="auto_format" value="xml"<?php checked( $auto_format, 'xml' ); ?> /> <?php _e( 'XML', 'woo_ce' ); ?> <span class="description"><?php _e( '(EXtensible Markup Language)', 'woo_ce' ); ?></label></li>
			<li><label><input type="radio" name="auto_format" value="xls"<?php checked( $auto_format, 'xls' ); ?> /> <?php _e( 'Excel (XLS)', 'woo_ce' ); ?> <span class="description"><?php _e( '(Microsoft Excel 2007)', 'woo_ce' ); ?></label></li>
		</ul>
		<p class="description"><?php _e( 'Adjust the export format to generate different export file formats. Default is CSV.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="auto_method"><?php _e( 'Export method', 'woo_ce' ); ?></label>
	</th>
	<td>
		<select id="auto_method" name="auto_method">
			<option value="archive"<?php selected( $auto_method, 'archive' ); ?>><?php _e( 'Archive to WordPress Media', 'woo_ce' ); ?></option>
			<option value="email"<?php selected( $auto_method, 'email' ); ?>><?php _e( 'Send as e-mail', 'woo_ce' ); ?></option>
			<option value="post"<?php selected( $auto_method, 'post' ); ?>><?php _e( 'POST to remote URL', 'woo_ce' ); ?></option>
			<option value="ftp"<?php selected( $auto_method, 'ftp' ); ?>><?php _e( 'Upload to remote FTP', 'woo_ce' ); ?></option>
		</select>
		<p class="description"><?php _e( 'Choose what Store Exporter Deluxe does with the generated export. Default is to archive the export to the WordPress Media for archival purposes.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr class="auto_method_options">
	<th>
		<label><?php _e( 'Export method options', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul>
			<li class="export-options ftp-options">
				<label for="ftp_method_host"><?php _e( 'Host', 'woo_ce' ); ?>:</label> <input type="text" id="ftp_method_host" name="ftp_method_host" size="15" class="regular-text code" value="<?php echo sanitize_text_field( $ftp_method_host ); ?>" /><br />
				<label for="ftp_method_user"><?php _e( 'Username', 'woo_ce' ); ?>:</label> <input type="text" id="ftp_method_user" name="ftp_method_user" size="15" class="regular-text code" value="<?php echo sanitize_text_field( $ftp_method_user ); ?>" /><br />
				<label for="ftp_method_pass"><?php _e( 'Password', 'woo_ce' ); ?>:</label> <input type="password" id="ftp_method_pass" name="ftp_method_pass" size="15" class="regular-text code" value="" /><?php if( !empty( $ftp_method_pass ) ) { echo ' ' . __( '(password is saved)', 'woo_ce' ); } ?><br />
				<label for="ftp_method_port"><?php _e( 'Port', 'woo_ce' ); ?>:</label> <input type="text" id="ftp_method_port" name="ftp_method_port" size="5" class="short-text code" value="<?php echo sanitize_text_field( $ftp_method_port ); ?>" maxlength="5" /><br />
				<label for="ftp_method_file_path"><?php _e( 'File path', 'woo_ce' ); ?>:</label> <input type="text" id="ftp_method_file_path" name="ftp_method_path" size="25" class="regular-text code" value="<?php echo sanitize_text_field( $ftp_method_path ); ?>" /><br />
				<label for="ftp_method_passive"><?php _e( 'Transfer mode', 'woo_ce' ); ?>:</label> 
				<select id="ftp_method_passive" name="ftp_method_passive">
					<option value="auto"<?php selected( $ftp_method_passive, '' ); ?>><?php _e( 'Auto', 'woo_ce' ); ?></option>
					<option value="active"<?php selected( $ftp_method_passive, 'active' ); ?>><?php _e( 'Active', 'woo_ce' ); ?></option>
					<option value="passive"<?php selected( $ftp_method_passive, 'passive' ); ?>><?php _e( 'Passive', 'woo_ce' ); ?></option>
				</select><br />
				<label for="ftp_method_timeout"><?php _e( 'Timeout', 'woo_ce' ); ?>:</label> <input type="text" id="ftp_method_timeout" name="ftp_method_timeout" size="5" class="short-text code" value="<?php echo sanitize_text_field( $ftp_method_timeout ); ?>" /><br />
				<p class="description"><?php _e( 'Enter the FTP host, login details and path of where to save the export file, do not provide the filename, the export filename can be set on General Settings above. For file path example: <code>wp-content/uploads/exports/</code>', 'woo_ce' ); ?></p>
			</li>
			<li class="export-options archive-options email-options post-options">
				<p><?php _e( 'No export method options are available for this export method.', 'woo_ce' ); ?></p>
			</li>
		</ul>
	</td>
</tr>
<tr>
	<th>
		<label for="scheduled_fields"><?php _e( 'Export fields', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul style="margin-top:0.2em;">
			<li><label><input type="radio" id="scheduled_fields" name="scheduled_fields" value="all"<?php checked( $scheduled_fields, 'all' ); ?> /> <?php _e( 'Include all Export Fields for the requested Export Type', 'woo_ce' ); ?></label></li>
			<li><label><input type="radio" name="scheduled_fields" value="saved"<?php checked( $scheduled_fields, 'saved' ); ?> /> <?php _e( 'Use the saved Export Fields preference set on the Export screen for the requested Export Type', 'woo_ce' ); ?></label></li>
		</ul>
		<p class="description"><?php _e( 'Control whether all known export fields are included or only checked fields from the Export Fields section on the Export screen for each Export Type. Default is to include all export fields.', 'woo_ce' ); ?></p>
	</td>
</tr>

<tr id="cron-exports">
	<td colspan="2" style="padding:0;">
		<hr />
		<h3><div class="dashicons dashicons-clock"></div>&nbsp;<?php _e( 'CRON Exports', 'woo_ce' ); ?></h3>
<?php if( $enable_cron == 1 ) { ?>
		<p style="font-size:0.8em;"><div class="dashicons dashicons-yes"></div>&nbsp;<strong><?php _e( 'CRON Exports is enabled', 'woo_ce' ); ?></strong></p>
<?php } ?>
		<p class="description"><?php printf( __( 'Store Exporter Deluxe supports exporting via a command line request, to do this you need to prepare a specific URL and pass it the following required inline parameters. For sample CRON requests and supported arguments consult our <a href="%s" target="_blank">online documentation</a>.', 'woo_ce' ), $troubleshooting_url ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="enable_cron"><?php _e( 'Enable CRON', 'woo_ce' ); ?></label>
	</th>
	<td>
		<select id="enable_cron" name="enable_cron">
			<option value="1"<?php selected( $enable_cron, 1 ); ?>><?php _e( 'Yes', 'woo_ce' ); ?></option>
			<option value="0"<?php selected( $enable_cron, 0 ); ?>><?php _e( 'No', 'woo_ce' ); ?></option>
		</select>
		<p class="description"><?php _e( 'Enabling CRON allows developers to schedule automated exports and connect with Store Exporter Deluxe remotely.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="secret_key"><?php _e( 'Export secret key', 'woo_ce' ); ?></label>
	</th>
	<td>
		<input name="secret_key" type="text" id="secret_key" value="<?php echo esc_attr( $secret_key ); ?>" class="large-text code" />
		<p class="description"><?php _e( 'This secret key (can be left empty to allow unrestricted access) limits access to authorised developers who provide a matching key when working with Store Exporter Deluxe.', 'woo_ce' ); ?></p>
	</td>
</tr>
<tr>
	<th>
		<label for="cron_fields"><?php _e( 'Export fields', 'woo_ce' ); ?></label>
	</th>
	<td>
		<ul style="margin-top:0.2em;">
			<li><label><input type="radio" id="cron_fields" name="cron_fields" value="all"<?php checked( $cron_fields, 'all' ); ?> /> <?php _e( 'Include all Export Fields for the requested Export Type', 'woo_ce' ); ?></label></li>
			<li><label><input type="radio" name="cron_fields" value="saved"<?php checked( $cron_fields, 'saved' ); ?> /> <?php _e( 'Use the saved Export Fields preference set on the Export screen for the requested Export Type', 'woo_ce' ); ?></label></li>
		</ul>
		<p class="description"><?php _e( 'Control whether all known export fields are included or only checked fields from the Export Fields section on the Export screen for each Export Type. Default is to include all export fields.', 'woo_ce' ); ?></p>
	</td>
</tr>
<?php
	ob_end_flush();

}
?>