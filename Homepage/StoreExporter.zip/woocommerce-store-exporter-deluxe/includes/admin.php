<?php
// Display admin notice on screen load
function woo_cd_admin_notice( $message = '', $priority = 'updated', $screen = '' ) {

	if( $priority == false || $priority == '' )
		$priority = 'updated';
	if( $message <> '' ) {
		ob_start();
		woo_cd_admin_notice_html( $message, $priority, $screen );
		$output = ob_get_contents();
		ob_end_clean();
		// Check if an existing notice is already in queue
		$existing_notice = get_transient( WOO_CD_PREFIX . '_notice' );
		if( $existing_notice !== false ) {
			$existing_notice = base64_decode( $existing_notice );
			$output = $existing_notice . $output;
		}
		set_transient( WOO_CD_PREFIX . '_notice', base64_encode( $output ), MINUTE_IN_SECONDS );
		add_action( 'admin_notices', 'woo_cd_admin_notice_print' );
	}

}

// HTML template for admin notice
function woo_cd_admin_notice_html( $message = '', $priority = 'updated', $screen = '' ) {

	// Display admin notice on specific screen
	if( !empty( $screen ) ) {

		global $pagenow;

		if( is_array( $screen ) ) {
			if( in_array( $pagenow, $screen ) == false )
				return;
		} else {
			if( $pagenow <> $screen )
				return;
		}

	} ?>
<div id="message" class="<?php echo $priority; ?>">
	<p><?php echo $message; ?></p>
</div>
<?php

}

// Grabs the WordPress transient that holds the admin notice and prints it
function woo_cd_admin_notice_print() {

	$output = get_transient( WOO_CD_PREFIX . '_notice' );
	if( $output !== false ) {
		delete_transient( WOO_CD_PREFIX . '_notice' );
		$output = base64_decode( $output );
		echo $output;
	}

}

// HTML template header on Store Exporter screen
function woo_cd_template_header( $title = '', $icon = 'woocommerce' ) {

	if( $title )
		$output = $title;
	else
		$output = __( 'Store Export', 'woo_ce' ); ?>
<div id="woo-ce" class="wrap">
	<div id="icon-<?php echo $icon; ?>" class="icon32 icon32-woocommerce-importer"><br /></div>
	<h2>
		<?php echo $output; ?>
		<a href="<?php echo add_query_arg( array( 'tab' => 'export', 'empty' => null ) ); ?>" class="add-new-h2"><?php _e( 'Add New', 'woo_ce' ); ?></a>
	</h2>
<?php

}

// HTML template footer on Store Exporter screen
function woo_cd_template_footer() { ?>
</div>
<!-- .wrap -->
<?php

}

function woo_cd_template_header_title() {

	return __( 'Store Exporter Deluxe', 'woo_ce' );

}
add_filter( 'woo_ce_template_header', 'woo_cd_template_header_title' );

// Add Export, Docs and Premium Support links to the Plugins screen
function woo_cd_add_settings_link( $links, $file ) {

	// Manually force slug
	$this_plugin = WOO_CD_RELPATH;

	if( $file == $this_plugin ) {
		$support_url = 'http://www.visser.com.au/premium-support/';
		$support_link = sprintf( '<a href="%s" target="_blank">' . __( 'Premium Support', 'woo_ce' ) . '</a>', $support_url );
		$docs_url = 'http://www.visser.com.au/docs/';
		$docs_link = sprintf( '<a href="%s" target="_blank">' . __( 'Docs', 'woo_ce' ) . '</a>', $docs_url );
		$export_link = sprintf( '<a href="%s">' . __( 'Export', 'woo_ce' ) . '</a>', add_query_arg( 'page', 'woo_ce', 'admin.php' ) );
		array_unshift( $links, $support_link );
		array_unshift( $links, $docs_link );
		array_unshift( $links, $export_link );
	}
	return $links;

}
add_filter( 'plugin_action_links', 'woo_cd_add_settings_link', 10, 2 );

// Display the bulk actions for Orders on the Orders screen
function woo_ce_admin_order_bulk_actions() {

	global $post_type;

	// Check if this is the Orders screen
	if( $post_type != 'shop_order' )
		return;

	ob_start(); ?>
<script type="text/javascript">
jQuery(function() {
	jQuery('<option>').val('download_csv').text('<?php _e( 'Download as CSV', 'woo_ce' )?>').appendTo("select[name='action']");
	jQuery('<option>').val('download_csv').text('<?php _e( 'Download as CSV', 'woo_ce' )?>').appendTo("select[name='action2']");

	jQuery('<option>').val('download_xml').text('<?php _e( 'Download as XML', 'woo_ce' )?>').appendTo("select[name='action']");
	jQuery('<option>').val('download_xml').text('<?php _e( 'Download as XML', 'woo_ce' )?>').appendTo("select[name='action2']");

	jQuery('<option>').val('download_xls').text('<?php _e( 'Download as Excel 2007 (XLS)', 'woo_ce' )?>').appendTo("select[name='action']");
	jQuery('<option>').val('download_xls').text('<?php _e( 'Download as Excel 2007 (XLS)', 'woo_ce' )?>').appendTo("select[name='action2']");
});
</script>
<?php
	ob_end_flush();

}

// Process the bulk action for Orders on the Orders screen
function woo_ce_admin_order_process_bulk_action() {

	$wp_list_table = _get_list_table( 'WP_Posts_List_Table' );
	$action = $wp_list_table->current_action();
	$export_format = false;
	switch( $action ) {

		case 'download_csv':
			$export_format = 'csv';
			break;

		case 'download_xml':
			$export_format = 'xml';
			break;

		case 'download_xls':
			$export_format = 'xls';
			break;

		default:
			return;
			break;

	}
	if( !empty( $export_format ) ) {
		$post_ids = array_map( 'absint', (array)$_REQUEST['post'] );
		set_transient( WOO_CD_PREFIX . '_single_export_format', $export_format, MINUTE_IN_SECONDS );
		set_transient( WOO_CD_PREFIX . '_single_export_order_ids', implode( ',', $post_ids ), MINUTE_IN_SECONDS );
		$gui = 'download';
		$export_type = 'order';
		woo_ce_cron_export( $gui, $export_type );
		delete_transient( WOO_CD_PREFIX . '_single_export_format' );
		delete_transient( WOO_CD_PREFIX . '_single_export_order_ids' );
		exit();
	}

}

// Add Download as... buttons to Actions column on Orders screen
function woo_ce_admin_order_actions( $actions = array(), $order = false ) {

	$actions[] = array(
		'url' => wp_nonce_url( admin_url( add_query_arg( array( 'action' => 'woo_ce_export_order', 'format' => 'csv', 'order_ids' => $order->id ), 'admin-ajax.php' ) ), 'woo_ce_export_order' ),
		'name' => __( 'Download as CSV', 'woo_ce' ),
		'action' => 'download_csv'
	);
	$actions[] = array(
		'url' => wp_nonce_url( admin_url( add_query_arg( array( 'action' => 'woo_ce_export_order', 'format' => 'xml', 'order_ids' => $order->id ), 'admin-ajax.php' ) ), 'woo_ce_export_order' ),
		'name' => __( 'Download as XML', 'woo_ce' ),
		'action' => 'download_xml'
	);
	$actions[] = array(
		'url' => wp_nonce_url( admin_url( add_query_arg( array( 'action' => 'woo_ce_export_order', 'format' => 'xls', 'order_ids' => $order->id ), 'admin-ajax.php' ) ), 'woo_ce_export_order' ),
		'name' => __( 'Download as Excel 2007 (XLS)', 'woo_ce' ),
		'action' => 'download_xls'
	);
	return $actions;

}

// Generate exports for Download as... button clicks
function woo_ce_ajax_export_order() {

	if( check_admin_referer( 'woo_ce_export_order' ) ) {
		$gui = 'download';
		$export_type = 'order';
		$order_ids = ( isset( $_GET['order_ids'] ) ? sanitize_text_field( $_GET['order_ids'] ) : false );
		if( $order_ids ) {
			woo_ce_cron_export( $gui, $export_type );
			exit();
		}
	}

}

function woo_ce_admin_order_single_export_csv( $order = false ) {

	if( $order !== false ) {
		// Set the export format type
		$export_format = 'csv';

		// Set up our export
		set_transient( WOO_CD_PREFIX . '_single_export_format', $export_format, MINUTE_IN_SECONDS );
		set_transient( WOO_CD_PREFIX . '_single_export_order_ids', $order->id, MINUTE_IN_SECONDS );

		// Run the export
		$gui = 'download';
		$export_type = 'order';
		woo_ce_cron_export( $gui, $export_type );

		// Clean up
		delete_transient( WOO_CD_PREFIX . '_single_export_format' );
		delete_transient( WOO_CD_PREFIX . '_single_export_order_ids' );
		exit();
	}

}

function woo_ce_admin_order_single_export_xml( $order = false ) {

	if( $order !== false ) {

		// Set the export format type
		$export_format = 'xml';

		// Set up our export
		set_transient( WOO_CD_PREFIX . '_single_export_format', $export_format, MINUTE_IN_SECONDS );
		set_transient( WOO_CD_PREFIX . '_single_export_order_ids', $order->id, MINUTE_IN_SECONDS );

		// Run the export
		$gui = 'download';
		$export_type = 'order';
		woo_ce_cron_export( $gui, $export_type );

		// Clean up
		delete_transient( WOO_CD_PREFIX . '_single_export_format' );
		delete_transient( WOO_CD_PREFIX . '_single_export_order_ids' );
		exit();
	}

}

function woo_ce_admin_order_single_export_xls( $order = false ) {

	if( $order !== false ) {

		// Set the export format type
		$export_type = 'xls';

		// Set up our export
		set_transient( WOO_CD_PREFIX . '_single_export_format', $export_type, MINUTE_IN_SECONDS );
		set_transient( WOO_CD_PREFIX . '_single_export_order_ids', $order->id, MINUTE_IN_SECONDS );

		// Run the export
		$gui = 'download';
		$export_type = 'order';
		woo_ce_cron_export( $gui, $export_type );

		// Clean up
		delete_transient( WOO_CD_PREFIX . '_single_export_format' );
		delete_transient( WOO_CD_PREFIX . '_single_export_order_ids' );
		exit();
	}

}

function woo_ce_admin_order_single_actions( $actions ) {

	$actions['woo_ce_export_order_csv'] = __( 'Download as CSV', 'woo_ce' );
	$actions['woo_ce_export_order_xml'] = __( 'Download as XML', 'woo_ce' );
	$actions['woo_ce_export_order_xls'] = __( 'Download as Excel 2007 (XLS)', 'woo_ce' );
	return $actions;

}

// Add Store Export page to WooCommerce screen IDs
function woo_ce_wc_screen_ids( $screen_ids = array() ) {

	$screen_ids[] = 'woocommerce_page_woo_ce';
	return $screen_ids;

}
add_filter( 'woocommerce_screen_ids', 'woo_ce_wc_screen_ids', 10, 1 );

// Add Store Export to WordPress Administration menu
function woo_ce_admin_menu() {

	$page = add_submenu_page( 'woocommerce', __( 'Store Exporter Deluxe', 'woo_ce' ), __( 'Store Export', 'woo_ce' ), 'view_woocommerce_reports', 'woo_ce', 'woo_cd_html_page' );
	add_action( 'admin_print_styles-' . $page, 'woo_ce_enqueue_scripts' );
	add_action( 'current_screen', 'woo_ce_add_help_tab' );

}
add_action( 'admin_menu', 'woo_ce_admin_menu', 11 );

// Load CSS and jQuery scripts for Store Exporter Deluxe screen
function woo_ce_enqueue_scripts() {

	// Simple check that WooCommerce is activated
	if( class_exists( 'WooCommerce' ) ) {

		global $woocommerce;

		// Load WooCommerce default Admin styling
		wp_enqueue_style( 'woocommerce_admin_styles', $woocommerce->plugin_url() . '/assets/css/admin.css' );

	}

	// Date Picker
	wp_enqueue_script( 'jquery-ui-datepicker' );
	wp_enqueue_style( 'jquery-ui-datepicker', plugins_url( '/templates/admin/jquery-ui-datepicker.css', WOO_CD_RELPATH ) );

	// Chosen
	wp_enqueue_style( 'jquery-chosen', plugins_url( '/templates/admin/chosen.css', WOO_CD_RELPATH ) );
	wp_enqueue_script( 'jquery-chosen', plugins_url( '/js/jquery.chosen.js', WOO_CD_RELPATH ), array( 'jquery' ) );

	// Common
	wp_enqueue_style( 'woo_ce_styles', plugins_url( '/templates/admin/export.css', WOO_CD_RELPATH ) );
	wp_enqueue_script( 'woo_ce_scripts', plugins_url( '/templates/admin/export.js', WOO_CD_RELPATH ), array( 'jquery', 'jquery-ui-sortable' ) );
	wp_enqueue_style( 'dashicons' );

	if( WOO_CD_DEBUG ) {
		wp_enqueue_style( 'jquery-csvToTable', plugins_url( '/templates/admin/jquery-csvtable.css', WOO_CD_RELPATH ) );
		wp_enqueue_script( 'jquery-csvToTable', plugins_url( '/js/jquery.csvToTable.js', WOO_CD_RELPATH ), array( 'jquery' ) );
	}
	wp_enqueue_style( 'woo_vm_styles', plugins_url( '/templates/admin/woocommerce-admin_dashboard_vm-plugins.css', WOO_CD_RELPATH ) );

}

function woo_ce_add_help_tab() {

	$screen = get_current_screen();
	if( $screen->id <> 'woocommerce_page_woo_ce' )
		return;

	$screen->add_help_tab( array(
		'id'		=> 'woo_ce',
		'title'		=> __( 'Store Exporter Deluxe', 'woo_ce' ),
		'content'	=> 
			'<p>' . __( 'Thank you for using Store Exporter Deluxe :) Should you need help using this Plugin please read the documentation, if an issue persists get in touch with us on Premium Support.', 'woo_ce' ) . '</p>' .
			'<p><a href="' . 'http://www.visser.com.au/documentation/store-exporter-deluxe/usage/' . '" target="_blank" class="button button-primary">' . __( 'Documentation', 'woo_ce' ) . '</a> <a href="' . 'http://www.visser.com.au/premium-support/' . '" target="_blank" class="button">' . __( 'Premium Support', 'woo_ce' ) . '</a></p>'
	) );

}

function woo_ce_admin_plugin_row() {

	$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/';

	// Detect if another e-Commerce platform is activated
	if( !woo_is_woo_activated() && ( woo_is_jigo_activated() || woo_is_wpsc_activated() ) ) {
		$message = sprintf( __( 'We have detected another e-Commerce Plugin than WooCommerce activated, please check that you are using Store Exporter Deluxe for the correct platform. <a href="%s" target="_blank">Need help?</a>', 'woo_ce' ), $troubleshooting_url );
		echo '</tr><tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message">' . $message . '</div></td></tr>';
	} else if( !woo_is_woo_activated() ) {
		$message = sprintf( __( 'We have been unable to detect the WooCommerce Plugin activated on this WordPress site, please check that you are using Store Exporter Deluxe for the correct platform. <a href="%s" target="_blank">Need help?</a>', 'woo_ce' ), $troubleshooting_url );
		echo '</tr><tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message">' . $message . '</div></td></tr>';
	}

	// Display notice if Visser Labs Updater is not installed
	if( !class_exists( 'VL_Updater' ) ) {
		$slug = 'visser-labs-updater';
		$download_url = 'http://updates.visser.com.au/downloads/visser-labs-updater.zip';
		$install_url = wp_nonce_url( self_admin_url( add_query_arg( array( 'action' => 'install-plugin', 'plugin' => $slug ), 'update.php' ) ), sprintf( 'install-plugin_%s', $slug ) );
		$activate_url = add_query_arg( array( 'action' => 'activate', 'plugin' => urlencode( 'visser-labs-updater/visser-labs-updater.php' ), 'plugin_status' => 'all', 'paged' => 1, '_wpnonce' => urlencode( wp_create_nonce( 'activate-plugin_visser-labs-updater/visser-labs-updater.php' ) ) ), 'plugins.php' );
		$message = sprintf( __( '<a href="%s">Install the Visser Labs Updater Plugin</a> (or download and manually install it from <a href="#">here</a>) to get automatic update notifications for your Visser Labs Plugins.', 'woo_ce' ), $install_url, $download_url );

		// Check if Visser Labs Updater has been installed but not activated
		if( $plugins = array_keys( get_plugins() ) ) {
			foreach( $plugins as $plugin ) {
				if( strpos( $plugin, 'visser-labs-updater.php' ) !== false ) {
					$message = sprintf( __( '<a href="%s">Activate the Visser Labs Updater Plugin</a> to get automatic update notifications for your Visser Labs Plugins.', 'woo_ce' ), esc_url( admin_url( $activate_url ) ) );
				}
			}
		}
		echo '</tr><tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message">' . $message . '</div></td></tr>';
	}

}

// @mod - Unused?
function woo_ce_plugin_page_notice( $file, $data ) {

	if( is_plugin_active( $file ) ) { ?>
<tr class='plugin-update-tr su-plugin-notice'>
	<td colspan='3' class='plugin-update colspanchange'>
		<div class='update-message'>
			<?php printf( __( '%1$s is intended to be used with a WooCommerce store, please check that you are using Store Exporter Deluxe with the correct e-Commerce platform.', 'woo_ce' ), $data['Name'] ); ?>
		</div>
	</td>
</tr>
<?php
	}

}

// HTML active class for the currently selected tab on the Store Exporter screen
function woo_cd_admin_active_tab( $tab_name = null, $tab = null ) {

	if( isset( $_GET['tab'] ) && !$tab )
		$tab = $_GET['tab'];
	else if( !isset( $_GET['tab'] ) && woo_ce_get_option( 'skip_overview', false ) )
		$tab = 'export';
	else
		$tab = 'overview';

	$output = '';
	if( isset( $tab_name ) && $tab_name ) {
		if( $tab_name == $tab )
			$output = ' nav-tab-active';
	}
	echo $output;

}

// HTML template for each tab on the Store Exporter screen
function woo_cd_tab_template( $tab = '' ) {

	if( !$tab )
		$tab = 'overview';

	$troubleshooting_url = 'http://www.visser.com.au/documentation/store-exporter-deluxe/';

	switch( $tab ) {

		case 'overview':
			$skip_overview = woo_ce_get_option( 'skip_overview', false );
			break;

		case 'export':
			$export_type = sanitize_text_field( ( isset( $_POST['dataset'] ) ? $_POST['dataset'] : woo_ce_get_option( 'last_export', 'product' ) ) );
			$types = array_keys( woo_ce_return_export_types() );
			// Check if the default export type exists
			if( !in_array( $export_type, $types ) )
				$export_type = 'product';

			$products = woo_ce_return_count( 'product' );
			$categories = woo_ce_return_count( 'category' );
			$tags = woo_ce_return_count( 'tag' );
			$brands = woo_ce_return_count( 'brand' );
			$orders = woo_ce_return_count( 'order' );
			$customers = woo_ce_return_count( 'customer' );
			$users = woo_ce_return_count( 'user' );
			$coupons = woo_ce_return_count( 'coupon' );
			$attributes = woo_ce_return_count( 'attribute' );
			$subscriptions = woo_ce_return_count( 'subscription' );
			$product_vendors = woo_ce_return_count( 'product_vendor' );
			$commissions = woo_ce_return_count( 'commission' );
			$shipping_classes = woo_ce_return_count( 'shipping_class' );

			add_action( 'woo_ce_export_options', 'woo_ce_export_options_export_format' );
			if( $product_fields = woo_ce_get_product_fields() ) {
				foreach( $product_fields as $key => $product_field )
					$product_fields[$key]['disabled'] = ( isset( $product_field['disabled'] ) ? $product_field['disabled'] : 0 );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_category' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_tag' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_brand' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_vendor' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_status' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_product_type' );
				add_action( 'woo_ce_export_product_options_before_table', 'woo_ce_products_filter_by_stock_status' );
				add_action( 'woo_ce_export_product_options_after_table', 'woo_ce_product_sorting' );
				add_action( 'woo_ce_export_options', 'woo_ce_products_upsells_formatting' );
				add_action( 'woo_ce_export_options', 'woo_ce_products_crosssells_formatting' );
				add_action( 'woo_ce_export_options', 'woo_ce_products_variation_formatting' );
				add_action( 'woo_ce_export_options', 'woo_ce_export_options_gallery_format' );
				add_action( 'woo_ce_export_after_form', 'woo_ce_products_custom_fields' );
			}
			if( $category_fields = woo_ce_get_category_fields() ) {
				foreach( $category_fields as $key => $category_field )
					$category_fields[$key]['disabled'] = ( isset( $category_field['disabled'] ) ? $category_field['disabled'] : 0 );
				add_action( 'woo_ce_export_category_options_after_table', 'woo_ce_category_sorting' );
			}
			if( $tag_fields = woo_ce_get_tag_fields() ) {
				foreach( $tag_fields as $key => $tag_field )
					$tag_fields[$key]['disabled'] = ( isset( $tag_field['disabled'] ) ? $tag_field['disabled'] : 0 );
				add_action( 'woo_ce_export_tag_options_after_table', 'woo_ce_tag_sorting' );
			}
			if( $brand_fields = woo_ce_get_brand_fields() ) {
				foreach( $brand_fields as $key => $brand_field )
					$brand_fields[$key]['disabled'] = ( isset( $brand_field['disabled'] ) ? $brand_field['disabled'] : 0 );
				add_action( 'woo_ce_export_brand_options_before_table', 'woo_ce_brand_sorting' );
			}
			if( $order_fields = woo_ce_get_order_fields() ) {
				foreach( $order_fields as $key => $order_field )
					$order_fields[$key]['disabled'] = ( isset( $order_field['disabled'] ) ? $order_field['disabled'] : 0 );
				add_action( 'woo_ce_export_quicklinks', 'woo_ce_quicklink_custom_fields' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_date' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_status' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_customer' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_billing_country' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_shipping_country' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_user_role' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_coupon' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_product' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_product_category' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_product_tag' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_product_brand' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_filter_by_order_id' );
				add_action( 'woo_ce_export_order_options_before_table', 'woo_ce_orders_custom_fields_link' );
				add_action( 'woo_ce_export_order_options_after_table', 'woo_ce_order_sorting' );
				add_action( 'woo_ce_export_options', 'woo_ce_orders_items_formatting' );
				add_action( 'woo_ce_export_options', 'woo_ce_orders_max_order_items' );
				add_action( 'woo_ce_export_options', 'woo_ce_orders_items_types' );
				add_action( 'woo_ce_export_after_form', 'woo_ce_orders_custom_fields' );
			}
			if( $customer_fields = woo_ce_get_customer_fields() ) {
				foreach( $customer_fields as $key => $customer_field )
					$customer_fields[$key]['disabled'] = ( isset( $customer_field['disabled'] ) ? $customer_field['disabled'] : 0 );
				add_action( 'woo_ce_export_customer_options_before_table', 'woo_ce_customers_filter_by_status' );
				add_action( 'woo_ce_export_customer_options_before_table', 'woo_ce_customers_filter_by_user_role' );
				add_action( 'woo_ce_export_after_form', 'woo_ce_customers_custom_fields' );
			}
			if( $user_fields = woo_ce_get_user_fields() ) {
				foreach( $user_fields as $key => $user_field )
					$user_fields[$key]['disabled'] = ( isset( $user_field['disabled'] ) ? $user_field['disabled'] : 0 );
				add_action( 'woo_ce_export_user_options_after_table', 'woo_ce_user_sorting' );
				add_action( 'woo_ce_export_after_form', 'woo_ce_users_custom_fields' );
			}
			if( $coupon_fields = woo_ce_get_coupon_fields() ) {
				foreach( $coupon_fields as $key => $coupon_field )
					$coupon_fields[$key]['disabled'] = ( isset( $coupon_field['disabled'] ) ? $coupon_field['disabled'] : 0 );
				add_action( 'woo_ce_export_coupon_options_before_table', 'woo_ce_coupon_sorting' );
			}
			if( $subscription_fields = woo_ce_get_subscription_fields() ) {
				foreach( $subscription_fields as $key => $subscription_field )
					$subscription_fields[$key]['disabled'] = ( isset( $subscription_field['disabled'] ) ? $subscription_field['disabled'] : 0 );
				add_action( 'woo_ce_export_subscription_options_before_table', 'woo_ce_subscriptions_filter_by_subscription_status' );
				add_action( 'woo_ce_export_subscription_options_before_table', 'woo_ce_subscriptions_filter_by_subscription_product' );
			}
			if( $product_vendor_fields = woo_ce_get_product_vendor_fields() ) {
				foreach( $product_vendor_fields as $key => $product_vendor_field )
					$product_vendor_fields[$key]['disabled'] = ( isset( $product_vendor_field['disabled'] ) ? $product_vendor_field['disabled'] : 0 );
			}
			if( $commission_fields = woo_ce_get_commission_fields() ) {
				foreach( $commission_fields as $key => $commission_field )
					$commission_fields[$key]['disabled'] = ( isset( $commission_field['disabled'] ) ? $commission_field['disabled'] : 0 );
				add_action( 'woo_ce_export_commission_options_before_table', 'woo_ce_commissions_filter_by_date' );
				add_action( 'woo_ce_export_commission_options_before_table', 'woo_ce_commissions_filter_by_product_vendor' );
				add_action( 'woo_ce_export_commission_options_before_table', 'woo_ce_commissions_filter_by_commission_status' );
				add_action( 'woo_ce_export_commission_options_before_table', 'woo_ce_commission_sorting' );
			}
			if( $shipping_class_fields = woo_ce_get_shipping_class_fields() ) {
				foreach( $shipping_class_fields as $key => $shipping_class_field )
					$shipping_class_fields[$key]['disabled'] = ( isset( $shipping_class_field['disabled'] ) ? $shipping_class_field['disabled'] : 0 );
				add_action( 'woo_ce_export_shipping_class_options_after_table', 'woo_ce_shipping_class_sorting' );
			}
			// $attribute_fields = woo_ce_get_attribute_fields();
			if( $attribute_fields = false ) {
				foreach( $attribute_fields as $key => $attribute_field )
					$attribute_fields[$key]['disabled'] = ( isset( $attribute_field['disabled'] ) ? $attribute_field['disabled'] : 0 );
			}

			// Export modules
			$modules = woo_ce_modules_list();

			// Export options
			$limit_volume = woo_ce_get_option( 'limit_volume' );
			$offset = woo_ce_get_option( 'offset' );
			break;

		case 'fields':
			$export_type = ( isset( $_GET['type'] ) ? sanitize_text_field( $_GET['type'] ) : '' );
			$types = array_keys( woo_ce_return_export_types() );
			$fields = array();
			if( in_array( $export_type, $types ) ) {
				if( has_filter( 'woo_ce_' . $export_type . '_fields', 'woo_ce_override_' . $export_type . '_field_labels' ) )
					remove_filter( 'woo_ce_' . $export_type . '_fields', 'woo_ce_override_' . $export_type . '_field_labels', 11 );
				if( function_exists( sprintf( 'woo_ce_get_%s_fields', $export_type ) ) )
					$fields = call_user_func( 'woo_ce_get_' . $export_type . '_fields' );
				$labels = woo_ce_get_option( $export_type . '_labels', array() );
			}
			break;

		case 'archive':
			if( isset( $_GET['deleted'] ) ) {
				$message = __( 'Archived export has been deleted.', 'woo_ce' );
				woo_cd_admin_notice( $message );
			}
			if( $files = woo_ce_get_archive_files() ) {
				foreach( $files as $key => $file )
					$files[$key] = woo_ce_get_archive_file( $file );
			}
			break;

		case 'settings':
			$export_filename = woo_ce_get_option( 'export_filename', '' );
			// Strip file extension from export filename
			if( ( strpos( $export_filename, '.csv' ) !== false ) || ( strpos( $export_filename, '.xml' ) !== false ) || ( strpos( $export_filename, '.xls' ) !== false ) )
				$export_filename = str_replace( array( '.csv', '.xml', '.xls' ), '', $export_filename );
			// Default export filename
			if( $export_filename == false )
				$export_filename = '%store_name%-export_%dataset%-%date%-%time%';
			$delete_file = woo_ce_get_option( 'delete_file', 0 );
			$timeout = woo_ce_get_option( 'timeout', 0 );
			$encoding = woo_ce_get_option( 'encoding', 'UTF-8' );
			$bom = woo_ce_get_option( 'bom', 1 );
			$delimiter = woo_ce_get_option( 'delimiter', ',' );
			$category_separator = woo_ce_get_option( 'category_separator', '|' );
			$line_ending_formatting = woo_ce_get_option( 'line_ending_formatting', 'windows' );
			$escape_formatting = woo_ce_get_option( 'escape_formatting', 'all' );
			$date_format = woo_ce_get_option( 'date_format', 'd/m/Y' );
			if( $date_format == 1 || $date_format == '' )
				$date_format = 'd/m/Y';
			$file_encodings = ( function_exists( 'mb_list_encodings' ) ? mb_list_encodings() : false );
			add_action( 'woo_ce_export_settings_top', 'woo_ce_export_settings_quicklinks' );
			add_action( 'woo_ce_export_settings_general', 'woo_ce_export_settings_additional' );
			add_action( 'woo_ce_export_settings_after', 'woo_ce_export_settings_csv' );
			add_action( 'woo_ce_export_settings_after', 'woo_ce_export_settings_cron' );
			break;

		case 'tools':
			// Product Importer Deluxe
			$woo_pd_url = 'http://www.visser.com.au/woocommerce/plugins/product-importer-deluxe/';
			$woo_pd_target = ' target="_blank"';
			if( function_exists( 'woo_pd_init' ) ) {
				$woo_pd_url = add_query_arg( array( 'page' => 'woo_pd', 'tab' => null ) );
				$woo_pd_target = false;
			}

			// Store Toolkit
			$woo_st_url = 'http://www.visser.com.au/woocommerce/plugins/store-toolkit/';
			$woo_st_target = ' target="_blank"';
			if( function_exists( 'woo_st_admin_init' ) ) {
				$woo_st_url = add_query_arg( array( 'page' => 'woo_st', 'tab' => null ) );
				$woo_st_target = false;
			}
			break;

	}
	if( $tab ) {
		if( file_exists( WOO_CD_PATH . 'templates/admin/tabs-' . $tab . '.php' ) ) {
			include_once( WOO_CD_PATH . 'templates/admin/tabs-' . $tab . '.php' );
		} else {
			$message = sprintf( __( 'We couldn\'t load the export template file <code>%s</code> within <code>%s</code>, this file should be present.', 'woo_ce' ), 'tabs-' . $tab . '.php', WOO_CD_PATH . 'templates/admin/...' );
			woo_cd_admin_notice_html( $message, 'error' );
			ob_start(); ?>
<p><?php _e( 'You can see this error for one of a few common reasons', 'woo_ce' ); ?>:</p>
<ul class="ul-disc">
	<li><?php _e( 'WordPress was unable to create this file when the Plugin was installed or updated', 'woo_ce' ); ?></li>
	<li><?php _e( 'The Plugin files have been recently changed and there has been a file conflict', 'woo_ce' ); ?></li>
	<li><?php _e( 'The Plugin file has been locked and cannot be opened by WordPress', 'woo_ce' ); ?></li>
</ul>
<p><?php _e( 'Jump onto our website and download a fresh copy of this Plugin as it might be enough to fix this issue. If this persists get in touch with us.', 'woo_ce' ); ?></p>
<?php
			ob_end_flush();
		}
	}

}

// List of WordPress Plugins that Store Exporter Deluxe integrates with
function woo_ce_modules_list( $modules = array() ) {

	$modules[] = array(
		'name' => 'aioseop',
		'title' => __( 'All in One SEO Pack', 'woo_ce' ),
		'description' => __( 'Optimize your WooCommerce Products for Search Engines. Requires Store Toolkit for All in One SEO Pack integration.', 'woo_ce' ),
		'url' => 'http://wordpress.org/extend/plugins/all-in-one-seo-pack/',
		'slug' => 'all-in-one-seo-pack',
		'function' => 'aioseop_activate'
	);
	$modules[] = array(
		'name' => 'store_toolkit',
		'title' => __( 'Store Toolkit', 'woo_ce' ),
		'description' => __( 'Store Toolkit includes a growing set of commonly-used WooCommerce administration tools aimed at web developers and store maintainers.', 'woo_ce' ),
		'url' => 'http://wordpress.org/extend/plugins/woocommerce-store-toolkit/',
		'slug' => 'woocommerce-store-toolkit',
		'function' => 'woo_st_admin_init'
	);
	$modules[] = array(
		'name' => 'ultimate_seo',
		'title' => __( 'SEO Ultimate', 'woo_ce' ),
		'description' => __( 'This all-in-one SEO plugin gives you control over Product details.', 'woo_ce' ),
		'url' => 'http://wordpress.org/extend/plugins/seo-ultimate/',
		'slug' => 'seo-ultimate',
		'function' => 'su_wp_incompat_notice'
	);
	$modules[] = array(
		'name' => 'gpf',
		'title' => __( 'Advanced Google Product Feed', 'woo_ce' ),
		'description' => __( 'Easily configure data to be added to your Google Merchant Centre feed.', 'woo_ce' ),
		'url' => 'http://www.leewillis.co.uk/wordpress-plugins/',
		'function' => 'woocommerce_gpf_install'
	);
	$modules[] = array(
		'name' => 'wpseo',
		'title' => __( 'WordPress SEO by Yoast', 'woo_ce' ),
		'description' => __( 'The first true all-in-one SEO solution for WordPress.', 'woo_ce' ),
		'url' => 'http://yoast.com/wordpress/seo/#utm_source=wpadmin&utm_medium=plugin&utm_campaign=wpseoplugin',
		'slug' => 'wordpress-seo',
		'function' => 'wpseo_admin_init'
	);
	$modules[] = array(
		'name' => 'msrp',
		'title' => __( 'WooCommerce MSRP Pricing', 'woo_ce' ),
		'description' => __( 'Define and display MSRP prices (Manufacturer\'s suggested retail price) to your customers.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/msrp-pricing/',
		'function' => 'woocommerce_msrp_activate'
	);
	$modules[] = array(
		'name' => 'wc_brands',
		'title' => __( 'WooCommerce Brands Addon', 'woo_ce' ),
		'description' => __( 'Create, assign and list brands for products, and allow customers to filter by brand.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/brands/',
		'class' => 'WC_Brands'
	);
	$modules[] = array(
		'name' => 'wc_cog',
		'title' => __( 'Cost of Goods', 'woo_ce' ),
		'description' => __( 'Easily track total profit and cost of goods by adding a Cost of Good field to simple and variable products.', 'woo_ce' ),
		'url' => 'http://www.skyverge.com/product/woocommerce-cost-of-goods-tracking/',
		'class' => 'WC_COG'
	);
	$modules[] = array(
		'name' => 'per_product_shipping',
		'title' => __( 'Per-Product Shipping', 'woo_ce' ),
		'description' => __( 'Define separate shipping costs per product which are combined at checkout to provide a total shipping cost.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/per-product-shipping/',
		'function' => 'woocommerce_per_product_shipping_init'
	);
	$modules[] = array(
		'name' => 'vendors',
		'title' => __( 'Product Vendors', 'woo_ce' ),
		'description' => __( 'Turn your store into a multi-vendor marketplace (such as Etsy or Creative Market).', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/product-vendors/',
		'class' => 'WooCommerce_Product_Vendors'
	);
	$modules[] = array(
		'name' => 'acf',
		'title' => __( 'Advanced Custom Fields', 'woo_ce' ),
		'description' => __( 'Powerful fields for WordPress developers.', 'woo_ce' ),
		'url' => 'http://www.advancedcustomfields.com',
		'class' => 'acf'
	);
	$modules[] = array(
		'name' => 'product_addons',
		'title' => __( 'Product Add-ons', 'woo_ce' ),
		'description' => __( 'Allow your customers to customise your products by adding input boxes, dropdowns or a field set of checkboxes.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/product-add-ons/',
		'class' => 'Product_Addon_Admin'
	);
	$modules[] = array(
		'name' => 'seq',
		'title' => __( 'WooCommerce Sequential Order Numbers', 'woo_ce' ),
		'description' => __( 'This plugin extends the WooCommerce e-commerce plugin by setting sequential order numbers for new orders.', 'woo_ce' ),
		'url' => 'https://wordpress.org/plugins/woocommerce-sequential-order-numbers/',
		'slug' => 'woocommerce-sequential-order-numbers',
		'class' => 'WC_Seq_Order_Number'
	);
	$modules[] = array(
		'name' => 'seq_pro',
		'title' => __( 'WooCommerce Sequential Order Numbers Pro', 'woo_ce' ),
		'description' => __( 'Tame your WooCommerce Order Numbers.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/sequential-order-numbers-pro/',
		'class' => 'WC_Seq_Order_Number_Pro'
	);
	$modules[] = array(
		'name' => 'print_invoice_delivery_note',
		'title' => __( 'WooCommerce Print Invoice & Delivery Note', 'woo_ce' ),
		'description' => __( 'Print invoices and delivery notes for WooCommerce orders.', 'woo_ce' ),
		'url' => 'http://wordpress.org/plugins/woocommerce-delivery-notes/',
		'slug' => 'woocommerce-delivery-notes',
		'class' => 'WooCommerce_Delivery_Notes'
	);
	$modules[] = array(
		'name' => 'pdf_invoices_packing_slips',
		'title' => __( 'WooCommerce PDF Invoices & Packing Slips', 'woo_ce' ),
		'description' => __( 'Create, print & automatically email PDF invoices & packing slips for WooCommerce orders.', 'woo_ce' ),
		'url' => 'https://wordpress.org/plugins/woocommerce-pdf-invoices-packing-slips/',
		'slug' => 'woocommerce-pdf-invoices-packing-slips',
		'class' => 'WooCommerce_PDF_Invoices'
	);
	$modules[] = array(
		'name' => 'checkout_manager',
		'title' => __( 'WooCommerce Checkout Manager', 'woo_ce' ),
		'description' => __( 'Manages WooCommerce Checkout.', 'woo_ce' ),
		'url' => 'http://wordpress.org/plugins/woocommerce-checkout-manager/',
		'slug' => 'woocommerce-checkout-manager',
		'function' => 'wccs_install'
	);
	$modules[] = array(
		'name' => 'checkout_manager_pro',
		'title' => __( 'WooCommerce Checkout Manager Pro', 'woo_ce' ),
		'description' => __( 'Manages the WooCommerce Checkout page and WooCommerce Checkout processes.', 'woo_ce' ),
		'url' => 'http://www.trottyzone.com/product/woocommerce-checkout-manager-pro',
		'function' => 'wccs_install'
	);
	$modules[] = array(
		'name' => 'pgsk',
		'title' => __( 'Poor Guys Swiss Knife', 'woo_ce' ),
		'description' => __( 'A Swiss Knife for WooCommerce.', 'woo_ce' ),
		'url' => 'http://wordpress.org/plugins/woocommerce-poor-guys-swiss-knife/',
		'slug' => 'woocommerce-poor-guys-swiss-knife',
		'function' => 'wcpgsk_init'
	);
	$modules[] = array(
		'name' => 'checkout_field_editor',
		'title' => __( 'Checkout Field Editor', 'woo_ce' ),
		'description' => __( 'Add, edit and remove fields shown on your WooCommerce checkout page.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/woocommerce-checkout-field-editor/',
		'function' => 'woocommerce_init_checkout_field_editor'
	);
	$modules[] = array(
		'name' => 'checkout_field_manager',
		'title' => __( 'Checkout Field Manager', 'woo_ce' ),
		'description' => __( 'Quickly and effortlessly add, remove and re-orders fields in the checkout process.', 'woo_ce' ),
		'url' => 'http://61extensions.com/shop/woocommerce-checkout-field-manager/',
		'function' => 'sod_woocommerce_checkout_manager_settings'
	);
	$modules[] = array(
		'name' => 'checkout_addons',
		'title' => __( 'WooCommerce Checkout Add-Ons', 'woo_ce' ),
		'description' => __( 'Add fields at checkout for add-on products and services while optionally setting a cost for each add-on.', 'woo_ce' ),
		'url' => 'http://www.skyverge.com/product/woocommerce-checkout-add-ons/',
		'function' => 'init_woocommerce_checkout_add_ons'
	);
	$modules[] = array(
		'name' => 'local_pickup_plus',
		'title' => __( 'Local Pickup Plus', 'woo_ce' ),
		'description' => __( 'Let customers pick up products from specific locations.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/local-pickup-plus/',
		'class' => 'WC_Local_Pickup_Plus'
	);
	$modules[] = array(
		'name' => 'gravity_forms',
		'title' => __( 'Gravity Forms', 'woo_ce' ),
		'description' => __( 'Gravity Forms is hands down the best contact form plugin for WordPress powered websites.', 'woo_ce' ),
		'url' => 'http://woothemes.com/woocommerce',
		'class' => 'RGForms'
	);
	$modules[] = array(
		'name' => 'currency_switcher',
		'title' => __( 'WooCommerce Currency Switcher', 'woo_ce' ),
		'description' => __( 'Currency Switcher for WooCommerce allows your shop to display prices and accept payments in multiple currencies.', 'woo_ce' ),
		'url' => 'http://aelia.co/shop/currency-switcher-woocommerce/',
		'class' => 'WC_Aelia_CurrencySwitcher'
	);
	$modules[] = array(
		'name' => 'subscriptions',
		'title' => __( 'WooCommerce Subscriptions', 'woo_ce' ),
		'description' => __( 'WC Subscriptions makes it easy to create and manage products with recurring payments.', 'woo_ce' ),
		'url' => 'http://www.woothemes.com/products/woocommerce-subscriptions/',
		'class' => 'WC_Subscriptions_Manager'
	);
	$modules[] = array(
		'name' => 'extra_product_options',
		'title' => __( 'Extra Product Options', 'woo_ce' ),
		'description' => __( 'Create extra price fields globally or per-Product', 'woo_ce' ),
		'url' => 'http://codecanyon.net/item/woocommerce-extra-product-options/7908619',
		'class' => 'TM_Extra_Product_Options'
	);

/*
	$modules[] = array(
		'name' => '',
		'title' => __( '', 'woo_ce' ),
		'description' => __( '', 'woo_ce' ),
		'url' => '',
		'slug' => '', // Define this if the Plugin is hosted on the WordPress repo
		'function' => ''
	);
*/

	$modules = apply_filters( 'woo_ce_modules_addons', $modules );

	if( !empty( $modules ) ) {
		foreach( $modules as $key => $module ) {
			$modules[$key]['status'] = 'inactive';
			// Check if each module is activated
			if( isset( $module['function'] ) ) {
				if( function_exists( $module['function'] ) )
					$modules[$key]['status'] = 'active';
			} else if( isset( $module['class'] ) ) {
				if( class_exists( $module['class'] ) )
					$modules[$key]['status'] = 'active';
			}
			// Check if the Plugin has a slug and if current user can install Plugins
			if( current_user_can( 'install_plugins' ) && isset( $module['slug'] ) )
				$modules[$key]['url'] = admin_url( sprintf( 'plugin-install.php?tab=search&type=tag&s=%s', $module['slug'] ) );
		}
	}
	return $modules;

}

function woo_ce_modules_status_class( $status = 'inactive' ) {

	$output = '';
	switch( $status ) {

		case 'active':
			$output = 'green';
			break;

		case 'inactive':
			$output = 'yellow';
			break;

	}
	echo $output;

}

function woo_ce_modules_status_label( $status = 'inactive' ) {

	$output = '';
	switch( $status ) {

		case 'active':
			$output = __( 'OK', 'woo_ce' );
			break;

		case 'inactive':
			$output = __( 'Install', 'woo_ce' );
			break;

	}
	echo $output;

}

function woo_ce_dashboard_setup() {

	if( woo_ce_get_option( 'enable_auto', 0 ) == 1 )
		wp_add_dashboard_widget( 'woo_ce_scheduled_export_widget', __( 'Scheduled Exports', 'woo_ce' ), 'woo_ce_scheduled_export_widget' );

}

function woo_ce_scheduled_export_widget() {

	$enable_auto = woo_ce_get_option( 'enable_auto', 0 );
	if( $enable_auto == 1 ) {
		if( ( $next_export = woo_ce_next_scheduled_export() ) == false )
			$next_export = __( 'a little while...', 'woo_ce' );
	}

	if( file_exists( WOO_CD_PATH . 'templates/admin/dashboard_widget-scheduled_export.php' ) ) {
		include_once( WOO_CD_PATH . 'templates/admin/dashboard_widget-scheduled_export.php' );
	} else {
		$message = sprintf( __( 'We couldn\'t load the widget template file <code>%s</code> within <code>%s</code>, this file should be present.', 'woo_ce' ), 'dashboard_widget-scheduled_export.php', WOO_CD_PATH . 'templates/admin/...' );
		ob_start(); ?>
<p><strong><?php echo $message; ?></strong></p>
<p><?php _e( 'You can see this error for one of a few common reasons', 'woo_ce' ); ?>:</p>
<ul class="ul-disc">
	<li><?php _e( 'WordPress was unable to create this file when the Plugin was installed or updated', 'woo_ce' ); ?></li>
	<li><?php _e( 'The Plugin files have been recently changed and there has been a file conflict', 'woo_ce' ); ?></li>
	<li><?php _e( 'The Plugin file has been locked and cannot be opened by WordPress', 'woo_ce' ); ?></li>
</ul>
<p><?php _e( 'Jump onto our website and download a fresh copy of this Plugin as it might be enough to fix this issue. If this persists get in touch with us.', 'woo_ce' ); ?></p>
<?php
		ob_end_flush();
	}

}
?>