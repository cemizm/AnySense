<?php
// Function to generate filename of XML file based on the Export type
function woo_ce_generate_xml_filename( $export_type = '' ) {

	// Get the filename from WordPress options
	$filename = woo_ce_get_option( 'export_filename', 'woo-export_%dataset%-%date%.xml' );

	// Strip other file extensions if present
	$filename = str_replace( array( 'csv', 'xls' ), 'xml', $filename );
	if( ( strpos( $filename, '.csv' ) !== false ) || ( strpos( $filename, '.xls' ) !== false ) )
		$filename = str_replace( array( '.csv', '.xls' ), '.xml', $filename );

	// Add file extension if it has been removed
	if( strpos( $filename, '.xml' ) === false )
		$filename .= '.xml';

	// Populate the available tags
	$date = date( 'Y_m_d' );
	$time = date( 'H_i_s' );
	$store_name = sanitize_title( get_bloginfo( 'name' ) );

	// Switch out the tags for filled values
	$filename = str_replace( '%dataset%', $export_type, $filename );
	$filename = str_replace( '%date%', $date, $filename );
	$filename = str_replace( '%time%', $time, $filename );
	$filename = str_replace( '%store_name%', $store_name, $filename );

	// Return the filename
	return $filename;

}

// File output header for XML file
function woo_ce_generate_xml_header( $export_type = '' ) {

	global $export;

	if( $filename = woo_ce_generate_xml_filename( $export_type ) ) {
		$mime_type = 'application/xml';
		header( sprintf( 'Content-Encoding: %s', esc_attr( $export->encoding ) ) );
		header( sprintf( 'Content-Type: %s; charset=%s', $mime_type, esc_attr( $export->encoding ) ) );
		header( 'Content-Transfer-Encoding: binary' );
		header( sprintf( 'Content-Disposition: attachment; filename=%s', $filename ) );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
	}

}

// Function to generate a valid XML file
function woo_ce_format_xml( $xml = null ) {

	if( isset( $xml ) && is_object( $xml ) ) {
		$dom = dom_import_simplexml( $xml )->ownerDocument;
		$dom->formatOutput = true;
		return $dom->saveXML();
	}

}
?>