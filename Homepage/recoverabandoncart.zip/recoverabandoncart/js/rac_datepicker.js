
jQuery(document).ready(function() {
    jQuery('.rac_date').datepicker();
});
