<?php

class FPRacCron {

    public static function fp_rac_cron_job_setting() {
        wp_clear_scheduled_hook('rac_cron_job');
        if (wp_next_scheduled('rac_cron_job') == false) {
            wp_schedule_event(time(), 'xhourly', 'rac_cron_job');
        }
    }

//on save clear and set the cron again
    public static function fp_rac_cron_job_setting_savings() {
        wp_clear_scheduled_hook('rac_cron_job');
        if (wp_next_scheduled('rac_cron_job') == false) {
            wp_schedule_event(time(), 'xhourly', 'rac_cron_job');
        }
    }

    public static function fp_rac_add_x_hourly($schedules) {

        $interval = get_option('rac_abandon_cron_time');
        if (get_option('rac_abandon_cart_cron_type') == 'minutes') {
            $interval = $interval * 60;
        } else if (get_option('rac_abandon_cart_cron_type') == 'hours') {
            $interval = $interval * 3600;
        } else if (get_option('rac_abandon_cart_cron_type') == 'days') {
            $interval = $interval * 86400;
        }
        $schedules['xhourly'] = array(
            'interval' => $interval,
            'display' => 'X Hourly'
        );
        return $schedules;
    }

    public static function get_rac_formatprice($price) {
        if (function_exists('woocommerce_price')) {
            return woocommerce_price($price);
        } else {
            if (function_exists('wc_price')) {
                return wc_price($price);
            }
        }
    }

    public static function fp_rac_cron_job_mailing() {
        global $wpdb;
        global $woocommerce;
        $emailtemplate_table_name = $wpdb->prefix . 'rac_templates_email';
        $abandancart_table_name = $wpdb->prefix . 'rac_abandoncart';
        $email_templates = $wpdb->get_results("SELECT * FROM $emailtemplate_table_name"); //all email templates
        $abandon_carts = $wpdb->get_results("SELECT * FROM $abandancart_table_name WHERE cart_status='ABANDON' AND user_id!='0' AND completed IS NULL"); //Selected only cart which are not completed
// For Members
        foreach ($abandon_carts as $each_cart) {
            foreach ($email_templates as $emails) {
                if ($emails->status == "ACTIVE") {


                    $cart_array = maybe_unserialize($each_cart->cart_details);
                    $tablecheckproduct = "<table width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'><tbody><tr><th>" . __('Product name', 'recoverabandoncart') . "</th><th>" . __('Product image', 'recoverabandoncart') . "</th><th>" . __('Product Price', 'recoverabandoncart') . "</th></tr>";
                    if (is_array($cart_array)) {

                        foreach ($cart_array as $cart) {

                            foreach ($cart as $inside) {

                                foreach ($inside as $product) {
                                    $objectproduct = new WC_Product($product['product_id']);
                                    $objectproductvariable = new WC_Product_Variation($product['variation_id']);
                                    $tablecheckproduct .= "<tr><td>" . get_the_title($product['product_id']) . "</td><td>" . get_the_post_thumbnail($product['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($product['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                                }
                            }
                        }
                        /* $tablecheckproduct .= "It is from Array";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= $dump; */
                    } elseif (is_object($cart_array)) {
                        $order = new WC_Order($cart_array->id);
                        if ($order->user_id != '') {
                            foreach ($order->get_items() as $products) {
                                $objectproduct = new WC_Product($products['product_id']);
                                $objectproductvariable = new WC_Product_Variation($products['variation_id']);
                                $tablecheckproduct .= "<tr><td>" . get_the_title($products['product_id']) . "</td><td>" . get_the_post_thumbnail($products['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($products['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                            }
                        }
                        /*  $tablecheckproduct .= "It is from Object";
                          $tablecheckproduct .= var_dump($cart_array); */
                    }
                    $tablecheckproduct .= "</table>";



                    if (get_option('rac_email_use_members') == 'yes') {


                        if (empty($each_cart->mail_template_id)) { // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE
                            if ($emails->sending_type == 'hours') {
                                $duration = $emails->sending_duration * 3600;
                            } else if ($emails->sending_type == 'minutes') {
                                $duration = $emails->sending_duration * 60;
                            } else if ($emails->sending_type == 'days') {
                                $duration = $emails->sending_duration * 86400;
                            }
                            //duration is finished
                            $cut_off_time = $each_cart->cart_abandon_time + $duration;
                            $current_time = current_time('timestamp');
                            if ($current_time > $cut_off_time) {
                                $cart_url = $woocommerce->cart->get_cart_url();
                                $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id), $cart_url);

                                $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                $user = get_userdata($each_cart->user_id);
                                $to = $user->user_email;
                                $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                $firstname = $user->user_firstname;
                                $lastname = $user->user_lastname;


                                $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                $message = str_replace('{rac.firstname}', $firstname, $message);
                                $message = str_replace('{rac.lastname}', $lastname, $message);
                                $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                if (strpos($message, "{rac.coupon}")) {
                                    $coupon_code = FPRacCoupon::rac_create_coupon($user->user_email, $each_cart->cart_abandon_time);
                                    $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                }
                                $message = do_shortcode($message); //shortcode feature
                                if (get_option('rac_email_use_temp_plain') != 'yes') {
                                    ob_start();
                                    if (function_exists('wc_get_template')) {
                                        wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        wc_get_template('emails/email-footer.php');
                                    } else {
                                        woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        woocommerce_get_template('emails/email-footer.php');
                                    }
                                    $woo_temp_msg = ob_get_clean();
                                } else {
                                    $woo_temp_msg = $message;
                                }
                                $headers = "MIME-Version: 1.0\r\n";
                                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                if ($emails->sender_opt == 'local') {
                                    $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                    $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                } else {
                                    $headers .= self::rac_formatted_from_address_woocommerce();
                                    $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . " <" . get_option('woocommerce_email_from_address') . ">\r\n";
                                }
                                if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                    if ('wp_mail' == get_option('rac_trouble_mail')) {
                                        if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            //  wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    } else {
                                        if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            //  wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    }
                                }
                            }
                        }  // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE END
                        elseif (!empty($each_cart->mail_template_id)) {
                            $sent_mail_templates = maybe_unserialize($each_cart->mail_template_id);

                            if (!in_array($emails->id, $sent_mail_templates)) {
                                if ($emails->sending_type == 'hours') {
                                    $duration = $emails->sending_duration * 3600;
                                } else if ($emails->sending_type == 'minutes') {
                                    $duration = $emails->sending_duration * 60;
                                } else if ($emails->sending_type == 'days') {
                                    $duration = $emails->sending_duration * 86400;
                                }//duration is finished
                                $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                $current_time = current_time('timestamp');
                                if ($current_time > $cut_off_time) {
                                    $cart_url = $woocommerce->cart->get_cart_url();
                                    $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id), $cart_url);
                                    $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                    $user = get_userdata($each_cart->user_id);
                                    $to = $user->user_email;
                                    $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                    $firstname = $user->user_firstname;
                                    $lastname = $user->user_lastname;
                                    $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                    $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                    $message = str_replace('{rac.firstname}', $firstname, $message);
                                    $message = str_replace('{rac.lastname}', $lastname, $message);
                                    $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                    if (strpos($message, "{rac.coupon}")) {
                                        $coupon_code = FPRacCoupon::rac_create_coupon($user->user_email, $each_cart->cart_abandon_time);
                                        $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                    }
                                    $message = do_shortcode($message); //shortcode feature
                                    if (get_option('rac_email_use_temp_plain') != 'yes') {
                                        ob_start();
                                        if (function_exists('wc_get_template')) {
                                            wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            wc_get_template('emails/email-footer.php');
                                        } else {
                                            woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            woocommerce_get_template('emails/email-footer.php');
                                        }
                                        $woo_temp_msg = ob_get_clean();
                                    } else {
                                        $woo_temp_msg = $message;
                                    }
                                    $headers = "MIME-Version: 1.0\r\n";
                                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                    if ($emails->sender_opt == 'local') {
                                        $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                        $headers .= "Reply-To: " . $emails->from_name . " <" . $emails->from_email . ">\r\n";
                                    } else {
                                        $headers .= self::rac_formatted_from_address_woocommerce();
                                        $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                    }
                                    if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                        if ('wp_mail' == get_option('rac_trouble_mail')) {

                                            if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                //wp_mail($to, $subject, $message);
                                                $sent_mail_templates[] = $emails->id;
                                                $store_template_id = maybe_serialize($sent_mail_templates);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        } else {
                                            if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                //wp_mail($to, $subject, $message);
                                                $sent_mail_templates[] = $emails->id;
                                                $store_template_id = maybe_serialize($sent_mail_templates);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // FOR GUEST
        if (get_option('rac_email_use_guests') == 'yes') {

            $abandon_carts = $wpdb->get_results("SELECT * FROM $abandancart_table_name WHERE cart_status='ABANDON' AND user_id='0' AND ip_address IS NULL AND completed IS NULL"); //Selected only cart which are not completed


            foreach ($abandon_carts as $each_cart) {
                foreach ($email_templates as $emails) {

                    if ($emails->status == "ACTIVE") {
                        $cart_array = maybe_unserialize($each_cart->cart_details);
                        $tablecheckproduct = "<table width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'><tbody><tr><th>" . __('Product name', 'recoverabandoncart') . "</th><th>" . __('Product image', 'recoverabandoncart') . "</th><th>" . __('Product Price', 'recoverabandoncart') . "</th></tr>";

                        $order = new WC_Order($cart_array->id);
                        $products = $order->get_items();
                        //var_dump($products);

                        /* $tablecheckproduct .= "It is from Guest0 Object or Array";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= "<pre>";
                          $tablecheckproduct .= $dump;
                          $tablecheckproduct .= "</pre>"; */

                        foreach ($products as $each_product) {
                            $objectproduct = new WC_Product($each_product['product_id']);
                            $objectproductvariable = new WC_Product_Variable($each_product['variation_id']);
                            $tablecheckproduct .= "<tr><td>" . get_the_title($each_product['product_id']) . "</td><td>" . get_the_post_thumbnail($each_product['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($each_product['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                        }


                        $tablecheckproduct .= "</table>";


                        if (empty($each_cart->mail_template_id)) { // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE
                            if ($emails->sending_type == 'hours') {
                                $duration = $emails->sending_duration * 3600;
                            } else if ($emails->sending_type == 'minutes') {
                                $duration = $emails->sending_duration * 60;
                            } else if ($emails->sending_type == 'days') {
                                $duration = $emails->sending_duration * 86400;
                            }//duration is finished
                            $cut_off_time = $each_cart->cart_abandon_time + $duration;
                            $current_time = current_time('timestamp');
                            if ($current_time > $cut_off_time) {
                                $cart_url = $woocommerce->cart->get_cart_url();
                                $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'guest' => 'yes'), $cart_url);
                                $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                echo "<pre>";
                                var_dump($each_cart->cart_details);
                                echo "</pre>";
                                @$order_object = maybe_unserialize($each_cart->cart_details);
                                // $order_objectinfo = maybe_unserialize($productifo->cart_details);






                                $to = $order_object->billing_email;
                                $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                $firstname = $order_object->billing_first_name;
                                $lastname = $order_object->billing_last_name;


                                $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                $message = str_replace('{rac.firstname}', $firstname, $message);
                                $message = str_replace('{rac.lastname}', $lastname, $message);
                                $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);
                                if (strpos($message, "{rac.coupon}")) {
                                    $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                    $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                }
                                $message = do_shortcode($message); //shortcode feature
                                if (get_option('rac_email_use_temp_plain') != 'yes') {
                                    ob_start();
                                    if (function_exists('wc_get_template')) {
                                        wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        wc_get_template('emails/email-footer.php');
                                    } else {
                                        woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        woocommerce_get_template('emails/email-footer.php');
                                    }
                                    $woo_temp_msg = ob_get_clean();
                                } else {
                                    $woo_temp_msg = $message;
                                }
                                $headers = "MIME-Version: 1.0\r\n";
                                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                if ($emails->sender_opt == 'local') {
                                    $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                    $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                } else {
                                    $headers .= self::rac_formatted_from_address_woocommerce();
                                    $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                }
                                if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                    if ('wp_mail' == get_option('rac_trouble_mail')) {
                                        if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            // wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    } else {
                                        if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            // wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    }
                                }
                            }// IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE END
                            elseif (!empty($each_cart->mail_template_id)) {
                                $sent_mail_templates = maybe_unserialize($each_cart->mail_template_id);

                                if (!in_array($emails->id, $sent_mail_templates)) {
                                    if ($emails->sending_type == 'hours') {
                                        $duration = $emails->sending_duration * 3600;
                                    } else if ($emails->sending_type == 'minutes') {
                                        $duration = $emails->sending_duration * 60;
                                    } else if ($emails->sending_type == 'days') {
                                        $duration = $emails->sending_duration * 86400;
                                    }//duration is finished
                                    $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                    $current_time = current_time('timestamp');
                                    if ($current_time > $cut_off_time) {
                                        $cart_url = $woocommerce->cart->get_cart_url();
                                        $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'guest' => 'yes'), $cart_url);
                                        $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                        //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                        $order_object = maybe_unserialize($each_cart->cart_details);



                                        $to = $order_object->billing_email;
                                        $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                        $firstname = $order_object->billing_first_name;
                                        $lastname = $order_object->billing_last_name;
                                        $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                        $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                        $message = str_replace('{rac.firstname}', $firstname, $message);
                                        $message = str_replace('{rac.lastname}', $lastname, $message);
                                        $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);
                                        if (strpos($message, "{rac.coupon}")) {
                                            $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                            $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                        }
                                        $message = do_shortcode($message); //shortcode feature
                                        if (get_option('rac_email_use_temp_plain') != 'yes') {
                                            ob_start();
                                            if (function_exists('wc_get_template')) {
                                                wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                wc_get_template('emails/email-footer.php');
                                            } else {
                                                woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                woocommerce_get_template('emails/email-footer.php');
                                            }
                                            $woo_temp_msg = ob_get_clean();
                                        } else {
                                            $woo_temp_msg = $message;
                                        }
                                        $headers = "MIME-Version: 1.0\r\n";
                                        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                        if ($emails->sender_opt == 'local') {
                                            $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                            $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                        } else {
                                            $headers .= self::rac_formatted_from_address_woocommerce();
                                            $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                        }
                                        if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                            if ('wp_mail' == get_option('rac_trouble_mail')) {
                                                if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $sent_mail_templates[] = $emails->id;
                                                    $store_template_id = maybe_serialize($sent_mail_templates);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            } else {
                                                if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $store_template_id = array($emails->id);
                                                    $store_template_id = maybe_serialize($store_template_id);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }


            //FOR Guest Captured in chcekout page
            $abandon_carts = $wpdb->get_results("SELECT * FROM $abandancart_table_name WHERE cart_status='ABANDON' AND user_id='0' AND ip_address IS NOT NULL AND completed IS NULL"); //Selected only cart which are not completed

            foreach ($abandon_carts as $each_cart) {
                foreach ($email_templates as $emails) {
                    $cart_array = maybe_unserialize($each_cart->cart_details);
                    $tablecheckproduct = "<table width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'><tbody><tr><th>" . __('Product name', 'recoverabandoncart') . "</th><th>" . __('Product image', 'recoverabandoncart') . "</th><th>" . __('Product Price', 'recoverabandoncart') . "</th></tr>";
                    if (is_array($cart_array)) {
                        /* $tablecheckproduct .= "It is from Guest Array";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= "<pre>";
                          $tablecheckproduct .= $dump;
                          $tablecheckproduct .= "</pre>"; */
                        foreach ($cart_array as $cart) {


                            if (is_array($cart)) {

                                $objectproduct = new WC_Product($cart['product_id']);
                                $objectproductvariable = new WC_Product_Variable($cart['variation_id']);
                                $tablecheckproduct .= "<tr><td>" . get_the_title($cart['product_id']) . "</td><td>" . get_the_post_thumbnail($cart['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($cart['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                            }
                        }
                    } elseif (is_object($cart_array)) {
                        /* $tablecheckproduct .= "It is from Guest1 Object";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= $dump; */
                        $order = new WC_Order($cart_array->id);
//                        if ($order->user_id != '') {
                        foreach ($order->get_items() as $products) {
                            $objectproduct = new WC_Product($products['product_id']);
                            $objectproductvariable = new WC_Product_Variable($products['variation_id']);
                            $tablecheckproduct .= "<tr><td>" . get_the_title($products['product_id']) . "</td><td>" . get_the_post_thumbnail($products['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($products['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                        }
                        //  }
                    }
                    $tablecheckproduct .= "</table>";
                    if ($emails->status == "ACTIVE") {


                        if (empty($each_cart->mail_template_id)) { // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE
                            if ($emails->sending_type == 'hours') {
                                $duration = $emails->sending_duration * 3600;
                            } else if ($emails->sending_type == 'minutes') {
                                $duration = $emails->sending_duration * 60;
                            } else if ($emails->sending_type == 'days') {
                                $duration = $emails->sending_duration * 86400;
                            }//duration is finished
                            $cut_off_time = $each_cart->cart_abandon_time + $duration;
                            $current_time = current_time('timestamp');
                            if ($current_time > $cut_off_time) {
                                $cart_url = $woocommerce->cart->get_cart_url();
                                $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'guest' => 'yes', 'checkout' => 'yes'), $cart_url);
                                $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                $order_object = maybe_unserialize($each_cart->cart_details);




                                $to = $order_object['visitor_mail'];
                                $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                $firstname = $order_object['first_name'];
                                $lastname = $order_object['last_name'];
                                $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                $message = str_replace('{rac.firstname}', $firstname, $message);
                                $message = str_replace('{rac.lastname}', $lastname, $message);
                                $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);
                                if (strpos($message, "{rac.coupon}")) {
                                    $coupon_code = FPRacCoupon::rac_create_coupon($order_object['visitor_mail'], $each_cart->cart_abandon_time);
                                    $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                }
                                $message = do_shortcode($message); //shortcode feature
                                if (get_option('rac_email_use_temp_plain') != 'yes') {
                                    ob_start();
                                    if (function_exists('wc_get_template')) {
                                        wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        wc_get_template('emails/email-footer.php');
                                    } else {
                                        woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                        echo $message;
                                        woocommerce_get_template('emails/email-footer.php');
                                    }
                                    $woo_temp_msg = ob_get_clean();
                                } else {
                                    $woo_temp_msg = $message;
                                }
                                $headers = "MIME-Version: 1.0\r\n";
                                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                if ($emails->sender_opt == 'local') {
                                    $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                    $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                } else {
                                    $headers .= self::rac_formatted_from_address_woocommerce();
                                    $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                }
                                if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                    if ('wp_mail' == get_option('rac_trouble_mail')) {
                                        if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            // wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    } else {
                                        if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                            // wp_mail($to, $subject, $message);
                                            $store_template_id = array($emails->id);
                                            $store_template_id = maybe_serialize($store_template_id);
                                            $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                            //add to mail log
                                            $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                            $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                            FPRacCounter::rac_do_mail_count();
                                        }
                                    }
                                }
                            }
                        }// IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE END
                        elseif (!empty($each_cart->mail_template_id)) {
                            $sent_mail_templates = maybe_unserialize($each_cart->mail_template_id);

                            if (!in_array($emails->id, $sent_mail_templates)) {
                                if ($emails->sending_type == 'hours') {
                                    $duration = $emails->sending_duration * 3600;
                                } else if ($emails->sending_type == 'minutes') {
                                    $duration = $emails->sending_duration * 60;
                                } else if ($emails->sending_type == 'days') {
                                    $duration = $emails->sending_duration * 86400;
                                }//duration is finished
                                $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                $current_time = current_time('timestamp');
                                if ($current_time > $cut_off_time) {
                                    $cart_url = $woocommerce->cart->get_cart_url();
                                    $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'guest' => 'yes', 'checkout' => 'yes'), $cart_url);
                                    $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                    //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                    $order_object = maybe_unserialize($each_cart->cart_details);

                                    $to = $order_object['visitor_mail'];
                                    $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                    $firstname = $order_object['first_name'];
                                    $lastname = $order_object['last_name'];
                                    $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                    $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                    $message = str_replace('{rac.firstname}', $firstname, $message);
                                    $message = str_replace('{rac.lastname}', $lastname, $message);
                                    $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                    if (strpos($message, "{rac.coupon}")) {
                                        $coupon_code = FPRacCoupon::rac_create_coupon($order_object['visitor_mail'], $each_cart->cart_abandon_time);
                                        $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                    }
                                    $message = do_shortcode($message); //shortcode feature
                                    if (get_option('rac_email_use_temp_plain') != 'yes') {
                                        ob_start();
                                        if (function_exists('wc_get_template')) {
                                            wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            wc_get_template('emails/email-footer.php');
                                        } else {
                                            woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            woocommerce_get_template('emails/email-footer.php');
                                        }
                                        $woo_temp_msg = ob_get_clean();
                                    } else {
                                        $woo_temp_msg = $message;
                                    }
                                    $headers = "MIME-Version: 1.0\r\n";
                                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                    if ($emails->sender_opt == 'local') {
                                        $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                        $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                    } else {
                                        $headers .= self::rac_formatted_from_address_woocommerce();
                                        $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                    }
                                    if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                        if ('wp_mail' == get_option('rac_trouble_mail')) {
                                            if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $sent_mail_templates[] = $emails->id;
                                                $store_template_id = maybe_serialize($sent_mail_templates);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        } else {
                                            if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $sent_mail_templates[] = $emails->id;
                                                $store_template_id = maybe_serialize($sent_mail_templates);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // FOR ORDER UPDATED FROM OLD
        $abandon_carts = $wpdb->get_results("SELECT * FROM $abandancart_table_name WHERE cart_status='ABANDON' AND user_id='old_order' AND ip_address IS NULL AND completed IS NULL"); //Selected only cart which are not completed

        foreach ($abandon_carts as $each_cart) {

            foreach ($email_templates as $emails) {

                $cart_array = maybe_unserialize($each_cart->cart_details);
                $tablecheckproduct = "<table width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'><tbody><tr><th>" . __('Product name', 'recoverabandoncart') . "</th><th>" . __('Product image', 'recoverabandoncart') . "</th><th>" . __('Product Price', 'recoverabandoncart') . "</th></tr>";
                if (is_object($cart_array)) {
                    if (get_option('rac_email_use_members') == 'yes') {

                        /* $tablecheckproduct .= "It is from Member Object";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= $dump; */

                        $order = new WC_Order($cart_array->id);
                        if ($order->user_id != '') {
                            foreach ($order->get_items() as $products) {
                                $objectproduct = new WC_Product($products['product_id']);
                                $objectproductvariable = new WC_Product_Variable($products['variation_id']);
                                $tablecheckproduct .= "<tr><td>" . get_the_title($products['product_id']) . "</td><td>" . get_the_post_thumbnail($products['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($products['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                            }
                        }

                        //mail
                        if ($emails->status == "ACTIVE") {


                            if (empty($each_cart->mail_template_id)) { // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE
                                if ($emails->sending_type == 'hours') {
                                    $duration = $emails->sending_duration * 3600;
                                } else if ($emails->sending_type == 'minutes') {
                                    $duration = $emails->sending_duration * 60;
                                } else if ($emails->sending_type == 'days') {
                                    $duration = $emails->sending_duration * 86400;
                                }//duration is finished
                                $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                $current_time = current_time('timestamp');
                                if ($current_time > $cut_off_time) {
                                    $cart_url = $woocommerce->cart->get_cart_url();
                                    $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'old_order' => 'yes'), $cart_url);
                                    $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                    //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                    $order_object = maybe_unserialize($each_cart->cart_details);






                                    $to = $order_object->billing_email;
                                    $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                    $firstname = $order_object->billing_first_name;
                                    $lastname = $order_object->billing_last_name;

                                    $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                    $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                    $message = str_replace('{rac.firstname}', $firstname, $message);
                                    $message = str_replace('{rac.lastname}', $lastname, $message);
                                    $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                    if (strpos($message, "{rac.coupon}")) {
                                        $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                        $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                    }
                                    $message = do_shortcode($message); //shortcode feature
                                    if (get_option('rac_email_use_temp_plain') != 'yes') {
                                        ob_start();
                                        if (function_exists('wc_get_template')) {
                                            wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            wc_get_template('emails/email-footer.php');
                                        } else {
                                            woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            woocommerce_get_template('emails/email-footer.php');
                                        }
                                        $woo_temp_msg = ob_get_clean();
                                    } else {
                                        $woo_temp_msg = $message;
                                    }
                                    $headers = "MIME-Version: 1.0\r\n";
                                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                    if ($emails->sender_opt == 'local') {
                                        $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                        $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                    } else {
                                        $headers .= self::rac_formatted_from_address_woocommerce();
                                        $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                    }




                                    if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                        if ('wp_mail' == get_option('rac_trouble_mail')) {
                                            if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $store_template_id = array($emails->id);
                                                $store_template_id = maybe_serialize($store_template_id);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        } else {
                                            if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $store_template_id = array($emails->id);
                                                $store_template_id = maybe_serialize($store_template_id);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        }
                                    }
                                }
                            }// IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE END
                            elseif (!empty($each_cart->mail_template_id)) {
                                $sent_mail_templates = maybe_unserialize($each_cart->mail_template_id);

                                if (!in_array($emails->id, $sent_mail_templates)) {
                                    if ($emails->sending_type == 'hours') {
                                        $duration = $emails->sending_duration * 3600;
                                    } else if ($emails->sending_type == 'minutes') {
                                        $duration = $emails->sending_duration * 60;
                                    } else if ($emails->sending_type == 'days') {
                                        $duration = $emails->sending_duration * 86400;
                                    }//duration is finished
                                    $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                    $current_time = current_time('timestamp');
                                    if ($current_time > $cut_off_time) {
                                        $cart_url = $woocommerce->cart->get_cart_url();
                                        $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'old_order' => 'yes'), $cart_url);
                                        $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                        //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                        $order_object = maybe_unserialize($each_cart->cart_details);







                                        $to = $order_object->billing_email;
                                        $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                        $firstname = $order_object->billing_first_name;
                                        $lastname = $order_object->billing_last_name;
                                        $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                        $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                        $message = str_replace('{rac.firstname}', $firstname, $message);
                                        $message = str_replace('{rac.lastname}', $lastname, $message);
                                        $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);
                                        if (strpos($message, "{rac.coupon}")) {
                                            $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                            $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                        }
                                        $message = do_shortcode($message); //shortcode feature
                                        if (get_option('rac_email_use_temp_plain') != 'yes') {
                                            ob_start();
                                            if (function_exists('wc_get_template')) {
                                                wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                wc_get_template('emails/email-footer.php');
                                            } else {
                                                woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                woocommerce_get_template('emails/email-footer.php');
                                            }
                                            $woo_temp_msg = ob_get_clean();
                                        } else {
                                            $woo_temp_msg = $message;
                                        }
                                        $headers = "MIME-Version: 1.0\r\n";
                                        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                        if ($emails->sender_opt == 'local') {
                                            $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                            $headers .= "Reply-To: " . $emails->from_name . " <" . $emails->from_email . ">\r\n";
                                        } else {
                                            $headers .= self::rac_formatted_from_address_woocommerce();
                                            $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                        }






                                        if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                            if ('wp_mail' == get_option('rac_trouble_mail')) {
                                                if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $sent_mail_templates[] = $emails->id;
                                                    $store_template_id = maybe_serialize($sent_mail_templates);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            } else {
                                                if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $sent_mail_templates[] = $emails->id;
                                                    $store_template_id = maybe_serialize($sent_mail_templates);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (get_option('rac_email_use_guests') == 'yes') {
                        /*  $tablecheckproduct .= "It is from Guest2 Object";
                          $dump = print_r($cart_array, true);
                          $tablecheckproduct .= $dump; */
                        //  if ($order->user_id == '') {
                        foreach ($order->get_items() as $products) {
                            $objectproduct = new WC_Product($products['product_id']);
                            $objectproductvariable = new WC_Product_Variable($products['variation_id']);
                            $tablecheckproduct .= "<tr><td>" . get_the_title($products['product_id']) . "</td><td>" . get_the_post_thumbnail($products['product_id'], array(90, 90)) . "</td><td>" . self::get_rac_formatprice($products['variation_id'] == '' ? $objectproduct->get_price() : $objectproductvariable->get_price()) . "</td></tr>";
                        }
                        // }
                        $tablecheckproduct .= "</table>";

                        //guest mail
                        if ($emails->status == "ACTIVE") {


                            if (empty($each_cart->mail_template_id)) { // IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE
                                if ($emails->sending_type == 'hours') {
                                    $duration = $emails->sending_duration * 3600;
                                } else if ($emails->sending_type == 'minutes') {
                                    $duration = $emails->sending_duration * 60;
                                } else if ($emails->sending_type == 'days') {
                                    $duration = $emails->sending_duration * 86400;
                                }//duration is finished
                                $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                $current_time = current_time('timestamp');
                                if ($current_time > $cut_off_time) {
                                    $cart_url = $woocommerce->cart->get_cart_url();
                                    $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'old_order' => 'yes'), $cart_url);
                                    $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                    //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                    $order_object = maybe_unserialize($each_cart->cart_details);






                                    $to = $order_object->billing_email;
                                    $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                    $firstname = $order_object->billing_first_name;
                                    $lastname = $order_object->billing_last_name;

                                    $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                    $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                    $message = str_replace('{rac.firstname}', $firstname, $message);
                                    $message = str_replace('{rac.lastname}', $lastname, $message);
                                    $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                    if (strpos($message, "{rac.coupon}")) {
                                        $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                        $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                    }
                                    $message = do_shortcode($message); //shortcode feature
                                    if (get_option('rac_email_use_temp_plain') != 'yes') {
                                        ob_start();
                                        if (function_exists('wc_get_template')) {
                                            wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            wc_get_template('emails/email-footer.php');
                                        } else {
                                            woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                            echo $message;
                                            woocommerce_get_template('emails/email-footer.php');
                                        }
                                        $woo_temp_msg = ob_get_clean();
                                    } else {
                                        $woo_temp_msg = $message;
                                    }
                                    $headers = "MIME-Version: 1.0\r\n";
                                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                    if ($emails->sender_opt == 'local') {
                                        $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                        $headers .= "Reply-To: " . $emails->from_name . "<" . $emails->from_email . ">\r\n";
                                    } else {
                                        $headers .= self::rac_formatted_from_address_woocommerce();
                                        $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                    }




                                    if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                        if ('wp_mail' == get_option('rac_trouble_mail')) {
                                            if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $store_template_id = array($emails->id);
                                                $store_template_id = maybe_serialize($store_template_id);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        } else {
                                            if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                // wp_mail($to, $subject, $message);
                                                $store_template_id = array($emails->id);
                                                $store_template_id = maybe_serialize($store_template_id);
                                                $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                //add to mail log
                                                $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                FPRacCounter::rac_do_mail_count();
                                            }
                                        }
                                    }
                                }
                            }// IF EMPTY IT IS NOT SENT FOR ANY SINGLE TEMPLATE END
                            elseif (!empty($each_cart->mail_template_id)) {
                                $sent_mail_templates = maybe_unserialize($each_cart->mail_template_id);

                                if (!in_array($emails->id, $sent_mail_templates)) {
                                    if ($emails->sending_type == 'hours') {
                                        $duration = $emails->sending_duration * 3600;
                                    } else if ($emails->sending_type == 'minutes') {
                                        $duration = $emails->sending_duration * 60;
                                    } else if ($emails->sending_type == 'days') {
                                        $duration = $emails->sending_duration * 86400;
                                    }//duration is finished
                                    $cut_off_time = $each_cart->cart_abandon_time + $duration;
                                    $current_time = current_time('timestamp');
                                    if ($current_time > $cut_off_time) {
                                        $cart_url = $woocommerce->cart->get_cart_url();
                                        $url_to_click = add_query_arg(array('abandon_cart' => $each_cart->id, 'email_template' => $emails->id, 'old_order' => 'yes'), $cart_url);
                                        $url_to_click = '<a href="' . $url_to_click . '">' . $emails->anchor_text . '</a>';
                                        //  $user = get_userdata($each_cart->user_id); NOT APPLICABLE
                                        $order_object = maybe_unserialize($each_cart->cart_details);







                                        $to = $order_object->billing_email;
                                        $subject = fp_get_wpml_text('rac_template_' . $emails->id . '_subject', $each_cart->wpml_lang, $emails->subject);
                                        $firstname = $order_object->billing_first_name;
                                        $lastname = $order_object->billing_last_name;
                                        $message = fp_get_wpml_text('rac_template_' . $emails->id . '_message', $each_cart->wpml_lang, $emails->message);
                                        $message = str_replace('{rac.cartlink}', $url_to_click, $message);
                                        $message = str_replace('{rac.firstname}', $firstname, $message);
                                        $message = str_replace('{rac.lastname}', $lastname, $message);
                                        $message = str_replace('{rac.Productinfo}', $tablecheckproduct, $message);

                                        if (strpos($message, "{rac.coupon}")) {
                                            $coupon_code = FPRacCoupon::rac_create_coupon($order_object->billing_email, $each_cart->cart_abandon_time);
                                            $message = str_replace('{rac.coupon}', $coupon_code, $message); //replacing shortcode with coupon code
                                        }
                                        $message = do_shortcode($message); //shortcode feature
                                        if (get_option('rac_email_use_temp_plain') != 'yes') {
                                            ob_start();
                                            if (function_exists('wc_get_template')) {
                                                wc_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                wc_get_template('emails/email-footer.php');
                                            } else {
                                                woocommerce_get_template('emails/email-header.php', array('email_heading' => $subject));
                                                echo $message;
                                                woocommerce_get_template('emails/email-footer.php');
                                            }
                                            $woo_temp_msg = ob_get_clean();
                                        } else {
                                            $woo_temp_msg = $message;
                                        }
                                        $headers = "MIME-Version: 1.0\r\n";
                                        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                                        if ($emails->sender_opt == 'local') {
                                            $headers .= self::rac_formatted_from_address_local($emails->from_name, $emails->from_email);
                                            $headers .= "Reply-To: " . $emails->from_name . " <" . $emails->from_email . ">\r\n";
                                        } else {
                                            $headers .= self::rac_formatted_from_address_woocommerce();
                                            $headers .= "Reply-To: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
                                        }






                                        if ($each_cart->sending_status == 'SEND') {//condition to check start/stop mail sending
                                            if ('wp_mail' == get_option('rac_trouble_mail')) {
                                                if (self::rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $sent_mail_templates[] = $emails->id;
                                                    $store_template_id = maybe_serialize($sent_mail_templates);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            } else {
                                                if (self::rac_send_mail($to, $subject, $woo_temp_msg, $headers)) {
                                                    // wp_mail($to, $subject, $message);
                                                    $sent_mail_templates[] = $emails->id;
                                                    $store_template_id = maybe_serialize($sent_mail_templates);
                                                    $wpdb->update($abandancart_table_name, array('mail_template_id' => $store_template_id), array('id' => $each_cart->id));
                                                    //add to mail log
                                                    $table_name_logs = $wpdb->prefix . 'rac_email_logs';
                                                    $wpdb->insert($table_name_logs, array("email_id" => $to, "date_time" => $current_time, "rac_cart_id" => $each_cart->id, "template_used" => $emails->id));
                                                    FPRacCounter::rac_do_mail_count();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static function rac_send_wp_mail($to, $subject, $woo_temp_msg, $headers) {
        if (get_option('rac_webmaster_mail') == 'webmaster1') {
            return wp_mail($to, $subject, $woo_temp_msg, $headers, '-f ' . get_option('rac_textarea_mail'));
        } else {
            return wp_mail($to, $subject, $woo_temp_msg, $headers);
        }
    }

    public static function rac_send_mail($to, $subject, $woo_temp_msg, $headers) {
        if (get_option('rac_webmaster_mail') == 'webmaster1') {
            return mail($to, $subject, $woo_temp_msg, $headers, '-f ' . get_option('rac_textarea_mail'));
        } else {
            return mail($to, $subject, $woo_temp_msg, $headers);
        }
    }

    public static function rac_formatted_from_address_local($fromname, $fromemail) {
        if (get_option('rac_webmaster_mail') == 'webmaster1') {
            return "From: " . $fromname . "<" . $fromemail . ">" . "-f " . get_option('rac_textarea_mail') . "\r\n";
        } else {
            return "From: " . $fromname . "<" . $fromemail . ">\r\n";
        }
    }

    public static function rac_formatted_from_address_woocommerce() {
        if (get_option('rac_webmaster_mail') == 'webmaster1') {
            return "From: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">" . "-f " . get_option('rac_textarea_mail') . "\r\n";
        } else {
            return "From: " . get_option('woocommerce_email_from_name') . "<" . get_option('woocommerce_email_from_address') . ">\r\n";
        }
    }

}

add_filter('cron_schedules', array('FPRacCron', 'fp_rac_add_x_hourly'));

add_action('update_option_rac_abandon_cart_cron_type', array('FPRacCron', 'fp_rac_cron_job_setting_savings'));
add_action('update_option_rac_abandon_cron_time', array('FPRacCron', 'fp_rac_cron_job_setting_savings'));
