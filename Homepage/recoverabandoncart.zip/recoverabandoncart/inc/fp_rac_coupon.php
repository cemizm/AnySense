<?php

class FPRacCoupon {

    public static function rac_create_coupon($email, $timestamp) {
        $email_letters = substr($email, 0, 4);

        $coupon_code = $email_letters . $timestamp;
        $amount = get_option('rac_coupon_value');
        $discount_type = get_option('rac_coupon_type');
        $time_now = time();
        $validity_time = get_option('rac_coupon_validity') * 24 * 60 * 60;
        $expire_time = $time_now + $validity_time;
        $expire_date = date("Y-m-d", $expire_time); //formating expire date

        $coupon = array(
            'post_title' => $coupon_code,
            'post_content' => '',
            'post_status' => 'publish',
            'post_author' => 1,
            'post_type' => 'shop_coupon'
        );

        $new_coupon_id = wp_insert_post($coupon);

        update_post_meta($new_coupon_id, 'discount_type', $discount_type);
        update_post_meta($new_coupon_id, 'coupon_amount', $amount);
        update_post_meta($new_coupon_id, 'individual_use', 'no');
        update_post_meta($new_coupon_id, 'product_ids', '');
        update_post_meta($new_coupon_id, 'exclude_product_ids', '');
        update_post_meta($new_coupon_id, 'usage_limit', '1'); //this is must to avoid multiple usage
        update_post_meta($new_coupon_id, 'expiry_date', $expire_date);
        update_post_meta($new_coupon_id, 'apply_before_tax', 'yes');
        update_post_meta($new_coupon_id, 'free_shipping', 'no');
        if (update_post_meta($new_coupon_id, 'coupon_by_rac', 'yes')) {
            return $coupon_code;
        }
    }

}

?>